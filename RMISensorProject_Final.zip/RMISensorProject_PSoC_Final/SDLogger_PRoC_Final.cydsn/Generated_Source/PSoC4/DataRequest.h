/*******************************************************************************
* File Name: DataRequest.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DataRequest_H) /* Pins DataRequest_H */
#define CY_PINS_DataRequest_H

#include "cytypes.h"
#include "cyfitter.h"
#include "DataRequest_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    DataRequest_Write(uint8 value) ;
void    DataRequest_SetDriveMode(uint8 mode) ;
uint8   DataRequest_ReadDataReg(void) ;
uint8   DataRequest_Read(void) ;
uint8   DataRequest_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define DataRequest_DRIVE_MODE_BITS        (3)
#define DataRequest_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - DataRequest_DRIVE_MODE_BITS))

#define DataRequest_DM_ALG_HIZ         (0x00u)
#define DataRequest_DM_DIG_HIZ         (0x01u)
#define DataRequest_DM_RES_UP          (0x02u)
#define DataRequest_DM_RES_DWN         (0x03u)
#define DataRequest_DM_OD_LO           (0x04u)
#define DataRequest_DM_OD_HI           (0x05u)
#define DataRequest_DM_STRONG          (0x06u)
#define DataRequest_DM_RES_UPDWN       (0x07u)

/* Digital Port Constants */
#define DataRequest_MASK               DataRequest__MASK
#define DataRequest_SHIFT              DataRequest__SHIFT
#define DataRequest_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define DataRequest_PS                     (* (reg32 *) DataRequest__PS)
/* Port Configuration */
#define DataRequest_PC                     (* (reg32 *) DataRequest__PC)
/* Data Register */
#define DataRequest_DR                     (* (reg32 *) DataRequest__DR)
/* Input Buffer Disable Override */
#define DataRequest_INP_DIS                (* (reg32 *) DataRequest__PC2)


#if defined(DataRequest__INTSTAT)  /* Interrupt Registers */

    #define DataRequest_INTSTAT                (* (reg32 *) DataRequest__INTSTAT)

#endif /* Interrupt Registers */


/***************************************
* The following code is DEPRECATED and 
* must not be used.
***************************************/

#define DataRequest_DRIVE_MODE_SHIFT       (0x00u)
#define DataRequest_DRIVE_MODE_MASK        (0x07u << DataRequest_DRIVE_MODE_SHIFT)


#endif /* End Pins DataRequest_H */


/* [] END OF FILE */
