/***************************************************************************//**
* \file PSoC5_SPI_UART.c
* \version 3.20
*
* \brief
*  This file provides the source code to the API for the SCB Component in
*  SPI and UART modes.
*
* Note:
*
*******************************************************************************
* \copyright
* Copyright 2013-2016, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "PSoC5_PVT.h"
#include "PSoC5_SPI_UART_PVT.h"

/***************************************
*        SPI/UART Private Vars
***************************************/

#if(PSoC5_INTERNAL_RX_SW_BUFFER_CONST)
    /* Start index to put data into the software receive buffer.*/
    volatile uint32 PSoC5_rxBufferHead;
    /* Start index to get data from the software receive buffer.*/
    volatile uint32 PSoC5_rxBufferTail;
    /**
    * \addtogroup group_globals
    * \{
    */
    /** Sets when internal software receive buffer overflow
    *  was occurred.
    */
    volatile uint8  PSoC5_rxBufferOverflow;
    /** \} globals */
#endif /* (PSoC5_INTERNAL_RX_SW_BUFFER_CONST) */

#if(PSoC5_INTERNAL_TX_SW_BUFFER_CONST)
    /* Start index to put data into the software transmit buffer.*/
    volatile uint32 PSoC5_txBufferHead;
    /* Start index to get data from the software transmit buffer.*/
    volatile uint32 PSoC5_txBufferTail;
#endif /* (PSoC5_INTERNAL_TX_SW_BUFFER_CONST) */

#if(PSoC5_INTERNAL_RX_SW_BUFFER)
    /* Add one element to the buffer to receive full packet. One byte in receive buffer is always empty */
    volatile uint8 PSoC5_rxBufferInternal[PSoC5_INTERNAL_RX_BUFFER_SIZE];
#endif /* (PSoC5_INTERNAL_RX_SW_BUFFER) */

#if(PSoC5_INTERNAL_TX_SW_BUFFER)
    volatile uint8 PSoC5_txBufferInternal[PSoC5_TX_BUFFER_SIZE];
#endif /* (PSoC5_INTERNAL_TX_SW_BUFFER) */


#if(PSoC5_RX_DIRECTION)
    /*******************************************************************************
    * Function Name: PSoC5_SpiUartReadRxData
    ****************************************************************************//**
    *
    *  Retrieves the next data element from the receive buffer.
    *   - RX software buffer is disabled: Returns data element retrieved from
    *     RX FIFO. Undefined data will be returned if the RX FIFO is empty.
    *   - RX software buffer is enabled: Returns data element from the software
    *     receive buffer. Zero value is returned if the software receive buffer
    *     is empty.
    *
    * \return
    *  Next data element from the receive buffer. 
    *  The amount of data bits to be received depends on RX data bits selection 
    *  (the data bit counting starts from LSB of return value).
    *
    * \globalvars
    *  PSoC5_rxBufferHead - the start index to put data into the 
    *  software receive buffer.
    *  PSoC5_rxBufferTail - the start index to get data from the 
    *  software receive buffer.
    *
    *******************************************************************************/
    uint32 PSoC5_SpiUartReadRxData(void)
    {
        uint32 rxData = 0u;

    #if (PSoC5_INTERNAL_RX_SW_BUFFER_CONST)
        uint32 locTail;
    #endif /* (PSoC5_INTERNAL_RX_SW_BUFFER_CONST) */

        #if (PSoC5_CHECK_RX_SW_BUFFER)
        {
            if (PSoC5_rxBufferHead != PSoC5_rxBufferTail)
            {
                /* There is data in RX software buffer */

                /* Calculate index to read from */
                locTail = (PSoC5_rxBufferTail + 1u);

                if (PSoC5_INTERNAL_RX_BUFFER_SIZE == locTail)
                {
                    locTail = 0u;
                }

                /* Get data from RX software buffer */
                rxData = PSoC5_GetWordFromRxBuffer(locTail);

                /* Change index in the buffer */
                PSoC5_rxBufferTail = locTail;

                #if (PSoC5_CHECK_UART_RTS_CONTROL_FLOW)
                {
                    /* Check if RX Not Empty is disabled in the interrupt */
                    if (0u == (PSoC5_INTR_RX_MASK_REG & PSoC5_INTR_RX_NOT_EMPTY))
                    {
                        /* Enable RX Not Empty interrupt source to continue
                        * receiving data into software buffer.
                        */
                        PSoC5_INTR_RX_MASK_REG |= PSoC5_INTR_RX_NOT_EMPTY;
                    }
                }
                #endif

            }
        }
        #else
        {
            /* Read data from RX FIFO */
            rxData = PSoC5_RX_FIFO_RD_REG;
        }
        #endif

        return (rxData);
    }


    /*******************************************************************************
    * Function Name: PSoC5_SpiUartGetRxBufferSize
    ****************************************************************************//**
    *
    *  Returns the number of received data elements in the receive buffer.
    *   - RX software buffer disabled: returns the number of used entries in
    *     RX FIFO.
    *   - RX software buffer enabled: returns the number of elements which were
    *     placed in the receive buffer. This does not include the hardware RX FIFO.
    *
    * \return
    *  Number of received data elements.
    *
    * \globalvars
    *  PSoC5_rxBufferHead - the start index to put data into the 
    *  software receive buffer.
    *  PSoC5_rxBufferTail - the start index to get data from the 
    *  software receive buffer.
    *
    *******************************************************************************/
    uint32 PSoC5_SpiUartGetRxBufferSize(void)
    {
        uint32 size;
    #if (PSoC5_INTERNAL_RX_SW_BUFFER_CONST)
        uint32 locHead;
    #endif /* (PSoC5_INTERNAL_RX_SW_BUFFER_CONST) */

        #if (PSoC5_CHECK_RX_SW_BUFFER)
        {
            locHead = PSoC5_rxBufferHead;

            if(locHead >= PSoC5_rxBufferTail)
            {
                size = (locHead - PSoC5_rxBufferTail);
            }
            else
            {
                size = (locHead + (PSoC5_INTERNAL_RX_BUFFER_SIZE - PSoC5_rxBufferTail));
            }
        }
        #else
        {
            size = PSoC5_GET_RX_FIFO_ENTRIES;
        }
        #endif

        return (size);
    }


    /*******************************************************************************
    * Function Name: PSoC5_SpiUartClearRxBuffer
    ****************************************************************************//**
    *
    *  Clears the receive buffer and RX FIFO.
    *
    * \globalvars
    *  PSoC5_rxBufferHead - the start index to put data into the 
    *  software receive buffer.
    *  PSoC5_rxBufferTail - the start index to get data from the 
    *  software receive buffer.
    *
    *******************************************************************************/
    void PSoC5_SpiUartClearRxBuffer(void)
    {
        #if (PSoC5_CHECK_RX_SW_BUFFER)
        {
            /* Lock from component interruption */
            PSoC5_DisableInt();

            /* Flush RX software buffer */
            PSoC5_rxBufferHead = PSoC5_rxBufferTail;
            PSoC5_rxBufferOverflow = 0u;

            PSoC5_CLEAR_RX_FIFO;
            PSoC5_ClearRxInterruptSource(PSoC5_INTR_RX_ALL);

            #if (PSoC5_CHECK_UART_RTS_CONTROL_FLOW)
            {
                /* Enable RX Not Empty interrupt source to continue receiving
                * data into software buffer.
                */
                PSoC5_INTR_RX_MASK_REG |= PSoC5_INTR_RX_NOT_EMPTY;
            }
            #endif
            
            /* Release lock */
            PSoC5_EnableInt();
        }
        #else
        {
            PSoC5_CLEAR_RX_FIFO;
        }
        #endif
    }

#endif /* (PSoC5_RX_DIRECTION) */


#if(PSoC5_TX_DIRECTION)
    /*******************************************************************************
    * Function Name: PSoC5_SpiUartWriteTxData
    ****************************************************************************//**
    *
    *  Places a data entry into the transmit buffer to be sent at the next available
    *  bus time.
    *  This function is blocking and waits until there is space available to put the
    *  requested data in the transmit buffer.
    *
    *  \param txDataByte: the data to be transmitted.
    *   The amount of data bits to be transmitted depends on TX data bits selection 
    *   (the data bit counting starts from LSB of txDataByte).
    *
    * \globalvars
    *  PSoC5_txBufferHead - the start index to put data into the 
    *  software transmit buffer.
    *  PSoC5_txBufferTail - start index to get data from the software
    *  transmit buffer.
    *
    *******************************************************************************/
    void PSoC5_SpiUartWriteTxData(uint32 txData)
    {
    #if (PSoC5_INTERNAL_TX_SW_BUFFER_CONST)
        uint32 locHead;
    #endif /* (PSoC5_INTERNAL_TX_SW_BUFFER_CONST) */

        #if (PSoC5_CHECK_TX_SW_BUFFER)
        {
            /* Put data directly into the TX FIFO */
            if ((PSoC5_txBufferHead == PSoC5_txBufferTail) &&
                (PSoC5_SPI_UART_FIFO_SIZE != PSoC5_GET_TX_FIFO_ENTRIES))
            {
                /* TX software buffer is empty: put data directly in TX FIFO */
                PSoC5_TX_FIFO_WR_REG = txData;
            }
            /* Put data into TX software buffer */
            else
            {
                /* Head index to put data */
                locHead = (PSoC5_txBufferHead + 1u);

                /* Adjust TX software buffer index */
                if (PSoC5_TX_BUFFER_SIZE == locHead)
                {
                    locHead = 0u;
                }

                /* Wait for space in TX software buffer */
                while (locHead == PSoC5_txBufferTail)
                {
                }

                /* TX software buffer has at least one room */

                /* Clear old status of INTR_TX_NOT_FULL. It sets at the end of transfer when TX FIFO is empty. */
                PSoC5_ClearTxInterruptSource(PSoC5_INTR_TX_NOT_FULL);

                PSoC5_PutWordInTxBuffer(locHead, txData);

                PSoC5_txBufferHead = locHead;

                /* Check if TX Not Full is disabled in interrupt */
                if (0u == (PSoC5_INTR_TX_MASK_REG & PSoC5_INTR_TX_NOT_FULL))
                {
                    /* Enable TX Not Full interrupt source to transmit from software buffer */
                    PSoC5_INTR_TX_MASK_REG |= (uint32) PSoC5_INTR_TX_NOT_FULL;
                }
            }
        }
        #else
        {
            /* Wait until TX FIFO has space to put data element */
            while (PSoC5_SPI_UART_FIFO_SIZE == PSoC5_GET_TX_FIFO_ENTRIES)
            {
            }

            PSoC5_TX_FIFO_WR_REG = txData;
        }
        #endif
    }


    /*******************************************************************************
    * Function Name: PSoC5_SpiUartPutArray
    ****************************************************************************//**
    *
    *  Places an array of data into the transmit buffer to be sent.
    *  This function is blocking and waits until there is a space available to put
    *  all the requested data in the transmit buffer. The array size can be greater
    *  than transmit buffer size.
    *
    * \param wrBuf: pointer to an array of data to be placed in transmit buffer. 
    *  The width of the data to be transmitted depends on TX data width selection 
    *  (the data bit counting starts from LSB for each array element).
    * \param count: number of data elements to be placed in the transmit buffer.
    *
    * \globalvars
    *  PSoC5_txBufferHead - the start index to put data into the 
    *  software transmit buffer.
    *  PSoC5_txBufferTail - start index to get data from the software
    *  transmit buffer.
    *
    *******************************************************************************/
    void PSoC5_SpiUartPutArray(const uint8 wrBuf[], uint32 count)
    {
        uint32 i;

        for (i=0u; i < count; i++)
        {
            PSoC5_SpiUartWriteTxData((uint32) wrBuf[i]);
        }
    }


    /*******************************************************************************
    * Function Name: PSoC5_SpiUartGetTxBufferSize
    ****************************************************************************//**
    *
    *  Returns the number of elements currently in the transmit buffer.
    *   - TX software buffer is disabled: returns the number of used entries in
    *     TX FIFO.
    *   - TX software buffer is enabled: returns the number of elements currently
    *     used in the transmit buffer. This number does not include used entries in
    *     the TX FIFO. The transmit buffer size is zero until the TX FIFO is
    *     not full.
    *
    * \return
    *  Number of data elements ready to transmit.
    *
    * \globalvars
    *  PSoC5_txBufferHead - the start index to put data into the 
    *  software transmit buffer.
    *  PSoC5_txBufferTail - start index to get data from the software
    *  transmit buffer.
    *
    *******************************************************************************/
    uint32 PSoC5_SpiUartGetTxBufferSize(void)
    {
        uint32 size;
    #if (PSoC5_INTERNAL_TX_SW_BUFFER_CONST)
        uint32 locTail;
    #endif /* (PSoC5_INTERNAL_TX_SW_BUFFER_CONST) */

        #if (PSoC5_CHECK_TX_SW_BUFFER)
        {
            /* Get current Tail index */
            locTail = PSoC5_txBufferTail;

            if (PSoC5_txBufferHead >= locTail)
            {
                size = (PSoC5_txBufferHead - locTail);
            }
            else
            {
                size = (PSoC5_txBufferHead + (PSoC5_TX_BUFFER_SIZE - locTail));
            }
        }
        #else
        {
            size = PSoC5_GET_TX_FIFO_ENTRIES;
        }
        #endif

        return (size);
    }


    /*******************************************************************************
    * Function Name: PSoC5_SpiUartClearTxBuffer
    ****************************************************************************//**
    *
    *  Clears the transmit buffer and TX FIFO.
    *
    * \globalvars
    *  PSoC5_txBufferHead - the start index to put data into the 
    *  software transmit buffer.
    *  PSoC5_txBufferTail - start index to get data from the software
    *  transmit buffer.
    *
    *******************************************************************************/
    void PSoC5_SpiUartClearTxBuffer(void)
    {
        #if (PSoC5_CHECK_TX_SW_BUFFER)
        {
            /* Lock from component interruption */
            PSoC5_DisableInt();

            /* Flush TX software buffer */
            PSoC5_txBufferHead = PSoC5_txBufferTail;

            PSoC5_INTR_TX_MASK_REG &= (uint32) ~PSoC5_INTR_TX_NOT_FULL;
            PSoC5_CLEAR_TX_FIFO;
            PSoC5_ClearTxInterruptSource(PSoC5_INTR_TX_ALL);

            /* Release lock */
            PSoC5_EnableInt();
        }
        #else
        {
            PSoC5_CLEAR_TX_FIFO;
        }
        #endif
    }

#endif /* (PSoC5_TX_DIRECTION) */


/*******************************************************************************
* Function Name: PSoC5_SpiUartDisableIntRx
****************************************************************************//**
*
*  Disables the RX interrupt sources.
*
*  \return
*   Returns the RX interrupt sources enabled before the function call.
*
*******************************************************************************/
uint32 PSoC5_SpiUartDisableIntRx(void)
{
    uint32 intSource;

    intSource = PSoC5_GetRxInterruptMode();

    PSoC5_SetRxInterruptMode(PSoC5_NO_INTR_SOURCES);

    return (intSource);
}


/*******************************************************************************
* Function Name: PSoC5_SpiUartDisableIntTx
****************************************************************************//**
*
*  Disables TX interrupt sources.
*
*  \return
*   Returns TX interrupt sources enabled before function call.
*
*******************************************************************************/
uint32 PSoC5_SpiUartDisableIntTx(void)
{
    uint32 intSourceMask;

    intSourceMask = PSoC5_GetTxInterruptMode();

    PSoC5_SetTxInterruptMode(PSoC5_NO_INTR_SOURCES);

    return (intSourceMask);
}


#if(PSoC5_SCB_MODE_UNCONFIG_CONST_CFG)
    /*******************************************************************************
    * Function Name: PSoC5_PutWordInRxBuffer
    ****************************************************************************//**
    *
    *  Stores a byte/word into the RX buffer.
    *  Only available in the Unconfigured operation mode.
    *
    *  \param index:      index to store data byte/word in the RX buffer.
    *  \param rxDataByte: byte/word to store.
    *
    *******************************************************************************/
    void PSoC5_PutWordInRxBuffer(uint32 idx, uint32 rxDataByte)
    {
        /* Put data in buffer */
        if (PSoC5_ONE_BYTE_WIDTH == PSoC5_rxDataBits)
        {
            PSoC5_rxBuffer[idx] = ((uint8) rxDataByte);
        }
        else
        {
            PSoC5_rxBuffer[(uint32)(idx << 1u)]      = LO8(LO16(rxDataByte));
            PSoC5_rxBuffer[(uint32)(idx << 1u) + 1u] = HI8(LO16(rxDataByte));
        }
    }


    /*******************************************************************************
    * Function Name: PSoC5_GetWordFromRxBuffer
    ****************************************************************************//**
    *
    *  Reads byte/word from RX buffer.
    *  Only available in the Unconfigured operation mode.
    *
    *  \return
    *   Returns byte/word read from RX buffer.
    *
    *******************************************************************************/
    uint32 PSoC5_GetWordFromRxBuffer(uint32 idx)
    {
        uint32 value;

        if (PSoC5_ONE_BYTE_WIDTH == PSoC5_rxDataBits)
        {
            value = PSoC5_rxBuffer[idx];
        }
        else
        {
            value  = (uint32) PSoC5_rxBuffer[(uint32)(idx << 1u)];
            value |= (uint32) ((uint32)PSoC5_rxBuffer[(uint32)(idx << 1u) + 1u] << 8u);
        }

        return (value);
    }


    /*******************************************************************************
    * Function Name: PSoC5_PutWordInTxBuffer
    ****************************************************************************//**
    *
    *  Stores byte/word into the TX buffer.
    *  Only available in the Unconfigured operation mode.
    *
    *  \param idx:        index to store data byte/word in the TX buffer.
    *  \param txDataByte: byte/word to store.
    *
    *******************************************************************************/
    void PSoC5_PutWordInTxBuffer(uint32 idx, uint32 txDataByte)
    {
        /* Put data in buffer */
        if (PSoC5_ONE_BYTE_WIDTH == PSoC5_txDataBits)
        {
            PSoC5_txBuffer[idx] = ((uint8) txDataByte);
        }
        else
        {
            PSoC5_txBuffer[(uint32)(idx << 1u)]      = LO8(LO16(txDataByte));
            PSoC5_txBuffer[(uint32)(idx << 1u) + 1u] = HI8(LO16(txDataByte));
        }
    }


    /*******************************************************************************
    * Function Name: PSoC5_GetWordFromTxBuffer
    ****************************************************************************//**
    *
    *  Reads byte/word from the TX buffer.
    *  Only available in the Unconfigured operation mode.
    *
    *  \param idx: index to get data byte/word from the TX buffer.
    *
    *  \return
    *   Returns byte/word read from the TX buffer.
    *
    *******************************************************************************/
    uint32 PSoC5_GetWordFromTxBuffer(uint32 idx)
    {
        uint32 value;

        if (PSoC5_ONE_BYTE_WIDTH == PSoC5_txDataBits)
        {
            value = (uint32) PSoC5_txBuffer[idx];
        }
        else
        {
            value  = (uint32) PSoC5_txBuffer[(uint32)(idx << 1u)];
            value |= (uint32) ((uint32) PSoC5_txBuffer[(uint32)(idx << 1u) + 1u] << 8u);
        }

        return (value);
    }

#endif /* (PSoC5_SCB_MODE_UNCONFIG_CONST_CFG) */


/* [] END OF FILE */
