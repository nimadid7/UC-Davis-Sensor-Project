/***************************************************************************//**
* \file PSoC5_SPI_UART_INT.c
* \version 3.20
*
* \brief
*  This file provides the source code to the Interrupt Service Routine for
*  the SCB Component in SPI and UART modes.
*
* Note:
*
********************************************************************************
* \copyright
* Copyright 2013-2016, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "PSoC5_PVT.h"
#include "PSoC5_SPI_UART_PVT.h"


#if (PSoC5_SCB_IRQ_INTERNAL)
/*******************************************************************************
* Function Name: PSoC5_SPI_UART_ISR
****************************************************************************//**
*
*  Handles the Interrupt Service Routine for the SCB SPI or UART modes.
*
*******************************************************************************/
CY_ISR(PSoC5_SPI_UART_ISR)
{
#if (PSoC5_INTERNAL_RX_SW_BUFFER_CONST)
    uint32 locHead;
#endif /* (PSoC5_INTERNAL_RX_SW_BUFFER_CONST) */

#if (PSoC5_INTERNAL_TX_SW_BUFFER_CONST)
    uint32 locTail;
#endif /* (PSoC5_INTERNAL_TX_SW_BUFFER_CONST) */

#ifdef PSoC5_SPI_UART_ISR_ENTRY_CALLBACK
    PSoC5_SPI_UART_ISR_EntryCallback();
#endif /* PSoC5_SPI_UART_ISR_ENTRY_CALLBACK */

    if (NULL != PSoC5_customIntrHandler)
    {
        PSoC5_customIntrHandler();
    }

    #if(PSoC5_CHECK_SPI_WAKE_ENABLE)
    {
        /* Clear SPI wakeup source */
        PSoC5_ClearSpiExtClkInterruptSource(PSoC5_INTR_SPI_EC_WAKE_UP);
    }
    #endif

    #if (PSoC5_CHECK_RX_SW_BUFFER)
    {
        if (PSoC5_CHECK_INTR_RX_MASKED(PSoC5_INTR_RX_NOT_EMPTY))
        {
            do
            {
                /* Move local head index */
                locHead = (PSoC5_rxBufferHead + 1u);

                /* Adjust local head index */
                if (PSoC5_INTERNAL_RX_BUFFER_SIZE == locHead)
                {
                    locHead = 0u;
                }

                if (locHead == PSoC5_rxBufferTail)
                {
                    #if (PSoC5_CHECK_UART_RTS_CONTROL_FLOW)
                    {
                        /* There is no space in the software buffer - disable the
                        * RX Not Empty interrupt source. The data elements are
                        * still being received into the RX FIFO until the RTS signal
                        * stops the transmitter. After the data element is read from the
                        * buffer, the RX Not Empty interrupt source is enabled to
                        * move the next data element in the software buffer.
                        */
                        PSoC5_INTR_RX_MASK_REG &= ~PSoC5_INTR_RX_NOT_EMPTY;
                        break;
                    }
                    #else
                    {
                        /* Overflow: through away received data element */
                        (void) PSoC5_RX_FIFO_RD_REG;
                        PSoC5_rxBufferOverflow = (uint8) PSoC5_INTR_RX_OVERFLOW;
                    }
                    #endif
                }
                else
                {
                    /* Store received data */
                    PSoC5_PutWordInRxBuffer(locHead, PSoC5_RX_FIFO_RD_REG);

                    /* Move head index */
                    PSoC5_rxBufferHead = locHead;
                }
            }
            while(0u != PSoC5_GET_RX_FIFO_ENTRIES);

            PSoC5_ClearRxInterruptSource(PSoC5_INTR_RX_NOT_EMPTY);
        }
    }
    #endif


    #if (PSoC5_CHECK_TX_SW_BUFFER)
    {
        if (PSoC5_CHECK_INTR_TX_MASKED(PSoC5_INTR_TX_NOT_FULL))
        {
            do
            {
                /* Check for room in TX software buffer */
                if (PSoC5_txBufferHead != PSoC5_txBufferTail)
                {
                    /* Move local tail index */
                    locTail = (PSoC5_txBufferTail + 1u);

                    /* Adjust local tail index */
                    if (PSoC5_TX_BUFFER_SIZE == locTail)
                    {
                        locTail = 0u;
                    }

                    /* Put data into TX FIFO */
                    PSoC5_TX_FIFO_WR_REG = PSoC5_GetWordFromTxBuffer(locTail);

                    /* Move tail index */
                    PSoC5_txBufferTail = locTail;
                }
                else
                {
                    /* TX software buffer is empty: complete transfer */
                    PSoC5_DISABLE_INTR_TX(PSoC5_INTR_TX_NOT_FULL);
                    break;
                }
            }
            while (PSoC5_SPI_UART_FIFO_SIZE != PSoC5_GET_TX_FIFO_ENTRIES);

            PSoC5_ClearTxInterruptSource(PSoC5_INTR_TX_NOT_FULL);
        }
    }
    #endif

#ifdef PSoC5_SPI_UART_ISR_EXIT_CALLBACK
    PSoC5_SPI_UART_ISR_ExitCallback();
#endif /* PSoC5_SPI_UART_ISR_EXIT_CALLBACK */

}

#endif /* (PSoC5_SCB_IRQ_INTERNAL) */


/* [] END OF FILE */
