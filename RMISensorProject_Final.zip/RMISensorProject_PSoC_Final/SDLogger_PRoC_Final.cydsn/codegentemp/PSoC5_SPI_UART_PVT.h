/***************************************************************************//**
* \file PSoC5_SPI_UART_PVT.h
* \version 3.20
*
* \brief
*  This private file provides constants and parameter values for the
*  SCB Component in SPI and UART modes.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* \copyright
* Copyright 2013-2016, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_SPI_UART_PVT_PSoC5_H)
#define CY_SCB_SPI_UART_PVT_PSoC5_H

#include "PSoC5_SPI_UART.h"


/***************************************
*     Internal Global Vars
***************************************/

#if (PSoC5_INTERNAL_RX_SW_BUFFER_CONST)
    extern volatile uint32  PSoC5_rxBufferHead;
    extern volatile uint32  PSoC5_rxBufferTail;
    
    /**
    * \addtogroup group_globals
    * @{
    */
    
    /** Sets when internal software receive buffer overflow
     *  was occurred.
    */  
    extern volatile uint8   PSoC5_rxBufferOverflow;
    /** @} globals */
#endif /* (PSoC5_INTERNAL_RX_SW_BUFFER_CONST) */

#if (PSoC5_INTERNAL_TX_SW_BUFFER_CONST)
    extern volatile uint32  PSoC5_txBufferHead;
    extern volatile uint32  PSoC5_txBufferTail;
#endif /* (PSoC5_INTERNAL_TX_SW_BUFFER_CONST) */

#if (PSoC5_INTERNAL_RX_SW_BUFFER)
    extern volatile uint8 PSoC5_rxBufferInternal[PSoC5_INTERNAL_RX_BUFFER_SIZE];
#endif /* (PSoC5_INTERNAL_RX_SW_BUFFER) */

#if (PSoC5_INTERNAL_TX_SW_BUFFER)
    extern volatile uint8 PSoC5_txBufferInternal[PSoC5_TX_BUFFER_SIZE];
#endif /* (PSoC5_INTERNAL_TX_SW_BUFFER) */


/***************************************
*     Private Function Prototypes
***************************************/

void PSoC5_SpiPostEnable(void);
void PSoC5_SpiStop(void);

#if (PSoC5_SCB_MODE_SPI_CONST_CFG)
    void PSoC5_SpiInit(void);
#endif /* (PSoC5_SCB_MODE_SPI_CONST_CFG) */

#if (PSoC5_SPI_WAKE_ENABLE_CONST)
    void PSoC5_SpiSaveConfig(void);
    void PSoC5_SpiRestoreConfig(void);
#endif /* (PSoC5_SPI_WAKE_ENABLE_CONST) */

void PSoC5_UartPostEnable(void);
void PSoC5_UartStop(void);

#if (PSoC5_SCB_MODE_UART_CONST_CFG)
    void PSoC5_UartInit(void);
#endif /* (PSoC5_SCB_MODE_UART_CONST_CFG) */

#if (PSoC5_UART_WAKE_ENABLE_CONST)
    void PSoC5_UartSaveConfig(void);
    void PSoC5_UartRestoreConfig(void);
#endif /* (PSoC5_UART_WAKE_ENABLE_CONST) */


/***************************************
*         UART API Constants
***************************************/

/* UART RX and TX position to be used in PSoC5_SetPins() */
#define PSoC5_UART_RX_PIN_ENABLE    (PSoC5_UART_RX)
#define PSoC5_UART_TX_PIN_ENABLE    (PSoC5_UART_TX)

/* UART RTS and CTS position to be used in  PSoC5_SetPins() */
#define PSoC5_UART_RTS_PIN_ENABLE    (0x10u)
#define PSoC5_UART_CTS_PIN_ENABLE    (0x20u)


/***************************************
* The following code is DEPRECATED and
* must not be used.
***************************************/

/* Interrupt processing */
#define PSoC5_SpiUartEnableIntRx(intSourceMask)  PSoC5_SetRxInterruptMode(intSourceMask)
#define PSoC5_SpiUartEnableIntTx(intSourceMask)  PSoC5_SetTxInterruptMode(intSourceMask)
uint32  PSoC5_SpiUartDisableIntRx(void);
uint32  PSoC5_SpiUartDisableIntTx(void);


#endif /* (CY_SCB_SPI_UART_PVT_PSoC5_H) */


/* [] END OF FILE */
