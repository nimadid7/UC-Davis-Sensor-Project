/***************************************************************************//**
* \file .h
* \version 3.20
*
* \brief
*  This private file provides constants and parameter values for the
*  SCB Component.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* \copyright
* Copyright 2013-2016, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_PVT_PSoC5_H)
#define CY_SCB_PVT_PSoC5_H

#include "PSoC5.h"


/***************************************
*     Private Function Prototypes
***************************************/

/* APIs to service INTR_I2C_EC register */
#define PSoC5_SetI2CExtClkInterruptMode(interruptMask) PSoC5_WRITE_INTR_I2C_EC_MASK(interruptMask)
#define PSoC5_ClearI2CExtClkInterruptSource(interruptMask) PSoC5_CLEAR_INTR_I2C_EC(interruptMask)
#define PSoC5_GetI2CExtClkInterruptSource()                (PSoC5_INTR_I2C_EC_REG)
#define PSoC5_GetI2CExtClkInterruptMode()                  (PSoC5_INTR_I2C_EC_MASK_REG)
#define PSoC5_GetI2CExtClkInterruptSourceMasked()          (PSoC5_INTR_I2C_EC_MASKED_REG)

#if (!PSoC5_CY_SCBIP_V1)
    /* APIs to service INTR_SPI_EC register */
    #define PSoC5_SetSpiExtClkInterruptMode(interruptMask) \
                                                                PSoC5_WRITE_INTR_SPI_EC_MASK(interruptMask)
    #define PSoC5_ClearSpiExtClkInterruptSource(interruptMask) \
                                                                PSoC5_CLEAR_INTR_SPI_EC(interruptMask)
    #define PSoC5_GetExtSpiClkInterruptSource()                 (PSoC5_INTR_SPI_EC_REG)
    #define PSoC5_GetExtSpiClkInterruptMode()                   (PSoC5_INTR_SPI_EC_MASK_REG)
    #define PSoC5_GetExtSpiClkInterruptSourceMasked()           (PSoC5_INTR_SPI_EC_MASKED_REG)
#endif /* (!PSoC5_CY_SCBIP_V1) */

#if(PSoC5_SCB_MODE_UNCONFIG_CONST_CFG)
    extern void PSoC5_SetPins(uint32 mode, uint32 subMode, uint32 uartEnableMask);
#endif /* (PSoC5_SCB_MODE_UNCONFIG_CONST_CFG) */


/***************************************
*     Vars with External Linkage
***************************************/

#if (PSoC5_SCB_IRQ_INTERNAL)
#if !defined (CY_REMOVE_PSoC5_CUSTOM_INTR_HANDLER)
    extern cyisraddress PSoC5_customIntrHandler;
#endif /* !defined (CY_REMOVE_PSoC5_CUSTOM_INTR_HANDLER) */
#endif /* (PSoC5_SCB_IRQ_INTERNAL) */

extern PSoC5_BACKUP_STRUCT PSoC5_backup;

#if(PSoC5_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Common configuration variables */
    extern uint8 PSoC5_scbMode;
    extern uint8 PSoC5_scbEnableWake;
    extern uint8 PSoC5_scbEnableIntr;

    /* I2C configuration variables */
    extern uint8 PSoC5_mode;
    extern uint8 PSoC5_acceptAddr;

    /* SPI/UART configuration variables */
    extern volatile uint8 * PSoC5_rxBuffer;
    extern uint8   PSoC5_rxDataBits;
    extern uint32  PSoC5_rxBufferSize;

    extern volatile uint8 * PSoC5_txBuffer;
    extern uint8   PSoC5_txDataBits;
    extern uint32  PSoC5_txBufferSize;

    /* EZI2C configuration variables */
    extern uint8 PSoC5_numberOfAddr;
    extern uint8 PSoC5_subAddrSize;
#endif /* (PSoC5_SCB_MODE_UNCONFIG_CONST_CFG) */

#if (! (PSoC5_SCB_MODE_I2C_CONST_CFG || \
        PSoC5_SCB_MODE_EZI2C_CONST_CFG))
    extern uint16 PSoC5_IntrTxMask;
#endif /* (! (PSoC5_SCB_MODE_I2C_CONST_CFG || \
              PSoC5_SCB_MODE_EZI2C_CONST_CFG)) */


/***************************************
*        Conditional Macro
****************************************/

#if(PSoC5_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Defines run time operation mode */
    #define PSoC5_SCB_MODE_I2C_RUNTM_CFG     (PSoC5_SCB_MODE_I2C      == PSoC5_scbMode)
    #define PSoC5_SCB_MODE_SPI_RUNTM_CFG     (PSoC5_SCB_MODE_SPI      == PSoC5_scbMode)
    #define PSoC5_SCB_MODE_UART_RUNTM_CFG    (PSoC5_SCB_MODE_UART     == PSoC5_scbMode)
    #define PSoC5_SCB_MODE_EZI2C_RUNTM_CFG   (PSoC5_SCB_MODE_EZI2C    == PSoC5_scbMode)
    #define PSoC5_SCB_MODE_UNCONFIG_RUNTM_CFG \
                                                        (PSoC5_SCB_MODE_UNCONFIG == PSoC5_scbMode)

    /* Defines wakeup enable */
    #define PSoC5_SCB_WAKE_ENABLE_CHECK       (0u != PSoC5_scbEnableWake)
#endif /* (PSoC5_SCB_MODE_UNCONFIG_CONST_CFG) */

/* Defines maximum number of SCB pins */
#if (!PSoC5_CY_SCBIP_V1)
    #define PSoC5_SCB_PINS_NUMBER    (7u)
#else
    #define PSoC5_SCB_PINS_NUMBER    (2u)
#endif /* (!PSoC5_CY_SCBIP_V1) */

#endif /* (CY_SCB_PVT_PSoC5_H) */


/* [] END OF FILE */
