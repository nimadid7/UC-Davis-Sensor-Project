/*
UC Davis RMI Sensor Project
Main file for PRoC BLE module
Written by Nick Madrid
*/

#include <project.h>

#define TRUE    1
#define FALSE   0
#define ZERO    0
#define CCCD_NTF_BIT_MASK   0x01
#define CCC_DATA_LEN    2

void ProcessBLEEvents();
void CustomEventHandler(uint32 event, void*eventParam);
void SendDataOverNotification(uint8 randValue[10]);
void UpdateNotificationCCCD(void);

CYBLE_CONN_HANDLE_T connectionHandle; 

uint8 deviceConnected=FALSE; 
uint8 startNotification=FALSE;
uint8 restartAdvertisement=FALSE;
uint8 updateNotificationCCCAttribute=FALSE;
uint8 busyStatus=FALSE;
uint8 dataLength = 20;

uint8 timeArray[12];
uint8 timeReady = 0;

int main()
{
    CyGlobalIntEnable;
    PSoC5_Start();
    CyBle_Start(CustomEventHandler);

    // Get time data from the phone and send to the PSoC 5
    uint8 done = 0;
    while(done == 0) {
        ProcessBLEEvents();
        if (timeReady) {
            PSoC5_SpiUartPutArray(timeArray, 12);
            done = 1;
        }
    }
    CyDelay(1000);
    CySysPmStop();
    
    for(;;)
    {    
    }
}

void ProcessBLEEvents() {
    CyBle_ProcessEvents();
    
    if(restartAdvertisement)
    {
        restartAdvertisement = FALSE;
        CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
    }
}

void CustomEventHandler(uint32 event, void *eventParam)
{
    CYBLE_GATTS_WRITE_REQ_PARAM_T *wrReqParam;
    
    switch(event)
    {
        case CYBLE_EVT_STACK_ON:
			/* This event is received when component is Started */
			
			/* Set restartAdvertisement flag to allow calling Advertisement 
			* API from main function */
			restartAdvertisement = TRUE;
			
			break;
        
        case CYBLE_EVT_TIMEOUT:
			/* Event Handling for Timeout  */
		
			break;
        
        case CYBLE_EVT_GAPP_ADVERTISEMENT_START_STOP:
			
			if(CyBle_GetState() == CYBLE_STATE_DISCONNECTED)
			{
				/* Set restartAdvertisement flag to allow calling Advertisement 
				* API from main function */
				restartAdvertisement = TRUE;
			}
			break;
            
        case CYBLE_EVT_GAP_DEVICE_CONNECTED:		
			/* This event is received when device is connected over GAP layer */
   
			break;
            
        case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:		
			/* This event is received when device is disconnected */
			
			/* Set restartAdvertisement flag to allow calling Advertisement 
			* API from main function */
			restartAdvertisement = TRUE;

            break;
            
        case CYBLE_EVT_GATT_CONNECT_IND:
			/* This event is received when device is connected over GATT level */
			
			/* Update attribute handle on GATT Connection*/
            connectionHandle = *(CYBLE_CONN_HANDLE_T *)eventParam;	

			/* This flag is used in application to check connection status */
			deviceConnected = TRUE;	
            
            break;
            
        case CYBLE_EVT_GATT_DISCONNECT_IND:	
			/*This event is received when device is disconnected. 
			* Update connection flag accordingly */
			deviceConnected = FALSE;
			
			/* Reset notification flag to prevent further notifications
			 * being sent to Central device after next connection. */
			startNotification = FALSE;

			/* Reset the CCCD value to disable notifications */
			updateNotificationCCCAttribute = TRUE;
			UpdateNotificationCCCD();
			
			/* Reset the isConnectionUpdateRequested flag to allow sending
			* connection parameter update request in next connection */
			//isConnectionUpdateRequested = TRUE;
			break; 
            
        case CYBLE_EVT_GATTS_WRITE_REQ:				
			/*When this event is triggered, the peripheral has received 
			* a write command on the custom characteristic */
			
            wrReqParam = (CYBLE_GATTS_WRITE_REQ_PARAM_T *) eventParam;
			
			/* If the returned handle matches the custom configuration, store the time data */
            if(CYBLE_CUSTOM_SERVICE_CUSTOM_CHARACTERISTIC_2_CHAR_HANDLE  == wrReqParam->handleValPair.attrHandle)
            {
                timeArray[0] = wrReqParam->handleValPair.value.val[0];
                timeArray[1] = wrReqParam->handleValPair.value.val[1];
                timeArray[2] = wrReqParam->handleValPair.value.val[2];
                timeArray[3] = wrReqParam->handleValPair.value.val[3];
                timeArray[4] = wrReqParam->handleValPair.value.val[4];
                timeArray[5] = wrReqParam->handleValPair.value.val[5];
                timeArray[6] = wrReqParam->handleValPair.value.val[6];
                timeArray[7] = wrReqParam->handleValPair.value.val[7];
                timeArray[8] = wrReqParam->handleValPair.value.val[8];
                timeArray[9] = wrReqParam->handleValPair.value.val[9];
                timeArray[10] = wrReqParam->handleValPair.value.val[10];
                timeArray[11] = wrReqParam->handleValPair.value.val[11];
                timeReady = 1;
			}
            if(CYBLE_CUSTOM_SERVICE_CUSTOM_CHARACTERISTIC_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_HANDLE == wrReqParam->handleValPair.attrHandle)
            {
                /* Set flag so that application can start sending notifications.*/
    			startNotification = wrReqParam->handleValPair.value.val[CYBLE_CUSTOM_SERVICE_CUSTOM_CHARACTERISTIC_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_INDEX];

				/* Set flag to allow CCCD to be updated for next read operation */
				updateNotificationCCCAttribute = TRUE;
			}
            CyBle_GattsWriteRsp(connectionHandle);
            
            break;
            
     case CYBLE_EVT_STACK_BUSY_STATUS:
			/* This event is generated when the internal stack buffer is full and no more
			* data can be accepted or the stack has buffer available and can accept data.
			* This event is used by application to prevent pushing lot of data to stack. */
			
			/* Extract the present stack status */
            busyStatus = * (uint8*)eventParam;
            break;
            
        default:
                        
            break;
            
    }
}


void SendDataOverNotification(uint8 inputArray[dataLength])
{
	/* 'notificationHandle' is handle to store notification data parameters */
	CYBLE_GATTS_HANDLE_VALUE_NTF_T		notificationHandle; 
	
	/* If stack is not busy, then send the notification */
	if(busyStatus == CYBLE_STACK_STATE_FREE)
    {
		/* Update Notification handle with sensor data */
		notificationHandle.attrHandle = CYBLE_CUSTOM_SERVICE_CUSTOM_CHARACTERISTIC_CHAR_HANDLE;				
		notificationHandle.value.val = inputArray;
		notificationHandle.value.len = dataLength;
		
		// Report data to BLE component for sending data by notifications*/
		CyBle_GattsNotification(connectionHandle,&notificationHandle);
	}
}

void UpdateNotificationCCCD(void)
{
	/* Local variable to store the current CCCD value */
	uint8 CCCDvalue[2];
	
	/* Handle value to update the CCCD */	
    CYBLE_GATT_HANDLE_VALUE_PAIR_T notificationCCCDhandle;

	/* Update notification attribute only when there has been change */
	if(updateNotificationCCCAttribute)
    {
		updateNotificationCCCAttribute = FALSE;
	
		/* Write the present notification status to the local variable */
		CCCDvalue[0] = startNotification;
		CCCDvalue[1] = 0x00;
		
		/* Update CCCD handle with notification status data*/
		notificationCCCDhandle.attrHandle = CYBLE_CUSTOM_SERVICE_CUSTOM_CHARACTERISTIC_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_HANDLE;
		notificationCCCDhandle.value.val = CCCDvalue;
		notificationCCCDhandle.value.len = CCC_DATA_LEN;
		
		/* Report data to BLE component for sending data when read by Central device */
		CyBle_GattsWriteAttributeValue(&notificationCCCDhandle, ZERO, &connectionHandle, CYBLE_GATT_DB_LOCALLY_INITIATED);
        CyBle_GattsReadAttributeValue(&notificationCCCDhandle, &connectionHandle, CYBLE_GATT_DB_LOCALLY_INITIATED);

	}	
}
/* [] END OF FILE */
