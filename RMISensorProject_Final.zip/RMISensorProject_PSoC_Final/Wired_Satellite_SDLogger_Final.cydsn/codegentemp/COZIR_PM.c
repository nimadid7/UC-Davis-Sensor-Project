/*******************************************************************************
* File Name: COZIR_PM.c
* Version 2.50
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "COZIR.h"


/***************************************
* Local data allocation
***************************************/

static COZIR_BACKUP_STRUCT  COZIR_backup =
{
    /* enableState - disabled */
    0u,
};



/*******************************************************************************
* Function Name: COZIR_SaveConfig
********************************************************************************
*
* Summary:
*  This function saves the component nonretention control register.
*  Does not save the FIFO which is a set of nonretention registers.
*  This function is called by the COZIR_Sleep() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  COZIR_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void COZIR_SaveConfig(void)
{
    #if(COZIR_CONTROL_REG_REMOVED == 0u)
        COZIR_backup.cr = COZIR_CONTROL_REG;
    #endif /* End COZIR_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: COZIR_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the nonretention control register except FIFO.
*  Does not restore the FIFO which is a set of nonretention registers.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  COZIR_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
* Notes:
*  If this function is called without calling COZIR_SaveConfig() 
*  first, the data loaded may be incorrect.
*
*******************************************************************************/
void COZIR_RestoreConfig(void)
{
    #if(COZIR_CONTROL_REG_REMOVED == 0u)
        COZIR_CONTROL_REG = COZIR_backup.cr;
    #endif /* End COZIR_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: COZIR_Sleep
********************************************************************************
*
* Summary:
*  This is the preferred API to prepare the component for sleep. 
*  The COZIR_Sleep() API saves the current component state. Then it
*  calls the COZIR_Stop() function and calls 
*  COZIR_SaveConfig() to save the hardware configuration.
*  Call the COZIR_Sleep() function before calling the CyPmSleep() 
*  or the CyPmHibernate() function. 
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  COZIR_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void COZIR_Sleep(void)
{
    #if(COZIR_RX_ENABLED || COZIR_HD_ENABLED)
        if((COZIR_RXSTATUS_ACTL_REG  & COZIR_INT_ENABLE) != 0u)
        {
            COZIR_backup.enableState = 1u;
        }
        else
        {
            COZIR_backup.enableState = 0u;
        }
    #else
        if((COZIR_TXSTATUS_ACTL_REG  & COZIR_INT_ENABLE) !=0u)
        {
            COZIR_backup.enableState = 1u;
        }
        else
        {
            COZIR_backup.enableState = 0u;
        }
    #endif /* End COZIR_RX_ENABLED || COZIR_HD_ENABLED*/

    COZIR_Stop();
    COZIR_SaveConfig();
}


/*******************************************************************************
* Function Name: COZIR_Wakeup
********************************************************************************
*
* Summary:
*  This is the preferred API to restore the component to the state when 
*  COZIR_Sleep() was called. The COZIR_Wakeup() function
*  calls the COZIR_RestoreConfig() function to restore the 
*  configuration. If the component was enabled before the 
*  COZIR_Sleep() function was called, the COZIR_Wakeup()
*  function will also re-enable the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  COZIR_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void COZIR_Wakeup(void)
{
    COZIR_RestoreConfig();
    #if( (COZIR_RX_ENABLED) || (COZIR_HD_ENABLED) )
        COZIR_ClearRxBuffer();
    #endif /* End (COZIR_RX_ENABLED) || (COZIR_HD_ENABLED) */
    #if(COZIR_TX_ENABLED || COZIR_HD_ENABLED)
        COZIR_ClearTxBuffer();
    #endif /* End COZIR_TX_ENABLED || COZIR_HD_ENABLED */

    if(COZIR_backup.enableState != 0u)
    {
        COZIR_Enable();
    }
}


/* [] END OF FILE */
