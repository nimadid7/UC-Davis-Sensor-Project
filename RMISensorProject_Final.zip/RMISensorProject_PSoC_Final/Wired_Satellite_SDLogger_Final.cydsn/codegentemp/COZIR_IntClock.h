/*******************************************************************************
* File Name: COZIR_IntClock.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_COZIR_IntClock_H)
#define CY_CLOCK_COZIR_IntClock_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void COZIR_IntClock_Start(void) ;
void COZIR_IntClock_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void COZIR_IntClock_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void COZIR_IntClock_StandbyPower(uint8 state) ;
void COZIR_IntClock_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 COZIR_IntClock_GetDividerRegister(void) ;
void COZIR_IntClock_SetModeRegister(uint8 modeBitMask) ;
void COZIR_IntClock_ClearModeRegister(uint8 modeBitMask) ;
uint8 COZIR_IntClock_GetModeRegister(void) ;
void COZIR_IntClock_SetSourceRegister(uint8 clkSource) ;
uint8 COZIR_IntClock_GetSourceRegister(void) ;
#if defined(COZIR_IntClock__CFG3)
void COZIR_IntClock_SetPhaseRegister(uint8 clkPhase) ;
uint8 COZIR_IntClock_GetPhaseRegister(void) ;
#endif /* defined(COZIR_IntClock__CFG3) */

#define COZIR_IntClock_Enable()                       COZIR_IntClock_Start()
#define COZIR_IntClock_Disable()                      COZIR_IntClock_Stop()
#define COZIR_IntClock_SetDivider(clkDivider)         COZIR_IntClock_SetDividerRegister(clkDivider, 1u)
#define COZIR_IntClock_SetDividerValue(clkDivider)    COZIR_IntClock_SetDividerRegister((clkDivider) - 1u, 1u)
#define COZIR_IntClock_SetMode(clkMode)               COZIR_IntClock_SetModeRegister(clkMode)
#define COZIR_IntClock_SetSource(clkSource)           COZIR_IntClock_SetSourceRegister(clkSource)
#if defined(COZIR_IntClock__CFG3)
#define COZIR_IntClock_SetPhase(clkPhase)             COZIR_IntClock_SetPhaseRegister(clkPhase)
#define COZIR_IntClock_SetPhaseValue(clkPhase)        COZIR_IntClock_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(COZIR_IntClock__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define COZIR_IntClock_CLKEN              (* (reg8 *) COZIR_IntClock__PM_ACT_CFG)
#define COZIR_IntClock_CLKEN_PTR          ((reg8 *) COZIR_IntClock__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define COZIR_IntClock_CLKSTBY            (* (reg8 *) COZIR_IntClock__PM_STBY_CFG)
#define COZIR_IntClock_CLKSTBY_PTR        ((reg8 *) COZIR_IntClock__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define COZIR_IntClock_DIV_LSB            (* (reg8 *) COZIR_IntClock__CFG0)
#define COZIR_IntClock_DIV_LSB_PTR        ((reg8 *) COZIR_IntClock__CFG0)
#define COZIR_IntClock_DIV_PTR            ((reg16 *) COZIR_IntClock__CFG0)

/* Clock MSB divider configuration register. */
#define COZIR_IntClock_DIV_MSB            (* (reg8 *) COZIR_IntClock__CFG1)
#define COZIR_IntClock_DIV_MSB_PTR        ((reg8 *) COZIR_IntClock__CFG1)

/* Mode and source configuration register */
#define COZIR_IntClock_MOD_SRC            (* (reg8 *) COZIR_IntClock__CFG2)
#define COZIR_IntClock_MOD_SRC_PTR        ((reg8 *) COZIR_IntClock__CFG2)

#if defined(COZIR_IntClock__CFG3)
/* Analog clock phase configuration register */
#define COZIR_IntClock_PHASE              (* (reg8 *) COZIR_IntClock__CFG3)
#define COZIR_IntClock_PHASE_PTR          ((reg8 *) COZIR_IntClock__CFG3)
#endif /* defined(COZIR_IntClock__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define COZIR_IntClock_CLKEN_MASK         COZIR_IntClock__PM_ACT_MSK
#define COZIR_IntClock_CLKSTBY_MASK       COZIR_IntClock__PM_STBY_MSK

/* CFG2 field masks */
#define COZIR_IntClock_SRC_SEL_MSK        COZIR_IntClock__CFG2_SRC_SEL_MASK
#define COZIR_IntClock_MODE_MASK          (~(COZIR_IntClock_SRC_SEL_MSK))

#if defined(COZIR_IntClock__CFG3)
/* CFG3 phase mask */
#define COZIR_IntClock_PHASE_MASK         COZIR_IntClock__CFG3_PHASE_DLY_MASK
#endif /* defined(COZIR_IntClock__CFG3) */

#endif /* CY_CLOCK_COZIR_IntClock_H */


/* [] END OF FILE */
