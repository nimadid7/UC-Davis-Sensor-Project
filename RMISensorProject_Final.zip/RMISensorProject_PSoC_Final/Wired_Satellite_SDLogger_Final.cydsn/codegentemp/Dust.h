/*******************************************************************************
* File Name: Dust.h
* Version 2.50
*
* Description:
*  Contains the function prototypes and constants available to the UART
*  user module.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/


#if !defined(CY_UART_Dust_H)
#define CY_UART_Dust_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CyLib.h"


/***************************************
* Conditional Compilation Parameters
***************************************/

#define Dust_RX_ENABLED                     (1u)
#define Dust_TX_ENABLED                     (0u)
#define Dust_HD_ENABLED                     (0u)
#define Dust_RX_INTERRUPT_ENABLED           (0u)
#define Dust_TX_INTERRUPT_ENABLED           (0u)
#define Dust_INTERNAL_CLOCK_USED            (1u)
#define Dust_RXHW_ADDRESS_ENABLED           (0u)
#define Dust_OVER_SAMPLE_COUNT              (8u)
#define Dust_PARITY_TYPE                    (0u)
#define Dust_PARITY_TYPE_SW                 (0u)
#define Dust_BREAK_DETECT                   (0u)
#define Dust_BREAK_BITS_TX                  (13u)
#define Dust_BREAK_BITS_RX                  (13u)
#define Dust_TXCLKGEN_DP                    (1u)
#define Dust_USE23POLLING                   (1u)
#define Dust_FLOW_CONTROL                   (0u)
#define Dust_CLK_FREQ                       (0u)
#define Dust_TX_BUFFER_SIZE                 (4u)
#define Dust_RX_BUFFER_SIZE                 (4u)

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component UART_v2_50 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */

#if defined(Dust_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG)
    #define Dust_CONTROL_REG_REMOVED            (0u)
#else
    #define Dust_CONTROL_REG_REMOVED            (1u)
#endif /* End Dust_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */


/***************************************
*      Data Structure Definition
***************************************/

/* Sleep Mode API Support */
typedef struct Dust_backupStruct_
{
    uint8 enableState;

    #if(Dust_CONTROL_REG_REMOVED == 0u)
        uint8 cr;
    #endif /* End Dust_CONTROL_REG_REMOVED */

} Dust_BACKUP_STRUCT;


/***************************************
*       Function Prototypes
***************************************/

void Dust_Start(void) ;
void Dust_Stop(void) ;
uint8 Dust_ReadControlRegister(void) ;
void Dust_WriteControlRegister(uint8 control) ;

void Dust_Init(void) ;
void Dust_Enable(void) ;
void Dust_SaveConfig(void) ;
void Dust_RestoreConfig(void) ;
void Dust_Sleep(void) ;
void Dust_Wakeup(void) ;

/* Only if RX is enabled */
#if( (Dust_RX_ENABLED) || (Dust_HD_ENABLED) )

    #if (Dust_RX_INTERRUPT_ENABLED)
        #define Dust_EnableRxInt()  CyIntEnable (Dust_RX_VECT_NUM)
        #define Dust_DisableRxInt() CyIntDisable(Dust_RX_VECT_NUM)
        CY_ISR_PROTO(Dust_RXISR);
    #endif /* Dust_RX_INTERRUPT_ENABLED */

    void Dust_SetRxAddressMode(uint8 addressMode)
                                                           ;
    void Dust_SetRxAddress1(uint8 address) ;
    void Dust_SetRxAddress2(uint8 address) ;

    void  Dust_SetRxInterruptMode(uint8 intSrc) ;
    uint8 Dust_ReadRxData(void) ;
    uint8 Dust_ReadRxStatus(void) ;
    uint8 Dust_GetChar(void) ;
    uint16 Dust_GetByte(void) ;
    uint8 Dust_GetRxBufferSize(void)
                                                            ;
    void Dust_ClearRxBuffer(void) ;

    /* Obsolete functions, defines for backward compatible */
    #define Dust_GetRxInterruptSource   Dust_ReadRxStatus

#endif /* End (Dust_RX_ENABLED) || (Dust_HD_ENABLED) */

/* Only if TX is enabled */
#if(Dust_TX_ENABLED || Dust_HD_ENABLED)

    #if(Dust_TX_INTERRUPT_ENABLED)
        #define Dust_EnableTxInt()  CyIntEnable (Dust_TX_VECT_NUM)
        #define Dust_DisableTxInt() CyIntDisable(Dust_TX_VECT_NUM)
        #define Dust_SetPendingTxInt() CyIntSetPending(Dust_TX_VECT_NUM)
        #define Dust_ClearPendingTxInt() CyIntClearPending(Dust_TX_VECT_NUM)
        CY_ISR_PROTO(Dust_TXISR);
    #endif /* Dust_TX_INTERRUPT_ENABLED */

    void Dust_SetTxInterruptMode(uint8 intSrc) ;
    void Dust_WriteTxData(uint8 txDataByte) ;
    uint8 Dust_ReadTxStatus(void) ;
    void Dust_PutChar(uint8 txDataByte) ;
    void Dust_PutString(const char8 string[]) ;
    void Dust_PutArray(const uint8 string[], uint8 byteCount)
                                                            ;
    void Dust_PutCRLF(uint8 txDataByte) ;
    void Dust_ClearTxBuffer(void) ;
    void Dust_SetTxAddressMode(uint8 addressMode) ;
    void Dust_SendBreak(uint8 retMode) ;
    uint8 Dust_GetTxBufferSize(void)
                                                            ;
    /* Obsolete functions, defines for backward compatible */
    #define Dust_PutStringConst         Dust_PutString
    #define Dust_PutArrayConst          Dust_PutArray
    #define Dust_GetTxInterruptSource   Dust_ReadTxStatus

#endif /* End Dust_TX_ENABLED || Dust_HD_ENABLED */

#if(Dust_HD_ENABLED)
    void Dust_LoadRxConfig(void) ;
    void Dust_LoadTxConfig(void) ;
#endif /* End Dust_HD_ENABLED */


/* Communication bootloader APIs */
#if defined(CYDEV_BOOTLOADER_IO_COMP) && ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Dust) || \
                                          (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))
    /* Physical layer functions */
    void    Dust_CyBtldrCommStart(void) CYSMALL ;
    void    Dust_CyBtldrCommStop(void) CYSMALL ;
    void    Dust_CyBtldrCommReset(void) CYSMALL ;
    cystatus Dust_CyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;
    cystatus Dust_CyBtldrCommRead(uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;

    #if (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Dust)
        #define CyBtldrCommStart    Dust_CyBtldrCommStart
        #define CyBtldrCommStop     Dust_CyBtldrCommStop
        #define CyBtldrCommReset    Dust_CyBtldrCommReset
        #define CyBtldrCommWrite    Dust_CyBtldrCommWrite
        #define CyBtldrCommRead     Dust_CyBtldrCommRead
    #endif  /* (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Dust) */

    /* Byte to Byte time out for detecting end of block data from host */
    #define Dust_BYTE2BYTE_TIME_OUT (25u)
    #define Dust_PACKET_EOP         (0x17u) /* End of packet defined by bootloader */
    #define Dust_WAIT_EOP_DELAY     (5u)    /* Additional 5ms to wait for End of packet */
    #define Dust_BL_CHK_DELAY_MS    (1u)    /* Time Out quantity equal 1mS */

#endif /* CYDEV_BOOTLOADER_IO_COMP */


/***************************************
*          API Constants
***************************************/
/* Parameters for SetTxAddressMode API*/
#define Dust_SET_SPACE      (0x00u)
#define Dust_SET_MARK       (0x01u)

/* Status Register definitions */
#if( (Dust_TX_ENABLED) || (Dust_HD_ENABLED) )
    #if(Dust_TX_INTERRUPT_ENABLED)
        #define Dust_TX_VECT_NUM            (uint8)Dust_TXInternalInterrupt__INTC_NUMBER
        #define Dust_TX_PRIOR_NUM           (uint8)Dust_TXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* Dust_TX_INTERRUPT_ENABLED */

    #define Dust_TX_STS_COMPLETE_SHIFT          (0x00u)
    #define Dust_TX_STS_FIFO_EMPTY_SHIFT        (0x01u)
    #define Dust_TX_STS_FIFO_NOT_FULL_SHIFT     (0x03u)
    #if(Dust_TX_ENABLED)
        #define Dust_TX_STS_FIFO_FULL_SHIFT     (0x02u)
    #else /* (Dust_HD_ENABLED) */
        #define Dust_TX_STS_FIFO_FULL_SHIFT     (0x05u)  /* Needs MD=0 */
    #endif /* (Dust_TX_ENABLED) */

    #define Dust_TX_STS_COMPLETE            (uint8)(0x01u << Dust_TX_STS_COMPLETE_SHIFT)
    #define Dust_TX_STS_FIFO_EMPTY          (uint8)(0x01u << Dust_TX_STS_FIFO_EMPTY_SHIFT)
    #define Dust_TX_STS_FIFO_FULL           (uint8)(0x01u << Dust_TX_STS_FIFO_FULL_SHIFT)
    #define Dust_TX_STS_FIFO_NOT_FULL       (uint8)(0x01u << Dust_TX_STS_FIFO_NOT_FULL_SHIFT)
#endif /* End (Dust_TX_ENABLED) || (Dust_HD_ENABLED)*/

#if( (Dust_RX_ENABLED) || (Dust_HD_ENABLED) )
    #if(Dust_RX_INTERRUPT_ENABLED)
        #define Dust_RX_VECT_NUM            (uint8)Dust_RXInternalInterrupt__INTC_NUMBER
        #define Dust_RX_PRIOR_NUM           (uint8)Dust_RXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* Dust_RX_INTERRUPT_ENABLED */
    #define Dust_RX_STS_MRKSPC_SHIFT            (0x00u)
    #define Dust_RX_STS_BREAK_SHIFT             (0x01u)
    #define Dust_RX_STS_PAR_ERROR_SHIFT         (0x02u)
    #define Dust_RX_STS_STOP_ERROR_SHIFT        (0x03u)
    #define Dust_RX_STS_OVERRUN_SHIFT           (0x04u)
    #define Dust_RX_STS_FIFO_NOTEMPTY_SHIFT     (0x05u)
    #define Dust_RX_STS_ADDR_MATCH_SHIFT        (0x06u)
    #define Dust_RX_STS_SOFT_BUFF_OVER_SHIFT    (0x07u)

    #define Dust_RX_STS_MRKSPC           (uint8)(0x01u << Dust_RX_STS_MRKSPC_SHIFT)
    #define Dust_RX_STS_BREAK            (uint8)(0x01u << Dust_RX_STS_BREAK_SHIFT)
    #define Dust_RX_STS_PAR_ERROR        (uint8)(0x01u << Dust_RX_STS_PAR_ERROR_SHIFT)
    #define Dust_RX_STS_STOP_ERROR       (uint8)(0x01u << Dust_RX_STS_STOP_ERROR_SHIFT)
    #define Dust_RX_STS_OVERRUN          (uint8)(0x01u << Dust_RX_STS_OVERRUN_SHIFT)
    #define Dust_RX_STS_FIFO_NOTEMPTY    (uint8)(0x01u << Dust_RX_STS_FIFO_NOTEMPTY_SHIFT)
    #define Dust_RX_STS_ADDR_MATCH       (uint8)(0x01u << Dust_RX_STS_ADDR_MATCH_SHIFT)
    #define Dust_RX_STS_SOFT_BUFF_OVER   (uint8)(0x01u << Dust_RX_STS_SOFT_BUFF_OVER_SHIFT)
    #define Dust_RX_HW_MASK                     (0x7Fu)
#endif /* End (Dust_RX_ENABLED) || (Dust_HD_ENABLED) */

/* Control Register definitions */
#define Dust_CTRL_HD_SEND_SHIFT                 (0x00u) /* 1 enable TX part in Half Duplex mode */
#define Dust_CTRL_HD_SEND_BREAK_SHIFT           (0x01u) /* 1 send BREAK signal in Half Duplez mode */
#define Dust_CTRL_MARK_SHIFT                    (0x02u) /* 1 sets mark, 0 sets space */
#define Dust_CTRL_PARITY_TYPE0_SHIFT            (0x03u) /* Defines the type of parity implemented */
#define Dust_CTRL_PARITY_TYPE1_SHIFT            (0x04u) /* Defines the type of parity implemented */
#define Dust_CTRL_RXADDR_MODE0_SHIFT            (0x05u)
#define Dust_CTRL_RXADDR_MODE1_SHIFT            (0x06u)
#define Dust_CTRL_RXADDR_MODE2_SHIFT            (0x07u)

#define Dust_CTRL_HD_SEND               (uint8)(0x01u << Dust_CTRL_HD_SEND_SHIFT)
#define Dust_CTRL_HD_SEND_BREAK         (uint8)(0x01u << Dust_CTRL_HD_SEND_BREAK_SHIFT)
#define Dust_CTRL_MARK                  (uint8)(0x01u << Dust_CTRL_MARK_SHIFT)
#define Dust_CTRL_PARITY_TYPE_MASK      (uint8)(0x03u << Dust_CTRL_PARITY_TYPE0_SHIFT)
#define Dust_CTRL_RXADDR_MODE_MASK      (uint8)(0x07u << Dust_CTRL_RXADDR_MODE0_SHIFT)

/* StatusI Register Interrupt Enable Control Bits. As defined by the Register map for the AUX Control Register */
#define Dust_INT_ENABLE                         (0x10u)

/* Bit Counter (7-bit) Control Register Bit Definitions. As defined by the Register map for the AUX Control Register */
#define Dust_CNTR_ENABLE                        (0x20u)

/*   Constants for SendBreak() "retMode" parameter  */
#define Dust_SEND_BREAK                         (0x00u)
#define Dust_WAIT_FOR_COMPLETE_REINIT           (0x01u)
#define Dust_REINIT                             (0x02u)
#define Dust_SEND_WAIT_REINIT                   (0x03u)

#define Dust_OVER_SAMPLE_8                      (8u)
#define Dust_OVER_SAMPLE_16                     (16u)

#define Dust_BIT_CENTER                         (Dust_OVER_SAMPLE_COUNT - 2u)

#define Dust_FIFO_LENGTH                        (4u)
#define Dust_NUMBER_OF_START_BIT                (1u)
#define Dust_MAX_BYTE_VALUE                     (0xFFu)

/* 8X always for count7 implementation */
#define Dust_TXBITCTR_BREAKBITS8X   ((Dust_BREAK_BITS_TX * Dust_OVER_SAMPLE_8) - 1u)
/* 8X or 16X for DP implementation */
#define Dust_TXBITCTR_BREAKBITS ((Dust_BREAK_BITS_TX * Dust_OVER_SAMPLE_COUNT) - 1u)

#define Dust_HALF_BIT_COUNT   \
                            (((Dust_OVER_SAMPLE_COUNT / 2u) + (Dust_USE23POLLING * 1u)) - 2u)
#if (Dust_OVER_SAMPLE_COUNT == Dust_OVER_SAMPLE_8)
    #define Dust_HD_TXBITCTR_INIT   (((Dust_BREAK_BITS_TX + \
                            Dust_NUMBER_OF_START_BIT) * Dust_OVER_SAMPLE_COUNT) - 1u)

    /* This parameter is increased on the 2 in 2 out of 3 mode to sample voting in the middle */
    #define Dust_RXBITCTR_INIT  ((((Dust_BREAK_BITS_RX + Dust_NUMBER_OF_START_BIT) \
                            * Dust_OVER_SAMPLE_COUNT) + Dust_HALF_BIT_COUNT) - 1u)

#else /* Dust_OVER_SAMPLE_COUNT == Dust_OVER_SAMPLE_16 */
    #define Dust_HD_TXBITCTR_INIT   ((8u * Dust_OVER_SAMPLE_COUNT) - 1u)
    /* 7bit counter need one more bit for OverSampleCount = 16 */
    #define Dust_RXBITCTR_INIT      (((7u * Dust_OVER_SAMPLE_COUNT) - 1u) + \
                                                      Dust_HALF_BIT_COUNT)
#endif /* End Dust_OVER_SAMPLE_COUNT */

#define Dust_HD_RXBITCTR_INIT                   Dust_RXBITCTR_INIT


/***************************************
* Global variables external identifier
***************************************/

extern uint8 Dust_initVar;
#if (Dust_TX_INTERRUPT_ENABLED && Dust_TX_ENABLED)
    extern volatile uint8 Dust_txBuffer[Dust_TX_BUFFER_SIZE];
    extern volatile uint8 Dust_txBufferRead;
    extern uint8 Dust_txBufferWrite;
#endif /* (Dust_TX_INTERRUPT_ENABLED && Dust_TX_ENABLED) */
#if (Dust_RX_INTERRUPT_ENABLED && (Dust_RX_ENABLED || Dust_HD_ENABLED))
    extern uint8 Dust_errorStatus;
    extern volatile uint8 Dust_rxBuffer[Dust_RX_BUFFER_SIZE];
    extern volatile uint8 Dust_rxBufferRead;
    extern volatile uint8 Dust_rxBufferWrite;
    extern volatile uint8 Dust_rxBufferLoopDetect;
    extern volatile uint8 Dust_rxBufferOverflow;
    #if (Dust_RXHW_ADDRESS_ENABLED)
        extern volatile uint8 Dust_rxAddressMode;
        extern volatile uint8 Dust_rxAddressDetected;
    #endif /* (Dust_RXHW_ADDRESS_ENABLED) */
#endif /* (Dust_RX_INTERRUPT_ENABLED && (Dust_RX_ENABLED || Dust_HD_ENABLED)) */


/***************************************
* Enumerated Types and Parameters
***************************************/

#define Dust__B_UART__AM_SW_BYTE_BYTE 1
#define Dust__B_UART__AM_SW_DETECT_TO_BUFFER 2
#define Dust__B_UART__AM_HW_BYTE_BY_BYTE 3
#define Dust__B_UART__AM_HW_DETECT_TO_BUFFER 4
#define Dust__B_UART__AM_NONE 0

#define Dust__B_UART__NONE_REVB 0
#define Dust__B_UART__EVEN_REVB 1
#define Dust__B_UART__ODD_REVB 2
#define Dust__B_UART__MARK_SPACE_REVB 3



/***************************************
*    Initial Parameter Constants
***************************************/

/* UART shifts max 8 bits, Mark/Space functionality working if 9 selected */
#define Dust_NUMBER_OF_DATA_BITS    ((8u > 8u) ? 8u : 8u)
#define Dust_NUMBER_OF_STOP_BITS    (1u)

#if (Dust_RXHW_ADDRESS_ENABLED)
    #define Dust_RX_ADDRESS_MODE    (0u)
    #define Dust_RX_HW_ADDRESS1     (0u)
    #define Dust_RX_HW_ADDRESS2     (0u)
#endif /* (Dust_RXHW_ADDRESS_ENABLED) */

#define Dust_INIT_RX_INTERRUPTS_MASK \
                                  (uint8)((1 << Dust_RX_STS_FIFO_NOTEMPTY_SHIFT) \
                                        | (0 << Dust_RX_STS_MRKSPC_SHIFT) \
                                        | (0 << Dust_RX_STS_ADDR_MATCH_SHIFT) \
                                        | (0 << Dust_RX_STS_PAR_ERROR_SHIFT) \
                                        | (0 << Dust_RX_STS_STOP_ERROR_SHIFT) \
                                        | (0 << Dust_RX_STS_BREAK_SHIFT) \
                                        | (0 << Dust_RX_STS_OVERRUN_SHIFT))

#define Dust_INIT_TX_INTERRUPTS_MASK \
                                  (uint8)((0 << Dust_TX_STS_COMPLETE_SHIFT) \
                                        | (0 << Dust_TX_STS_FIFO_EMPTY_SHIFT) \
                                        | (0 << Dust_TX_STS_FIFO_FULL_SHIFT) \
                                        | (0 << Dust_TX_STS_FIFO_NOT_FULL_SHIFT))


/***************************************
*              Registers
***************************************/

#ifdef Dust_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define Dust_CONTROL_REG \
                            (* (reg8 *) Dust_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
    #define Dust_CONTROL_PTR \
                            (  (reg8 *) Dust_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
#endif /* End Dust_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(Dust_TX_ENABLED)
    #define Dust_TXDATA_REG          (* (reg8 *) Dust_BUART_sTX_TxShifter_u0__F0_REG)
    #define Dust_TXDATA_PTR          (  (reg8 *) Dust_BUART_sTX_TxShifter_u0__F0_REG)
    #define Dust_TXDATA_AUX_CTL_REG  (* (reg8 *) Dust_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define Dust_TXDATA_AUX_CTL_PTR  (  (reg8 *) Dust_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define Dust_TXSTATUS_REG        (* (reg8 *) Dust_BUART_sTX_TxSts__STATUS_REG)
    #define Dust_TXSTATUS_PTR        (  (reg8 *) Dust_BUART_sTX_TxSts__STATUS_REG)
    #define Dust_TXSTATUS_MASK_REG   (* (reg8 *) Dust_BUART_sTX_TxSts__MASK_REG)
    #define Dust_TXSTATUS_MASK_PTR   (  (reg8 *) Dust_BUART_sTX_TxSts__MASK_REG)
    #define Dust_TXSTATUS_ACTL_REG   (* (reg8 *) Dust_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)
    #define Dust_TXSTATUS_ACTL_PTR   (  (reg8 *) Dust_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)

    /* DP clock */
    #if(Dust_TXCLKGEN_DP)
        #define Dust_TXBITCLKGEN_CTR_REG        \
                                        (* (reg8 *) Dust_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define Dust_TXBITCLKGEN_CTR_PTR        \
                                        (  (reg8 *) Dust_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define Dust_TXBITCLKTX_COMPLETE_REG    \
                                        (* (reg8 *) Dust_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
        #define Dust_TXBITCLKTX_COMPLETE_PTR    \
                                        (  (reg8 *) Dust_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
    #else     /* Count7 clock*/
        #define Dust_TXBITCTR_PERIOD_REG    \
                                        (* (reg8 *) Dust_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define Dust_TXBITCTR_PERIOD_PTR    \
                                        (  (reg8 *) Dust_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define Dust_TXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) Dust_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define Dust_TXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) Dust_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define Dust_TXBITCTR_COUNTER_REG   \
                                        (* (reg8 *) Dust_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
        #define Dust_TXBITCTR_COUNTER_PTR   \
                                        (  (reg8 *) Dust_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
    #endif /* Dust_TXCLKGEN_DP */

#endif /* End Dust_TX_ENABLED */

#if(Dust_HD_ENABLED)

    #define Dust_TXDATA_REG             (* (reg8 *) Dust_BUART_sRX_RxShifter_u0__F1_REG )
    #define Dust_TXDATA_PTR             (  (reg8 *) Dust_BUART_sRX_RxShifter_u0__F1_REG )
    #define Dust_TXDATA_AUX_CTL_REG     (* (reg8 *) Dust_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)
    #define Dust_TXDATA_AUX_CTL_PTR     (  (reg8 *) Dust_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define Dust_TXSTATUS_REG           (* (reg8 *) Dust_BUART_sRX_RxSts__STATUS_REG )
    #define Dust_TXSTATUS_PTR           (  (reg8 *) Dust_BUART_sRX_RxSts__STATUS_REG )
    #define Dust_TXSTATUS_MASK_REG      (* (reg8 *) Dust_BUART_sRX_RxSts__MASK_REG )
    #define Dust_TXSTATUS_MASK_PTR      (  (reg8 *) Dust_BUART_sRX_RxSts__MASK_REG )
    #define Dust_TXSTATUS_ACTL_REG      (* (reg8 *) Dust_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define Dust_TXSTATUS_ACTL_PTR      (  (reg8 *) Dust_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End Dust_HD_ENABLED */

#if( (Dust_RX_ENABLED) || (Dust_HD_ENABLED) )
    #define Dust_RXDATA_REG             (* (reg8 *) Dust_BUART_sRX_RxShifter_u0__F0_REG )
    #define Dust_RXDATA_PTR             (  (reg8 *) Dust_BUART_sRX_RxShifter_u0__F0_REG )
    #define Dust_RXADDRESS1_REG         (* (reg8 *) Dust_BUART_sRX_RxShifter_u0__D0_REG )
    #define Dust_RXADDRESS1_PTR         (  (reg8 *) Dust_BUART_sRX_RxShifter_u0__D0_REG )
    #define Dust_RXADDRESS2_REG         (* (reg8 *) Dust_BUART_sRX_RxShifter_u0__D1_REG )
    #define Dust_RXADDRESS2_PTR         (  (reg8 *) Dust_BUART_sRX_RxShifter_u0__D1_REG )
    #define Dust_RXDATA_AUX_CTL_REG     (* (reg8 *) Dust_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define Dust_RXBITCTR_PERIOD_REG    (* (reg8 *) Dust_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define Dust_RXBITCTR_PERIOD_PTR    (  (reg8 *) Dust_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define Dust_RXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) Dust_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define Dust_RXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) Dust_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define Dust_RXBITCTR_COUNTER_REG   (* (reg8 *) Dust_BUART_sRX_RxBitCounter__COUNT_REG )
    #define Dust_RXBITCTR_COUNTER_PTR   (  (reg8 *) Dust_BUART_sRX_RxBitCounter__COUNT_REG )

    #define Dust_RXSTATUS_REG           (* (reg8 *) Dust_BUART_sRX_RxSts__STATUS_REG )
    #define Dust_RXSTATUS_PTR           (  (reg8 *) Dust_BUART_sRX_RxSts__STATUS_REG )
    #define Dust_RXSTATUS_MASK_REG      (* (reg8 *) Dust_BUART_sRX_RxSts__MASK_REG )
    #define Dust_RXSTATUS_MASK_PTR      (  (reg8 *) Dust_BUART_sRX_RxSts__MASK_REG )
    #define Dust_RXSTATUS_ACTL_REG      (* (reg8 *) Dust_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define Dust_RXSTATUS_ACTL_PTR      (  (reg8 *) Dust_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End  (Dust_RX_ENABLED) || (Dust_HD_ENABLED) */

#if(Dust_INTERNAL_CLOCK_USED)
    /* Register to enable or disable the digital clocks */
    #define Dust_INTCLOCK_CLKEN_REG     (* (reg8 *) Dust_IntClock__PM_ACT_CFG)
    #define Dust_INTCLOCK_CLKEN_PTR     (  (reg8 *) Dust_IntClock__PM_ACT_CFG)

    /* Clock mask for this clock. */
    #define Dust_INTCLOCK_CLKEN_MASK    Dust_IntClock__PM_ACT_MSK
#endif /* End Dust_INTERNAL_CLOCK_USED */


/***************************************
*       Register Constants
***************************************/

#if(Dust_TX_ENABLED)
    #define Dust_TX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End Dust_TX_ENABLED */

#if(Dust_HD_ENABLED)
    #define Dust_TX_FIFO_CLR            (0x02u) /* FIFO1 CLR */
#endif /* End Dust_HD_ENABLED */

#if( (Dust_RX_ENABLED) || (Dust_HD_ENABLED) )
    #define Dust_RX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End  (Dust_RX_ENABLED) || (Dust_HD_ENABLED) */


/***************************************
* The following code is DEPRECATED and
* should not be used in new projects.
***************************************/

/* UART v2_40 obsolete definitions */
#define Dust_WAIT_1_MS      Dust_BL_CHK_DELAY_MS   

#define Dust_TXBUFFERSIZE   Dust_TX_BUFFER_SIZE
#define Dust_RXBUFFERSIZE   Dust_RX_BUFFER_SIZE

#if (Dust_RXHW_ADDRESS_ENABLED)
    #define Dust_RXADDRESSMODE  Dust_RX_ADDRESS_MODE
    #define Dust_RXHWADDRESS1   Dust_RX_HW_ADDRESS1
    #define Dust_RXHWADDRESS2   Dust_RX_HW_ADDRESS2
    /* Backward compatible define */
    #define Dust_RXAddressMode  Dust_RXADDRESSMODE
#endif /* (Dust_RXHW_ADDRESS_ENABLED) */

/* UART v2_30 obsolete definitions */
#define Dust_initvar                    Dust_initVar

#define Dust_RX_Enabled                 Dust_RX_ENABLED
#define Dust_TX_Enabled                 Dust_TX_ENABLED
#define Dust_HD_Enabled                 Dust_HD_ENABLED
#define Dust_RX_IntInterruptEnabled     Dust_RX_INTERRUPT_ENABLED
#define Dust_TX_IntInterruptEnabled     Dust_TX_INTERRUPT_ENABLED
#define Dust_InternalClockUsed          Dust_INTERNAL_CLOCK_USED
#define Dust_RXHW_Address_Enabled       Dust_RXHW_ADDRESS_ENABLED
#define Dust_OverSampleCount            Dust_OVER_SAMPLE_COUNT
#define Dust_ParityType                 Dust_PARITY_TYPE

#if( Dust_TX_ENABLED && (Dust_TXBUFFERSIZE > Dust_FIFO_LENGTH))
    #define Dust_TXBUFFER               Dust_txBuffer
    #define Dust_TXBUFFERREAD           Dust_txBufferRead
    #define Dust_TXBUFFERWRITE          Dust_txBufferWrite
#endif /* End Dust_TX_ENABLED */
#if( ( Dust_RX_ENABLED || Dust_HD_ENABLED ) && \
     (Dust_RXBUFFERSIZE > Dust_FIFO_LENGTH) )
    #define Dust_RXBUFFER               Dust_rxBuffer
    #define Dust_RXBUFFERREAD           Dust_rxBufferRead
    #define Dust_RXBUFFERWRITE          Dust_rxBufferWrite
    #define Dust_RXBUFFERLOOPDETECT     Dust_rxBufferLoopDetect
    #define Dust_RXBUFFER_OVERFLOW      Dust_rxBufferOverflow
#endif /* End Dust_RX_ENABLED */

#ifdef Dust_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define Dust_CONTROL                Dust_CONTROL_REG
#endif /* End Dust_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(Dust_TX_ENABLED)
    #define Dust_TXDATA                 Dust_TXDATA_REG
    #define Dust_TXSTATUS               Dust_TXSTATUS_REG
    #define Dust_TXSTATUS_MASK          Dust_TXSTATUS_MASK_REG
    #define Dust_TXSTATUS_ACTL          Dust_TXSTATUS_ACTL_REG
    /* DP clock */
    #if(Dust_TXCLKGEN_DP)
        #define Dust_TXBITCLKGEN_CTR        Dust_TXBITCLKGEN_CTR_REG
        #define Dust_TXBITCLKTX_COMPLETE    Dust_TXBITCLKTX_COMPLETE_REG
    #else     /* Count7 clock*/
        #define Dust_TXBITCTR_PERIOD        Dust_TXBITCTR_PERIOD_REG
        #define Dust_TXBITCTR_CONTROL       Dust_TXBITCTR_CONTROL_REG
        #define Dust_TXBITCTR_COUNTER       Dust_TXBITCTR_COUNTER_REG
    #endif /* Dust_TXCLKGEN_DP */
#endif /* End Dust_TX_ENABLED */

#if(Dust_HD_ENABLED)
    #define Dust_TXDATA                 Dust_TXDATA_REG
    #define Dust_TXSTATUS               Dust_TXSTATUS_REG
    #define Dust_TXSTATUS_MASK          Dust_TXSTATUS_MASK_REG
    #define Dust_TXSTATUS_ACTL          Dust_TXSTATUS_ACTL_REG
#endif /* End Dust_HD_ENABLED */

#if( (Dust_RX_ENABLED) || (Dust_HD_ENABLED) )
    #define Dust_RXDATA                 Dust_RXDATA_REG
    #define Dust_RXADDRESS1             Dust_RXADDRESS1_REG
    #define Dust_RXADDRESS2             Dust_RXADDRESS2_REG
    #define Dust_RXBITCTR_PERIOD        Dust_RXBITCTR_PERIOD_REG
    #define Dust_RXBITCTR_CONTROL       Dust_RXBITCTR_CONTROL_REG
    #define Dust_RXBITCTR_COUNTER       Dust_RXBITCTR_COUNTER_REG
    #define Dust_RXSTATUS               Dust_RXSTATUS_REG
    #define Dust_RXSTATUS_MASK          Dust_RXSTATUS_MASK_REG
    #define Dust_RXSTATUS_ACTL          Dust_RXSTATUS_ACTL_REG
#endif /* End  (Dust_RX_ENABLED) || (Dust_HD_ENABLED) */

#if(Dust_INTERNAL_CLOCK_USED)
    #define Dust_INTCLOCK_CLKEN         Dust_INTCLOCK_CLKEN_REG
#endif /* End Dust_INTERNAL_CLOCK_USED */

#define Dust_WAIT_FOR_COMLETE_REINIT    Dust_WAIT_FOR_COMPLETE_REINIT

#endif  /* CY_UART_Dust_H */


/* [] END OF FILE */
