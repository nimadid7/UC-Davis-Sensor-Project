/*******************************************************************************
* File Name: PSoC4.h
* Version 2.50
*
* Description:
*  Contains the function prototypes and constants available to the UART
*  user module.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/


#if !defined(CY_UART_PSoC4_H)
#define CY_UART_PSoC4_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CyLib.h"


/***************************************
* Conditional Compilation Parameters
***************************************/

#define PSoC4_RX_ENABLED                     (1u)
#define PSoC4_TX_ENABLED                     (1u)
#define PSoC4_HD_ENABLED                     (0u)
#define PSoC4_RX_INTERRUPT_ENABLED           (1u)
#define PSoC4_TX_INTERRUPT_ENABLED           (0u)
#define PSoC4_INTERNAL_CLOCK_USED            (1u)
#define PSoC4_RXHW_ADDRESS_ENABLED           (0u)
#define PSoC4_OVER_SAMPLE_COUNT              (8u)
#define PSoC4_PARITY_TYPE                    (0u)
#define PSoC4_PARITY_TYPE_SW                 (0u)
#define PSoC4_BREAK_DETECT                   (0u)
#define PSoC4_BREAK_BITS_TX                  (13u)
#define PSoC4_BREAK_BITS_RX                  (13u)
#define PSoC4_TXCLKGEN_DP                    (1u)
#define PSoC4_USE23POLLING                   (1u)
#define PSoC4_FLOW_CONTROL                   (0u)
#define PSoC4_CLK_FREQ                       (0u)
#define PSoC4_TX_BUFFER_SIZE                 (4u)
#define PSoC4_RX_BUFFER_SIZE                 (12u)

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component UART_v2_50 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */

#if defined(PSoC4_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG)
    #define PSoC4_CONTROL_REG_REMOVED            (0u)
#else
    #define PSoC4_CONTROL_REG_REMOVED            (1u)
#endif /* End PSoC4_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */


/***************************************
*      Data Structure Definition
***************************************/

/* Sleep Mode API Support */
typedef struct PSoC4_backupStruct_
{
    uint8 enableState;

    #if(PSoC4_CONTROL_REG_REMOVED == 0u)
        uint8 cr;
    #endif /* End PSoC4_CONTROL_REG_REMOVED */

} PSoC4_BACKUP_STRUCT;


/***************************************
*       Function Prototypes
***************************************/

void PSoC4_Start(void) ;
void PSoC4_Stop(void) ;
uint8 PSoC4_ReadControlRegister(void) ;
void PSoC4_WriteControlRegister(uint8 control) ;

void PSoC4_Init(void) ;
void PSoC4_Enable(void) ;
void PSoC4_SaveConfig(void) ;
void PSoC4_RestoreConfig(void) ;
void PSoC4_Sleep(void) ;
void PSoC4_Wakeup(void) ;

/* Only if RX is enabled */
#if( (PSoC4_RX_ENABLED) || (PSoC4_HD_ENABLED) )

    #if (PSoC4_RX_INTERRUPT_ENABLED)
        #define PSoC4_EnableRxInt()  CyIntEnable (PSoC4_RX_VECT_NUM)
        #define PSoC4_DisableRxInt() CyIntDisable(PSoC4_RX_VECT_NUM)
        CY_ISR_PROTO(PSoC4_RXISR);
    #endif /* PSoC4_RX_INTERRUPT_ENABLED */

    void PSoC4_SetRxAddressMode(uint8 addressMode)
                                                           ;
    void PSoC4_SetRxAddress1(uint8 address) ;
    void PSoC4_SetRxAddress2(uint8 address) ;

    void  PSoC4_SetRxInterruptMode(uint8 intSrc) ;
    uint8 PSoC4_ReadRxData(void) ;
    uint8 PSoC4_ReadRxStatus(void) ;
    uint8 PSoC4_GetChar(void) ;
    uint16 PSoC4_GetByte(void) ;
    uint8 PSoC4_GetRxBufferSize(void)
                                                            ;
    void PSoC4_ClearRxBuffer(void) ;

    /* Obsolete functions, defines for backward compatible */
    #define PSoC4_GetRxInterruptSource   PSoC4_ReadRxStatus

#endif /* End (PSoC4_RX_ENABLED) || (PSoC4_HD_ENABLED) */

/* Only if TX is enabled */
#if(PSoC4_TX_ENABLED || PSoC4_HD_ENABLED)

    #if(PSoC4_TX_INTERRUPT_ENABLED)
        #define PSoC4_EnableTxInt()  CyIntEnable (PSoC4_TX_VECT_NUM)
        #define PSoC4_DisableTxInt() CyIntDisable(PSoC4_TX_VECT_NUM)
        #define PSoC4_SetPendingTxInt() CyIntSetPending(PSoC4_TX_VECT_NUM)
        #define PSoC4_ClearPendingTxInt() CyIntClearPending(PSoC4_TX_VECT_NUM)
        CY_ISR_PROTO(PSoC4_TXISR);
    #endif /* PSoC4_TX_INTERRUPT_ENABLED */

    void PSoC4_SetTxInterruptMode(uint8 intSrc) ;
    void PSoC4_WriteTxData(uint8 txDataByte) ;
    uint8 PSoC4_ReadTxStatus(void) ;
    void PSoC4_PutChar(uint8 txDataByte) ;
    void PSoC4_PutString(const char8 string[]) ;
    void PSoC4_PutArray(const uint8 string[], uint8 byteCount)
                                                            ;
    void PSoC4_PutCRLF(uint8 txDataByte) ;
    void PSoC4_ClearTxBuffer(void) ;
    void PSoC4_SetTxAddressMode(uint8 addressMode) ;
    void PSoC4_SendBreak(uint8 retMode) ;
    uint8 PSoC4_GetTxBufferSize(void)
                                                            ;
    /* Obsolete functions, defines for backward compatible */
    #define PSoC4_PutStringConst         PSoC4_PutString
    #define PSoC4_PutArrayConst          PSoC4_PutArray
    #define PSoC4_GetTxInterruptSource   PSoC4_ReadTxStatus

#endif /* End PSoC4_TX_ENABLED || PSoC4_HD_ENABLED */

#if(PSoC4_HD_ENABLED)
    void PSoC4_LoadRxConfig(void) ;
    void PSoC4_LoadTxConfig(void) ;
#endif /* End PSoC4_HD_ENABLED */


/* Communication bootloader APIs */
#if defined(CYDEV_BOOTLOADER_IO_COMP) && ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_PSoC4) || \
                                          (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))
    /* Physical layer functions */
    void    PSoC4_CyBtldrCommStart(void) CYSMALL ;
    void    PSoC4_CyBtldrCommStop(void) CYSMALL ;
    void    PSoC4_CyBtldrCommReset(void) CYSMALL ;
    cystatus PSoC4_CyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;
    cystatus PSoC4_CyBtldrCommRead(uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;

    #if (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_PSoC4)
        #define CyBtldrCommStart    PSoC4_CyBtldrCommStart
        #define CyBtldrCommStop     PSoC4_CyBtldrCommStop
        #define CyBtldrCommReset    PSoC4_CyBtldrCommReset
        #define CyBtldrCommWrite    PSoC4_CyBtldrCommWrite
        #define CyBtldrCommRead     PSoC4_CyBtldrCommRead
    #endif  /* (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_PSoC4) */

    /* Byte to Byte time out for detecting end of block data from host */
    #define PSoC4_BYTE2BYTE_TIME_OUT (25u)
    #define PSoC4_PACKET_EOP         (0x17u) /* End of packet defined by bootloader */
    #define PSoC4_WAIT_EOP_DELAY     (5u)    /* Additional 5ms to wait for End of packet */
    #define PSoC4_BL_CHK_DELAY_MS    (1u)    /* Time Out quantity equal 1mS */

#endif /* CYDEV_BOOTLOADER_IO_COMP */


/***************************************
*          API Constants
***************************************/
/* Parameters for SetTxAddressMode API*/
#define PSoC4_SET_SPACE      (0x00u)
#define PSoC4_SET_MARK       (0x01u)

/* Status Register definitions */
#if( (PSoC4_TX_ENABLED) || (PSoC4_HD_ENABLED) )
    #if(PSoC4_TX_INTERRUPT_ENABLED)
        #define PSoC4_TX_VECT_NUM            (uint8)PSoC4_TXInternalInterrupt__INTC_NUMBER
        #define PSoC4_TX_PRIOR_NUM           (uint8)PSoC4_TXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* PSoC4_TX_INTERRUPT_ENABLED */

    #define PSoC4_TX_STS_COMPLETE_SHIFT          (0x00u)
    #define PSoC4_TX_STS_FIFO_EMPTY_SHIFT        (0x01u)
    #define PSoC4_TX_STS_FIFO_NOT_FULL_SHIFT     (0x03u)
    #if(PSoC4_TX_ENABLED)
        #define PSoC4_TX_STS_FIFO_FULL_SHIFT     (0x02u)
    #else /* (PSoC4_HD_ENABLED) */
        #define PSoC4_TX_STS_FIFO_FULL_SHIFT     (0x05u)  /* Needs MD=0 */
    #endif /* (PSoC4_TX_ENABLED) */

    #define PSoC4_TX_STS_COMPLETE            (uint8)(0x01u << PSoC4_TX_STS_COMPLETE_SHIFT)
    #define PSoC4_TX_STS_FIFO_EMPTY          (uint8)(0x01u << PSoC4_TX_STS_FIFO_EMPTY_SHIFT)
    #define PSoC4_TX_STS_FIFO_FULL           (uint8)(0x01u << PSoC4_TX_STS_FIFO_FULL_SHIFT)
    #define PSoC4_TX_STS_FIFO_NOT_FULL       (uint8)(0x01u << PSoC4_TX_STS_FIFO_NOT_FULL_SHIFT)
#endif /* End (PSoC4_TX_ENABLED) || (PSoC4_HD_ENABLED)*/

#if( (PSoC4_RX_ENABLED) || (PSoC4_HD_ENABLED) )
    #if(PSoC4_RX_INTERRUPT_ENABLED)
        #define PSoC4_RX_VECT_NUM            (uint8)PSoC4_RXInternalInterrupt__INTC_NUMBER
        #define PSoC4_RX_PRIOR_NUM           (uint8)PSoC4_RXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* PSoC4_RX_INTERRUPT_ENABLED */
    #define PSoC4_RX_STS_MRKSPC_SHIFT            (0x00u)
    #define PSoC4_RX_STS_BREAK_SHIFT             (0x01u)
    #define PSoC4_RX_STS_PAR_ERROR_SHIFT         (0x02u)
    #define PSoC4_RX_STS_STOP_ERROR_SHIFT        (0x03u)
    #define PSoC4_RX_STS_OVERRUN_SHIFT           (0x04u)
    #define PSoC4_RX_STS_FIFO_NOTEMPTY_SHIFT     (0x05u)
    #define PSoC4_RX_STS_ADDR_MATCH_SHIFT        (0x06u)
    #define PSoC4_RX_STS_SOFT_BUFF_OVER_SHIFT    (0x07u)

    #define PSoC4_RX_STS_MRKSPC           (uint8)(0x01u << PSoC4_RX_STS_MRKSPC_SHIFT)
    #define PSoC4_RX_STS_BREAK            (uint8)(0x01u << PSoC4_RX_STS_BREAK_SHIFT)
    #define PSoC4_RX_STS_PAR_ERROR        (uint8)(0x01u << PSoC4_RX_STS_PAR_ERROR_SHIFT)
    #define PSoC4_RX_STS_STOP_ERROR       (uint8)(0x01u << PSoC4_RX_STS_STOP_ERROR_SHIFT)
    #define PSoC4_RX_STS_OVERRUN          (uint8)(0x01u << PSoC4_RX_STS_OVERRUN_SHIFT)
    #define PSoC4_RX_STS_FIFO_NOTEMPTY    (uint8)(0x01u << PSoC4_RX_STS_FIFO_NOTEMPTY_SHIFT)
    #define PSoC4_RX_STS_ADDR_MATCH       (uint8)(0x01u << PSoC4_RX_STS_ADDR_MATCH_SHIFT)
    #define PSoC4_RX_STS_SOFT_BUFF_OVER   (uint8)(0x01u << PSoC4_RX_STS_SOFT_BUFF_OVER_SHIFT)
    #define PSoC4_RX_HW_MASK                     (0x7Fu)
#endif /* End (PSoC4_RX_ENABLED) || (PSoC4_HD_ENABLED) */

/* Control Register definitions */
#define PSoC4_CTRL_HD_SEND_SHIFT                 (0x00u) /* 1 enable TX part in Half Duplex mode */
#define PSoC4_CTRL_HD_SEND_BREAK_SHIFT           (0x01u) /* 1 send BREAK signal in Half Duplez mode */
#define PSoC4_CTRL_MARK_SHIFT                    (0x02u) /* 1 sets mark, 0 sets space */
#define PSoC4_CTRL_PARITY_TYPE0_SHIFT            (0x03u) /* Defines the type of parity implemented */
#define PSoC4_CTRL_PARITY_TYPE1_SHIFT            (0x04u) /* Defines the type of parity implemented */
#define PSoC4_CTRL_RXADDR_MODE0_SHIFT            (0x05u)
#define PSoC4_CTRL_RXADDR_MODE1_SHIFT            (0x06u)
#define PSoC4_CTRL_RXADDR_MODE2_SHIFT            (0x07u)

#define PSoC4_CTRL_HD_SEND               (uint8)(0x01u << PSoC4_CTRL_HD_SEND_SHIFT)
#define PSoC4_CTRL_HD_SEND_BREAK         (uint8)(0x01u << PSoC4_CTRL_HD_SEND_BREAK_SHIFT)
#define PSoC4_CTRL_MARK                  (uint8)(0x01u << PSoC4_CTRL_MARK_SHIFT)
#define PSoC4_CTRL_PARITY_TYPE_MASK      (uint8)(0x03u << PSoC4_CTRL_PARITY_TYPE0_SHIFT)
#define PSoC4_CTRL_RXADDR_MODE_MASK      (uint8)(0x07u << PSoC4_CTRL_RXADDR_MODE0_SHIFT)

/* StatusI Register Interrupt Enable Control Bits. As defined by the Register map for the AUX Control Register */
#define PSoC4_INT_ENABLE                         (0x10u)

/* Bit Counter (7-bit) Control Register Bit Definitions. As defined by the Register map for the AUX Control Register */
#define PSoC4_CNTR_ENABLE                        (0x20u)

/*   Constants for SendBreak() "retMode" parameter  */
#define PSoC4_SEND_BREAK                         (0x00u)
#define PSoC4_WAIT_FOR_COMPLETE_REINIT           (0x01u)
#define PSoC4_REINIT                             (0x02u)
#define PSoC4_SEND_WAIT_REINIT                   (0x03u)

#define PSoC4_OVER_SAMPLE_8                      (8u)
#define PSoC4_OVER_SAMPLE_16                     (16u)

#define PSoC4_BIT_CENTER                         (PSoC4_OVER_SAMPLE_COUNT - 2u)

#define PSoC4_FIFO_LENGTH                        (4u)
#define PSoC4_NUMBER_OF_START_BIT                (1u)
#define PSoC4_MAX_BYTE_VALUE                     (0xFFu)

/* 8X always for count7 implementation */
#define PSoC4_TXBITCTR_BREAKBITS8X   ((PSoC4_BREAK_BITS_TX * PSoC4_OVER_SAMPLE_8) - 1u)
/* 8X or 16X for DP implementation */
#define PSoC4_TXBITCTR_BREAKBITS ((PSoC4_BREAK_BITS_TX * PSoC4_OVER_SAMPLE_COUNT) - 1u)

#define PSoC4_HALF_BIT_COUNT   \
                            (((PSoC4_OVER_SAMPLE_COUNT / 2u) + (PSoC4_USE23POLLING * 1u)) - 2u)
#if (PSoC4_OVER_SAMPLE_COUNT == PSoC4_OVER_SAMPLE_8)
    #define PSoC4_HD_TXBITCTR_INIT   (((PSoC4_BREAK_BITS_TX + \
                            PSoC4_NUMBER_OF_START_BIT) * PSoC4_OVER_SAMPLE_COUNT) - 1u)

    /* This parameter is increased on the 2 in 2 out of 3 mode to sample voting in the middle */
    #define PSoC4_RXBITCTR_INIT  ((((PSoC4_BREAK_BITS_RX + PSoC4_NUMBER_OF_START_BIT) \
                            * PSoC4_OVER_SAMPLE_COUNT) + PSoC4_HALF_BIT_COUNT) - 1u)

#else /* PSoC4_OVER_SAMPLE_COUNT == PSoC4_OVER_SAMPLE_16 */
    #define PSoC4_HD_TXBITCTR_INIT   ((8u * PSoC4_OVER_SAMPLE_COUNT) - 1u)
    /* 7bit counter need one more bit for OverSampleCount = 16 */
    #define PSoC4_RXBITCTR_INIT      (((7u * PSoC4_OVER_SAMPLE_COUNT) - 1u) + \
                                                      PSoC4_HALF_BIT_COUNT)
#endif /* End PSoC4_OVER_SAMPLE_COUNT */

#define PSoC4_HD_RXBITCTR_INIT                   PSoC4_RXBITCTR_INIT


/***************************************
* Global variables external identifier
***************************************/

extern uint8 PSoC4_initVar;
#if (PSoC4_TX_INTERRUPT_ENABLED && PSoC4_TX_ENABLED)
    extern volatile uint8 PSoC4_txBuffer[PSoC4_TX_BUFFER_SIZE];
    extern volatile uint8 PSoC4_txBufferRead;
    extern uint8 PSoC4_txBufferWrite;
#endif /* (PSoC4_TX_INTERRUPT_ENABLED && PSoC4_TX_ENABLED) */
#if (PSoC4_RX_INTERRUPT_ENABLED && (PSoC4_RX_ENABLED || PSoC4_HD_ENABLED))
    extern uint8 PSoC4_errorStatus;
    extern volatile uint8 PSoC4_rxBuffer[PSoC4_RX_BUFFER_SIZE];
    extern volatile uint8 PSoC4_rxBufferRead;
    extern volatile uint8 PSoC4_rxBufferWrite;
    extern volatile uint8 PSoC4_rxBufferLoopDetect;
    extern volatile uint8 PSoC4_rxBufferOverflow;
    #if (PSoC4_RXHW_ADDRESS_ENABLED)
        extern volatile uint8 PSoC4_rxAddressMode;
        extern volatile uint8 PSoC4_rxAddressDetected;
    #endif /* (PSoC4_RXHW_ADDRESS_ENABLED) */
#endif /* (PSoC4_RX_INTERRUPT_ENABLED && (PSoC4_RX_ENABLED || PSoC4_HD_ENABLED)) */


/***************************************
* Enumerated Types and Parameters
***************************************/

#define PSoC4__B_UART__AM_SW_BYTE_BYTE 1
#define PSoC4__B_UART__AM_SW_DETECT_TO_BUFFER 2
#define PSoC4__B_UART__AM_HW_BYTE_BY_BYTE 3
#define PSoC4__B_UART__AM_HW_DETECT_TO_BUFFER 4
#define PSoC4__B_UART__AM_NONE 0

#define PSoC4__B_UART__NONE_REVB 0
#define PSoC4__B_UART__EVEN_REVB 1
#define PSoC4__B_UART__ODD_REVB 2
#define PSoC4__B_UART__MARK_SPACE_REVB 3



/***************************************
*    Initial Parameter Constants
***************************************/

/* UART shifts max 8 bits, Mark/Space functionality working if 9 selected */
#define PSoC4_NUMBER_OF_DATA_BITS    ((8u > 8u) ? 8u : 8u)
#define PSoC4_NUMBER_OF_STOP_BITS    (1u)

#if (PSoC4_RXHW_ADDRESS_ENABLED)
    #define PSoC4_RX_ADDRESS_MODE    (0u)
    #define PSoC4_RX_HW_ADDRESS1     (0u)
    #define PSoC4_RX_HW_ADDRESS2     (0u)
#endif /* (PSoC4_RXHW_ADDRESS_ENABLED) */

#define PSoC4_INIT_RX_INTERRUPTS_MASK \
                                  (uint8)((1 << PSoC4_RX_STS_FIFO_NOTEMPTY_SHIFT) \
                                        | (0 << PSoC4_RX_STS_MRKSPC_SHIFT) \
                                        | (0 << PSoC4_RX_STS_ADDR_MATCH_SHIFT) \
                                        | (0 << PSoC4_RX_STS_PAR_ERROR_SHIFT) \
                                        | (0 << PSoC4_RX_STS_STOP_ERROR_SHIFT) \
                                        | (0 << PSoC4_RX_STS_BREAK_SHIFT) \
                                        | (0 << PSoC4_RX_STS_OVERRUN_SHIFT))

#define PSoC4_INIT_TX_INTERRUPTS_MASK \
                                  (uint8)((0 << PSoC4_TX_STS_COMPLETE_SHIFT) \
                                        | (0 << PSoC4_TX_STS_FIFO_EMPTY_SHIFT) \
                                        | (0 << PSoC4_TX_STS_FIFO_FULL_SHIFT) \
                                        | (0 << PSoC4_TX_STS_FIFO_NOT_FULL_SHIFT))


/***************************************
*              Registers
***************************************/

#ifdef PSoC4_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define PSoC4_CONTROL_REG \
                            (* (reg8 *) PSoC4_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
    #define PSoC4_CONTROL_PTR \
                            (  (reg8 *) PSoC4_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
#endif /* End PSoC4_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(PSoC4_TX_ENABLED)
    #define PSoC4_TXDATA_REG          (* (reg8 *) PSoC4_BUART_sTX_TxShifter_u0__F0_REG)
    #define PSoC4_TXDATA_PTR          (  (reg8 *) PSoC4_BUART_sTX_TxShifter_u0__F0_REG)
    #define PSoC4_TXDATA_AUX_CTL_REG  (* (reg8 *) PSoC4_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define PSoC4_TXDATA_AUX_CTL_PTR  (  (reg8 *) PSoC4_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define PSoC4_TXSTATUS_REG        (* (reg8 *) PSoC4_BUART_sTX_TxSts__STATUS_REG)
    #define PSoC4_TXSTATUS_PTR        (  (reg8 *) PSoC4_BUART_sTX_TxSts__STATUS_REG)
    #define PSoC4_TXSTATUS_MASK_REG   (* (reg8 *) PSoC4_BUART_sTX_TxSts__MASK_REG)
    #define PSoC4_TXSTATUS_MASK_PTR   (  (reg8 *) PSoC4_BUART_sTX_TxSts__MASK_REG)
    #define PSoC4_TXSTATUS_ACTL_REG   (* (reg8 *) PSoC4_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)
    #define PSoC4_TXSTATUS_ACTL_PTR   (  (reg8 *) PSoC4_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)

    /* DP clock */
    #if(PSoC4_TXCLKGEN_DP)
        #define PSoC4_TXBITCLKGEN_CTR_REG        \
                                        (* (reg8 *) PSoC4_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define PSoC4_TXBITCLKGEN_CTR_PTR        \
                                        (  (reg8 *) PSoC4_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define PSoC4_TXBITCLKTX_COMPLETE_REG    \
                                        (* (reg8 *) PSoC4_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
        #define PSoC4_TXBITCLKTX_COMPLETE_PTR    \
                                        (  (reg8 *) PSoC4_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
    #else     /* Count7 clock*/
        #define PSoC4_TXBITCTR_PERIOD_REG    \
                                        (* (reg8 *) PSoC4_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define PSoC4_TXBITCTR_PERIOD_PTR    \
                                        (  (reg8 *) PSoC4_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define PSoC4_TXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) PSoC4_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define PSoC4_TXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) PSoC4_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define PSoC4_TXBITCTR_COUNTER_REG   \
                                        (* (reg8 *) PSoC4_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
        #define PSoC4_TXBITCTR_COUNTER_PTR   \
                                        (  (reg8 *) PSoC4_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
    #endif /* PSoC4_TXCLKGEN_DP */

#endif /* End PSoC4_TX_ENABLED */

#if(PSoC4_HD_ENABLED)

    #define PSoC4_TXDATA_REG             (* (reg8 *) PSoC4_BUART_sRX_RxShifter_u0__F1_REG )
    #define PSoC4_TXDATA_PTR             (  (reg8 *) PSoC4_BUART_sRX_RxShifter_u0__F1_REG )
    #define PSoC4_TXDATA_AUX_CTL_REG     (* (reg8 *) PSoC4_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)
    #define PSoC4_TXDATA_AUX_CTL_PTR     (  (reg8 *) PSoC4_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define PSoC4_TXSTATUS_REG           (* (reg8 *) PSoC4_BUART_sRX_RxSts__STATUS_REG )
    #define PSoC4_TXSTATUS_PTR           (  (reg8 *) PSoC4_BUART_sRX_RxSts__STATUS_REG )
    #define PSoC4_TXSTATUS_MASK_REG      (* (reg8 *) PSoC4_BUART_sRX_RxSts__MASK_REG )
    #define PSoC4_TXSTATUS_MASK_PTR      (  (reg8 *) PSoC4_BUART_sRX_RxSts__MASK_REG )
    #define PSoC4_TXSTATUS_ACTL_REG      (* (reg8 *) PSoC4_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define PSoC4_TXSTATUS_ACTL_PTR      (  (reg8 *) PSoC4_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End PSoC4_HD_ENABLED */

#if( (PSoC4_RX_ENABLED) || (PSoC4_HD_ENABLED) )
    #define PSoC4_RXDATA_REG             (* (reg8 *) PSoC4_BUART_sRX_RxShifter_u0__F0_REG )
    #define PSoC4_RXDATA_PTR             (  (reg8 *) PSoC4_BUART_sRX_RxShifter_u0__F0_REG )
    #define PSoC4_RXADDRESS1_REG         (* (reg8 *) PSoC4_BUART_sRX_RxShifter_u0__D0_REG )
    #define PSoC4_RXADDRESS1_PTR         (  (reg8 *) PSoC4_BUART_sRX_RxShifter_u0__D0_REG )
    #define PSoC4_RXADDRESS2_REG         (* (reg8 *) PSoC4_BUART_sRX_RxShifter_u0__D1_REG )
    #define PSoC4_RXADDRESS2_PTR         (  (reg8 *) PSoC4_BUART_sRX_RxShifter_u0__D1_REG )
    #define PSoC4_RXDATA_AUX_CTL_REG     (* (reg8 *) PSoC4_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define PSoC4_RXBITCTR_PERIOD_REG    (* (reg8 *) PSoC4_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define PSoC4_RXBITCTR_PERIOD_PTR    (  (reg8 *) PSoC4_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define PSoC4_RXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) PSoC4_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define PSoC4_RXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) PSoC4_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define PSoC4_RXBITCTR_COUNTER_REG   (* (reg8 *) PSoC4_BUART_sRX_RxBitCounter__COUNT_REG )
    #define PSoC4_RXBITCTR_COUNTER_PTR   (  (reg8 *) PSoC4_BUART_sRX_RxBitCounter__COUNT_REG )

    #define PSoC4_RXSTATUS_REG           (* (reg8 *) PSoC4_BUART_sRX_RxSts__STATUS_REG )
    #define PSoC4_RXSTATUS_PTR           (  (reg8 *) PSoC4_BUART_sRX_RxSts__STATUS_REG )
    #define PSoC4_RXSTATUS_MASK_REG      (* (reg8 *) PSoC4_BUART_sRX_RxSts__MASK_REG )
    #define PSoC4_RXSTATUS_MASK_PTR      (  (reg8 *) PSoC4_BUART_sRX_RxSts__MASK_REG )
    #define PSoC4_RXSTATUS_ACTL_REG      (* (reg8 *) PSoC4_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define PSoC4_RXSTATUS_ACTL_PTR      (  (reg8 *) PSoC4_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End  (PSoC4_RX_ENABLED) || (PSoC4_HD_ENABLED) */

#if(PSoC4_INTERNAL_CLOCK_USED)
    /* Register to enable or disable the digital clocks */
    #define PSoC4_INTCLOCK_CLKEN_REG     (* (reg8 *) PSoC4_IntClock__PM_ACT_CFG)
    #define PSoC4_INTCLOCK_CLKEN_PTR     (  (reg8 *) PSoC4_IntClock__PM_ACT_CFG)

    /* Clock mask for this clock. */
    #define PSoC4_INTCLOCK_CLKEN_MASK    PSoC4_IntClock__PM_ACT_MSK
#endif /* End PSoC4_INTERNAL_CLOCK_USED */


/***************************************
*       Register Constants
***************************************/

#if(PSoC4_TX_ENABLED)
    #define PSoC4_TX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End PSoC4_TX_ENABLED */

#if(PSoC4_HD_ENABLED)
    #define PSoC4_TX_FIFO_CLR            (0x02u) /* FIFO1 CLR */
#endif /* End PSoC4_HD_ENABLED */

#if( (PSoC4_RX_ENABLED) || (PSoC4_HD_ENABLED) )
    #define PSoC4_RX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End  (PSoC4_RX_ENABLED) || (PSoC4_HD_ENABLED) */


/***************************************
* The following code is DEPRECATED and
* should not be used in new projects.
***************************************/

/* UART v2_40 obsolete definitions */
#define PSoC4_WAIT_1_MS      PSoC4_BL_CHK_DELAY_MS   

#define PSoC4_TXBUFFERSIZE   PSoC4_TX_BUFFER_SIZE
#define PSoC4_RXBUFFERSIZE   PSoC4_RX_BUFFER_SIZE

#if (PSoC4_RXHW_ADDRESS_ENABLED)
    #define PSoC4_RXADDRESSMODE  PSoC4_RX_ADDRESS_MODE
    #define PSoC4_RXHWADDRESS1   PSoC4_RX_HW_ADDRESS1
    #define PSoC4_RXHWADDRESS2   PSoC4_RX_HW_ADDRESS2
    /* Backward compatible define */
    #define PSoC4_RXAddressMode  PSoC4_RXADDRESSMODE
#endif /* (PSoC4_RXHW_ADDRESS_ENABLED) */

/* UART v2_30 obsolete definitions */
#define PSoC4_initvar                    PSoC4_initVar

#define PSoC4_RX_Enabled                 PSoC4_RX_ENABLED
#define PSoC4_TX_Enabled                 PSoC4_TX_ENABLED
#define PSoC4_HD_Enabled                 PSoC4_HD_ENABLED
#define PSoC4_RX_IntInterruptEnabled     PSoC4_RX_INTERRUPT_ENABLED
#define PSoC4_TX_IntInterruptEnabled     PSoC4_TX_INTERRUPT_ENABLED
#define PSoC4_InternalClockUsed          PSoC4_INTERNAL_CLOCK_USED
#define PSoC4_RXHW_Address_Enabled       PSoC4_RXHW_ADDRESS_ENABLED
#define PSoC4_OverSampleCount            PSoC4_OVER_SAMPLE_COUNT
#define PSoC4_ParityType                 PSoC4_PARITY_TYPE

#if( PSoC4_TX_ENABLED && (PSoC4_TXBUFFERSIZE > PSoC4_FIFO_LENGTH))
    #define PSoC4_TXBUFFER               PSoC4_txBuffer
    #define PSoC4_TXBUFFERREAD           PSoC4_txBufferRead
    #define PSoC4_TXBUFFERWRITE          PSoC4_txBufferWrite
#endif /* End PSoC4_TX_ENABLED */
#if( ( PSoC4_RX_ENABLED || PSoC4_HD_ENABLED ) && \
     (PSoC4_RXBUFFERSIZE > PSoC4_FIFO_LENGTH) )
    #define PSoC4_RXBUFFER               PSoC4_rxBuffer
    #define PSoC4_RXBUFFERREAD           PSoC4_rxBufferRead
    #define PSoC4_RXBUFFERWRITE          PSoC4_rxBufferWrite
    #define PSoC4_RXBUFFERLOOPDETECT     PSoC4_rxBufferLoopDetect
    #define PSoC4_RXBUFFER_OVERFLOW      PSoC4_rxBufferOverflow
#endif /* End PSoC4_RX_ENABLED */

#ifdef PSoC4_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define PSoC4_CONTROL                PSoC4_CONTROL_REG
#endif /* End PSoC4_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(PSoC4_TX_ENABLED)
    #define PSoC4_TXDATA                 PSoC4_TXDATA_REG
    #define PSoC4_TXSTATUS               PSoC4_TXSTATUS_REG
    #define PSoC4_TXSTATUS_MASK          PSoC4_TXSTATUS_MASK_REG
    #define PSoC4_TXSTATUS_ACTL          PSoC4_TXSTATUS_ACTL_REG
    /* DP clock */
    #if(PSoC4_TXCLKGEN_DP)
        #define PSoC4_TXBITCLKGEN_CTR        PSoC4_TXBITCLKGEN_CTR_REG
        #define PSoC4_TXBITCLKTX_COMPLETE    PSoC4_TXBITCLKTX_COMPLETE_REG
    #else     /* Count7 clock*/
        #define PSoC4_TXBITCTR_PERIOD        PSoC4_TXBITCTR_PERIOD_REG
        #define PSoC4_TXBITCTR_CONTROL       PSoC4_TXBITCTR_CONTROL_REG
        #define PSoC4_TXBITCTR_COUNTER       PSoC4_TXBITCTR_COUNTER_REG
    #endif /* PSoC4_TXCLKGEN_DP */
#endif /* End PSoC4_TX_ENABLED */

#if(PSoC4_HD_ENABLED)
    #define PSoC4_TXDATA                 PSoC4_TXDATA_REG
    #define PSoC4_TXSTATUS               PSoC4_TXSTATUS_REG
    #define PSoC4_TXSTATUS_MASK          PSoC4_TXSTATUS_MASK_REG
    #define PSoC4_TXSTATUS_ACTL          PSoC4_TXSTATUS_ACTL_REG
#endif /* End PSoC4_HD_ENABLED */

#if( (PSoC4_RX_ENABLED) || (PSoC4_HD_ENABLED) )
    #define PSoC4_RXDATA                 PSoC4_RXDATA_REG
    #define PSoC4_RXADDRESS1             PSoC4_RXADDRESS1_REG
    #define PSoC4_RXADDRESS2             PSoC4_RXADDRESS2_REG
    #define PSoC4_RXBITCTR_PERIOD        PSoC4_RXBITCTR_PERIOD_REG
    #define PSoC4_RXBITCTR_CONTROL       PSoC4_RXBITCTR_CONTROL_REG
    #define PSoC4_RXBITCTR_COUNTER       PSoC4_RXBITCTR_COUNTER_REG
    #define PSoC4_RXSTATUS               PSoC4_RXSTATUS_REG
    #define PSoC4_RXSTATUS_MASK          PSoC4_RXSTATUS_MASK_REG
    #define PSoC4_RXSTATUS_ACTL          PSoC4_RXSTATUS_ACTL_REG
#endif /* End  (PSoC4_RX_ENABLED) || (PSoC4_HD_ENABLED) */

#if(PSoC4_INTERNAL_CLOCK_USED)
    #define PSoC4_INTCLOCK_CLKEN         PSoC4_INTCLOCK_CLKEN_REG
#endif /* End PSoC4_INTERNAL_CLOCK_USED */

#define PSoC4_WAIT_FOR_COMLETE_REINIT    PSoC4_WAIT_FOR_COMPLETE_REINIT

#endif  /* CY_UART_PSoC4_H */


/* [] END OF FILE */
