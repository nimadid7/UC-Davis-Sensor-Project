/*******************************************************************************
* File Name: Dust_PM.c
* Version 2.50
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Dust.h"


/***************************************
* Local data allocation
***************************************/

static Dust_BACKUP_STRUCT  Dust_backup =
{
    /* enableState - disabled */
    0u,
};



/*******************************************************************************
* Function Name: Dust_SaveConfig
********************************************************************************
*
* Summary:
*  This function saves the component nonretention control register.
*  Does not save the FIFO which is a set of nonretention registers.
*  This function is called by the Dust_Sleep() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  Dust_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Dust_SaveConfig(void)
{
    #if(Dust_CONTROL_REG_REMOVED == 0u)
        Dust_backup.cr = Dust_CONTROL_REG;
    #endif /* End Dust_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: Dust_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the nonretention control register except FIFO.
*  Does not restore the FIFO which is a set of nonretention registers.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  Dust_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
* Notes:
*  If this function is called without calling Dust_SaveConfig() 
*  first, the data loaded may be incorrect.
*
*******************************************************************************/
void Dust_RestoreConfig(void)
{
    #if(Dust_CONTROL_REG_REMOVED == 0u)
        Dust_CONTROL_REG = Dust_backup.cr;
    #endif /* End Dust_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: Dust_Sleep
********************************************************************************
*
* Summary:
*  This is the preferred API to prepare the component for sleep. 
*  The Dust_Sleep() API saves the current component state. Then it
*  calls the Dust_Stop() function and calls 
*  Dust_SaveConfig() to save the hardware configuration.
*  Call the Dust_Sleep() function before calling the CyPmSleep() 
*  or the CyPmHibernate() function. 
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  Dust_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Dust_Sleep(void)
{
    #if(Dust_RX_ENABLED || Dust_HD_ENABLED)
        if((Dust_RXSTATUS_ACTL_REG  & Dust_INT_ENABLE) != 0u)
        {
            Dust_backup.enableState = 1u;
        }
        else
        {
            Dust_backup.enableState = 0u;
        }
    #else
        if((Dust_TXSTATUS_ACTL_REG  & Dust_INT_ENABLE) !=0u)
        {
            Dust_backup.enableState = 1u;
        }
        else
        {
            Dust_backup.enableState = 0u;
        }
    #endif /* End Dust_RX_ENABLED || Dust_HD_ENABLED*/

    Dust_Stop();
    Dust_SaveConfig();
}


/*******************************************************************************
* Function Name: Dust_Wakeup
********************************************************************************
*
* Summary:
*  This is the preferred API to restore the component to the state when 
*  Dust_Sleep() was called. The Dust_Wakeup() function
*  calls the Dust_RestoreConfig() function to restore the 
*  configuration. If the component was enabled before the 
*  Dust_Sleep() function was called, the Dust_Wakeup()
*  function will also re-enable the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  Dust_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Dust_Wakeup(void)
{
    Dust_RestoreConfig();
    #if( (Dust_RX_ENABLED) || (Dust_HD_ENABLED) )
        Dust_ClearRxBuffer();
    #endif /* End (Dust_RX_ENABLED) || (Dust_HD_ENABLED) */
    #if(Dust_TX_ENABLED || Dust_HD_ENABLED)
        Dust_ClearTxBuffer();
    #endif /* End Dust_TX_ENABLED || Dust_HD_ENABLED */

    if(Dust_backup.enableState != 0u)
    {
        Dust_Enable();
    }
}


/* [] END OF FILE */
