/*******************************************************************************
* File Name: PSoC4.c
* Version 2.50
*
* Description:
*  This file provides all API functionality of the UART component
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "PSoC4.h"
#if (PSoC4_INTERNAL_CLOCK_USED)
    #include "PSoC4_IntClock.h"
#endif /* End PSoC4_INTERNAL_CLOCK_USED */


/***************************************
* Global data allocation
***************************************/

uint8 PSoC4_initVar = 0u;

#if (PSoC4_TX_INTERRUPT_ENABLED && PSoC4_TX_ENABLED)
    volatile uint8 PSoC4_txBuffer[PSoC4_TX_BUFFER_SIZE];
    volatile uint8 PSoC4_txBufferRead = 0u;
    uint8 PSoC4_txBufferWrite = 0u;
#endif /* (PSoC4_TX_INTERRUPT_ENABLED && PSoC4_TX_ENABLED) */

#if (PSoC4_RX_INTERRUPT_ENABLED && (PSoC4_RX_ENABLED || PSoC4_HD_ENABLED))
    uint8 PSoC4_errorStatus = 0u;
    volatile uint8 PSoC4_rxBuffer[PSoC4_RX_BUFFER_SIZE];
    volatile uint8 PSoC4_rxBufferRead  = 0u;
    volatile uint8 PSoC4_rxBufferWrite = 0u;
    volatile uint8 PSoC4_rxBufferLoopDetect = 0u;
    volatile uint8 PSoC4_rxBufferOverflow   = 0u;
    #if (PSoC4_RXHW_ADDRESS_ENABLED)
        volatile uint8 PSoC4_rxAddressMode = PSoC4_RX_ADDRESS_MODE;
        volatile uint8 PSoC4_rxAddressDetected = 0u;
    #endif /* (PSoC4_RXHW_ADDRESS_ENABLED) */
#endif /* (PSoC4_RX_INTERRUPT_ENABLED && (PSoC4_RX_ENABLED || PSoC4_HD_ENABLED)) */


/*******************************************************************************
* Function Name: PSoC4_Start
********************************************************************************
*
* Summary:
*  This is the preferred method to begin component operation.
*  PSoC4_Start() sets the initVar variable, calls the
*  PSoC4_Init() function, and then calls the
*  PSoC4_Enable() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  The PSoC4_intiVar variable is used to indicate initial
*  configuration of this component. The variable is initialized to zero (0u)
*  and set to one (1u) the first time PSoC4_Start() is called. This
*  allows for component initialization without re-initialization in all
*  subsequent calls to the PSoC4_Start() routine.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void PSoC4_Start(void) 
{
    /* If not initialized then initialize all required hardware and software */
    if(PSoC4_initVar == 0u)
    {
        PSoC4_Init();
        PSoC4_initVar = 1u;
    }

    PSoC4_Enable();
}


/*******************************************************************************
* Function Name: PSoC4_Init
********************************************************************************
*
* Summary:
*  Initializes or restores the component according to the customizer Configure
*  dialog settings. It is not necessary to call PSoC4_Init() because
*  the PSoC4_Start() API calls this function and is the preferred
*  method to begin component operation.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void PSoC4_Init(void) 
{
    #if(PSoC4_RX_ENABLED || PSoC4_HD_ENABLED)

        #if (PSoC4_RX_INTERRUPT_ENABLED)
            /* Set RX interrupt vector and priority */
            (void) CyIntSetVector(PSoC4_RX_VECT_NUM, &PSoC4_RXISR);
            CyIntSetPriority(PSoC4_RX_VECT_NUM, PSoC4_RX_PRIOR_NUM);
            PSoC4_errorStatus = 0u;
        #endif /* (PSoC4_RX_INTERRUPT_ENABLED) */

        #if (PSoC4_RXHW_ADDRESS_ENABLED)
            PSoC4_SetRxAddressMode(PSoC4_RX_ADDRESS_MODE);
            PSoC4_SetRxAddress1(PSoC4_RX_HW_ADDRESS1);
            PSoC4_SetRxAddress2(PSoC4_RX_HW_ADDRESS2);
        #endif /* End PSoC4_RXHW_ADDRESS_ENABLED */

        /* Init Count7 period */
        PSoC4_RXBITCTR_PERIOD_REG = PSoC4_RXBITCTR_INIT;
        /* Configure the Initial RX interrupt mask */
        PSoC4_RXSTATUS_MASK_REG  = PSoC4_INIT_RX_INTERRUPTS_MASK;
    #endif /* End PSoC4_RX_ENABLED || PSoC4_HD_ENABLED*/

    #if(PSoC4_TX_ENABLED)
        #if (PSoC4_TX_INTERRUPT_ENABLED)
            /* Set TX interrupt vector and priority */
            (void) CyIntSetVector(PSoC4_TX_VECT_NUM, &PSoC4_TXISR);
            CyIntSetPriority(PSoC4_TX_VECT_NUM, PSoC4_TX_PRIOR_NUM);
        #endif /* (PSoC4_TX_INTERRUPT_ENABLED) */

        /* Write Counter Value for TX Bit Clk Generator*/
        #if (PSoC4_TXCLKGEN_DP)
            PSoC4_TXBITCLKGEN_CTR_REG = PSoC4_BIT_CENTER;
            PSoC4_TXBITCLKTX_COMPLETE_REG = ((PSoC4_NUMBER_OF_DATA_BITS +
                        PSoC4_NUMBER_OF_START_BIT) * PSoC4_OVER_SAMPLE_COUNT) - 1u;
        #else
            PSoC4_TXBITCTR_PERIOD_REG = ((PSoC4_NUMBER_OF_DATA_BITS +
                        PSoC4_NUMBER_OF_START_BIT) * PSoC4_OVER_SAMPLE_8) - 1u;
        #endif /* End PSoC4_TXCLKGEN_DP */

        /* Configure the Initial TX interrupt mask */
        #if (PSoC4_TX_INTERRUPT_ENABLED)
            PSoC4_TXSTATUS_MASK_REG = PSoC4_TX_STS_FIFO_EMPTY;
        #else
            PSoC4_TXSTATUS_MASK_REG = PSoC4_INIT_TX_INTERRUPTS_MASK;
        #endif /*End PSoC4_TX_INTERRUPT_ENABLED*/

    #endif /* End PSoC4_TX_ENABLED */

    #if(PSoC4_PARITY_TYPE_SW)  /* Write Parity to Control Register */
        PSoC4_WriteControlRegister( \
            (PSoC4_ReadControlRegister() & (uint8)~PSoC4_CTRL_PARITY_TYPE_MASK) | \
            (uint8)(PSoC4_PARITY_TYPE << PSoC4_CTRL_PARITY_TYPE0_SHIFT) );
    #endif /* End PSoC4_PARITY_TYPE_SW */
}


/*******************************************************************************
* Function Name: PSoC4_Enable
********************************************************************************
*
* Summary:
*  Activates the hardware and begins component operation. It is not necessary
*  to call PSoC4_Enable() because the PSoC4_Start() API
*  calls this function, which is the preferred method to begin component
*  operation.

* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  PSoC4_rxAddressDetected - set to initial state (0).
*
*******************************************************************************/
void PSoC4_Enable(void) 
{
    uint8 enableInterrupts;
    enableInterrupts = CyEnterCriticalSection();

    #if (PSoC4_RX_ENABLED || PSoC4_HD_ENABLED)
        /* RX Counter (Count7) Enable */
        PSoC4_RXBITCTR_CONTROL_REG |= PSoC4_CNTR_ENABLE;

        /* Enable the RX Interrupt */
        PSoC4_RXSTATUS_ACTL_REG  |= PSoC4_INT_ENABLE;

        #if (PSoC4_RX_INTERRUPT_ENABLED)
            PSoC4_EnableRxInt();

            #if (PSoC4_RXHW_ADDRESS_ENABLED)
                PSoC4_rxAddressDetected = 0u;
            #endif /* (PSoC4_RXHW_ADDRESS_ENABLED) */
        #endif /* (PSoC4_RX_INTERRUPT_ENABLED) */
    #endif /* (PSoC4_RX_ENABLED || PSoC4_HD_ENABLED) */

    #if(PSoC4_TX_ENABLED)
        /* TX Counter (DP/Count7) Enable */
        #if(!PSoC4_TXCLKGEN_DP)
            PSoC4_TXBITCTR_CONTROL_REG |= PSoC4_CNTR_ENABLE;
        #endif /* End PSoC4_TXCLKGEN_DP */

        /* Enable the TX Interrupt */
        PSoC4_TXSTATUS_ACTL_REG |= PSoC4_INT_ENABLE;
        #if (PSoC4_TX_INTERRUPT_ENABLED)
            PSoC4_ClearPendingTxInt(); /* Clear history of TX_NOT_EMPTY */
            PSoC4_EnableTxInt();
        #endif /* (PSoC4_TX_INTERRUPT_ENABLED) */
     #endif /* (PSoC4_TX_INTERRUPT_ENABLED) */

    #if (PSoC4_INTERNAL_CLOCK_USED)
        PSoC4_IntClock_Start();  /* Enable the clock */
    #endif /* (PSoC4_INTERNAL_CLOCK_USED) */

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: PSoC4_Stop
********************************************************************************
*
* Summary:
*  Disables the UART operation.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void PSoC4_Stop(void) 
{
    uint8 enableInterrupts;
    enableInterrupts = CyEnterCriticalSection();

    /* Write Bit Counter Disable */
    #if (PSoC4_RX_ENABLED || PSoC4_HD_ENABLED)
        PSoC4_RXBITCTR_CONTROL_REG &= (uint8) ~PSoC4_CNTR_ENABLE;
    #endif /* (PSoC4_RX_ENABLED || PSoC4_HD_ENABLED) */

    #if (PSoC4_TX_ENABLED)
        #if(!PSoC4_TXCLKGEN_DP)
            PSoC4_TXBITCTR_CONTROL_REG &= (uint8) ~PSoC4_CNTR_ENABLE;
        #endif /* (!PSoC4_TXCLKGEN_DP) */
    #endif /* (PSoC4_TX_ENABLED) */

    #if (PSoC4_INTERNAL_CLOCK_USED)
        PSoC4_IntClock_Stop();   /* Disable the clock */
    #endif /* (PSoC4_INTERNAL_CLOCK_USED) */

    /* Disable internal interrupt component */
    #if (PSoC4_RX_ENABLED || PSoC4_HD_ENABLED)
        PSoC4_RXSTATUS_ACTL_REG  &= (uint8) ~PSoC4_INT_ENABLE;

        #if (PSoC4_RX_INTERRUPT_ENABLED)
            PSoC4_DisableRxInt();
        #endif /* (PSoC4_RX_INTERRUPT_ENABLED) */
    #endif /* (PSoC4_RX_ENABLED || PSoC4_HD_ENABLED) */

    #if (PSoC4_TX_ENABLED)
        PSoC4_TXSTATUS_ACTL_REG &= (uint8) ~PSoC4_INT_ENABLE;

        #if (PSoC4_TX_INTERRUPT_ENABLED)
            PSoC4_DisableTxInt();
        #endif /* (PSoC4_TX_INTERRUPT_ENABLED) */
    #endif /* (PSoC4_TX_ENABLED) */

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: PSoC4_ReadControlRegister
********************************************************************************
*
* Summary:
*  Returns the current value of the control register.
*
* Parameters:
*  None.
*
* Return:
*  Contents of the control register.
*
*******************************************************************************/
uint8 PSoC4_ReadControlRegister(void) 
{
    #if (PSoC4_CONTROL_REG_REMOVED)
        return(0u);
    #else
        return(PSoC4_CONTROL_REG);
    #endif /* (PSoC4_CONTROL_REG_REMOVED) */
}


/*******************************************************************************
* Function Name: PSoC4_WriteControlRegister
********************************************************************************
*
* Summary:
*  Writes an 8-bit value into the control register
*
* Parameters:
*  control:  control register value
*
* Return:
*  None.
*
*******************************************************************************/
void  PSoC4_WriteControlRegister(uint8 control) 
{
    #if (PSoC4_CONTROL_REG_REMOVED)
        if(0u != control)
        {
            /* Suppress compiler warning */
        }
    #else
       PSoC4_CONTROL_REG = control;
    #endif /* (PSoC4_CONTROL_REG_REMOVED) */
}


#if(PSoC4_RX_ENABLED || PSoC4_HD_ENABLED)
    /*******************************************************************************
    * Function Name: PSoC4_SetRxInterruptMode
    ********************************************************************************
    *
    * Summary:
    *  Configures the RX interrupt sources enabled.
    *
    * Parameters:
    *  IntSrc:  Bit field containing the RX interrupts to enable. Based on the 
    *  bit-field arrangement of the status register. This value must be a 
    *  combination of status register bit-masks shown below:
    *      PSoC4_RX_STS_FIFO_NOTEMPTY    Interrupt on byte received.
    *      PSoC4_RX_STS_PAR_ERROR        Interrupt on parity error.
    *      PSoC4_RX_STS_STOP_ERROR       Interrupt on stop error.
    *      PSoC4_RX_STS_BREAK            Interrupt on break.
    *      PSoC4_RX_STS_OVERRUN          Interrupt on overrun error.
    *      PSoC4_RX_STS_ADDR_MATCH       Interrupt on address match.
    *      PSoC4_RX_STS_MRKSPC           Interrupt on address detect.
    *
    * Return:
    *  None.
    *
    * Theory:
    *  Enables the output of specific status bits to the interrupt controller
    *
    *******************************************************************************/
    void PSoC4_SetRxInterruptMode(uint8 intSrc) 
    {
        PSoC4_RXSTATUS_MASK_REG  = intSrc;
    }


    /*******************************************************************************
    * Function Name: PSoC4_ReadRxData
    ********************************************************************************
    *
    * Summary:
    *  Returns the next byte of received data. This function returns data without
    *  checking the status. You must check the status separately.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Received data from RX register
    *
    * Global Variables:
    *  PSoC4_rxBuffer - RAM buffer pointer for save received data.
    *  PSoC4_rxBufferWrite - cyclic index for write to rxBuffer,
    *     checked to identify new data.
    *  PSoC4_rxBufferRead - cyclic index for read from rxBuffer,
    *     incremented after each byte has been read from buffer.
    *  PSoC4_rxBufferLoopDetect - cleared if loop condition was detected
    *     in RX ISR.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    uint8 PSoC4_ReadRxData(void) 
    {
        uint8 rxData;

    #if (PSoC4_RX_INTERRUPT_ENABLED)

        uint8 locRxBufferRead;
        uint8 locRxBufferWrite;

        /* Protect variables that could change on interrupt */
        PSoC4_DisableRxInt();

        locRxBufferRead  = PSoC4_rxBufferRead;
        locRxBufferWrite = PSoC4_rxBufferWrite;

        if( (PSoC4_rxBufferLoopDetect != 0u) || (locRxBufferRead != locRxBufferWrite) )
        {
            rxData = PSoC4_rxBuffer[locRxBufferRead];
            locRxBufferRead++;

            if(locRxBufferRead >= PSoC4_RX_BUFFER_SIZE)
            {
                locRxBufferRead = 0u;
            }
            /* Update the real pointer */
            PSoC4_rxBufferRead = locRxBufferRead;

            if(PSoC4_rxBufferLoopDetect != 0u)
            {
                PSoC4_rxBufferLoopDetect = 0u;
                #if ((PSoC4_RX_INTERRUPT_ENABLED) && (PSoC4_FLOW_CONTROL != 0u))
                    /* When Hardware Flow Control selected - return RX mask */
                    #if( PSoC4_HD_ENABLED )
                        if((PSoC4_CONTROL_REG & PSoC4_CTRL_HD_SEND) == 0u)
                        {   /* In Half duplex mode return RX mask only in RX
                            *  configuration set, otherwise
                            *  mask will be returned in LoadRxConfig() API.
                            */
                            PSoC4_RXSTATUS_MASK_REG  |= PSoC4_RX_STS_FIFO_NOTEMPTY;
                        }
                    #else
                        PSoC4_RXSTATUS_MASK_REG  |= PSoC4_RX_STS_FIFO_NOTEMPTY;
                    #endif /* end PSoC4_HD_ENABLED */
                #endif /* ((PSoC4_RX_INTERRUPT_ENABLED) && (PSoC4_FLOW_CONTROL != 0u)) */
            }
        }
        else
        {   /* Needs to check status for RX_STS_FIFO_NOTEMPTY bit */
            rxData = PSoC4_RXDATA_REG;
        }

        PSoC4_EnableRxInt();

    #else

        /* Needs to check status for RX_STS_FIFO_NOTEMPTY bit */
        rxData = PSoC4_RXDATA_REG;

    #endif /* (PSoC4_RX_INTERRUPT_ENABLED) */

        return(rxData);
    }


    /*******************************************************************************
    * Function Name: PSoC4_ReadRxStatus
    ********************************************************************************
    *
    * Summary:
    *  Returns the current state of the receiver status register and the software
    *  buffer overflow status.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Current state of the status register.
    *
    * Side Effect:
    *  All status register bits are clear-on-read except
    *  PSoC4_RX_STS_FIFO_NOTEMPTY.
    *  PSoC4_RX_STS_FIFO_NOTEMPTY clears immediately after RX data
    *  register read.
    *
    * Global Variables:
    *  PSoC4_rxBufferOverflow - used to indicate overload condition.
    *   It set to one in RX interrupt when there isn't free space in
    *   PSoC4_rxBufferRead to write new data. This condition returned
    *   and cleared to zero by this API as an
    *   PSoC4_RX_STS_SOFT_BUFF_OVER bit along with RX Status register
    *   bits.
    *
    *******************************************************************************/
    uint8 PSoC4_ReadRxStatus(void) 
    {
        uint8 status;

        status = PSoC4_RXSTATUS_REG & PSoC4_RX_HW_MASK;

    #if (PSoC4_RX_INTERRUPT_ENABLED)
        if(PSoC4_rxBufferOverflow != 0u)
        {
            status |= PSoC4_RX_STS_SOFT_BUFF_OVER;
            PSoC4_rxBufferOverflow = 0u;
        }
    #endif /* (PSoC4_RX_INTERRUPT_ENABLED) */

        return(status);
    }


    /*******************************************************************************
    * Function Name: PSoC4_GetChar
    ********************************************************************************
    *
    * Summary:
    *  Returns the last received byte of data. PSoC4_GetChar() is
    *  designed for ASCII characters and returns a uint8 where 1 to 255 are values
    *  for valid characters and 0 indicates an error occurred or no data is present.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Character read from UART RX buffer. ASCII characters from 1 to 255 are valid.
    *  A returned zero signifies an error condition or no data available.
    *
    * Global Variables:
    *  PSoC4_rxBuffer - RAM buffer pointer for save received data.
    *  PSoC4_rxBufferWrite - cyclic index for write to rxBuffer,
    *     checked to identify new data.
    *  PSoC4_rxBufferRead - cyclic index for read from rxBuffer,
    *     incremented after each byte has been read from buffer.
    *  PSoC4_rxBufferLoopDetect - cleared if loop condition was detected
    *     in RX ISR.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    uint8 PSoC4_GetChar(void) 
    {
        uint8 rxData = 0u;
        uint8 rxStatus;

    #if (PSoC4_RX_INTERRUPT_ENABLED)
        uint8 locRxBufferRead;
        uint8 locRxBufferWrite;

        /* Protect variables that could change on interrupt */
        PSoC4_DisableRxInt();

        locRxBufferRead  = PSoC4_rxBufferRead;
        locRxBufferWrite = PSoC4_rxBufferWrite;

        if( (PSoC4_rxBufferLoopDetect != 0u) || (locRxBufferRead != locRxBufferWrite) )
        {
            rxData = PSoC4_rxBuffer[locRxBufferRead];
            locRxBufferRead++;
            if(locRxBufferRead >= PSoC4_RX_BUFFER_SIZE)
            {
                locRxBufferRead = 0u;
            }
            /* Update the real pointer */
            PSoC4_rxBufferRead = locRxBufferRead;

            if(PSoC4_rxBufferLoopDetect != 0u)
            {
                PSoC4_rxBufferLoopDetect = 0u;
                #if( (PSoC4_RX_INTERRUPT_ENABLED) && (PSoC4_FLOW_CONTROL != 0u) )
                    /* When Hardware Flow Control selected - return RX mask */
                    #if( PSoC4_HD_ENABLED )
                        if((PSoC4_CONTROL_REG & PSoC4_CTRL_HD_SEND) == 0u)
                        {   /* In Half duplex mode return RX mask only if
                            *  RX configuration set, otherwise
                            *  mask will be returned in LoadRxConfig() API.
                            */
                            PSoC4_RXSTATUS_MASK_REG |= PSoC4_RX_STS_FIFO_NOTEMPTY;
                        }
                    #else
                        PSoC4_RXSTATUS_MASK_REG |= PSoC4_RX_STS_FIFO_NOTEMPTY;
                    #endif /* end PSoC4_HD_ENABLED */
                #endif /* PSoC4_RX_INTERRUPT_ENABLED and Hardware flow control*/
            }

        }
        else
        {   rxStatus = PSoC4_RXSTATUS_REG;
            if((rxStatus & PSoC4_RX_STS_FIFO_NOTEMPTY) != 0u)
            {   /* Read received data from FIFO */
                rxData = PSoC4_RXDATA_REG;
                /*Check status on error*/
                if((rxStatus & (PSoC4_RX_STS_BREAK | PSoC4_RX_STS_PAR_ERROR |
                                PSoC4_RX_STS_STOP_ERROR | PSoC4_RX_STS_OVERRUN)) != 0u)
                {
                    rxData = 0u;
                }
            }
        }

        PSoC4_EnableRxInt();

    #else

        rxStatus =PSoC4_RXSTATUS_REG;
        if((rxStatus & PSoC4_RX_STS_FIFO_NOTEMPTY) != 0u)
        {
            /* Read received data from FIFO */
            rxData = PSoC4_RXDATA_REG;

            /*Check status on error*/
            if((rxStatus & (PSoC4_RX_STS_BREAK | PSoC4_RX_STS_PAR_ERROR |
                            PSoC4_RX_STS_STOP_ERROR | PSoC4_RX_STS_OVERRUN)) != 0u)
            {
                rxData = 0u;
            }
        }
    #endif /* (PSoC4_RX_INTERRUPT_ENABLED) */

        return(rxData);
    }


    /*******************************************************************************
    * Function Name: PSoC4_GetByte
    ********************************************************************************
    *
    * Summary:
    *  Reads UART RX buffer immediately, returns received character and error
    *  condition.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  MSB contains status and LSB contains UART RX data. If the MSB is nonzero,
    *  an error has occurred.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    uint16 PSoC4_GetByte(void) 
    {
        
    #if (PSoC4_RX_INTERRUPT_ENABLED)
        uint16 locErrorStatus;
        /* Protect variables that could change on interrupt */
        PSoC4_DisableRxInt();
        locErrorStatus = (uint16)PSoC4_errorStatus;
        PSoC4_errorStatus = 0u;
        PSoC4_EnableRxInt();
        return ( (uint16)(locErrorStatus << 8u) | PSoC4_ReadRxData() );
    #else
        return ( ((uint16)PSoC4_ReadRxStatus() << 8u) | PSoC4_ReadRxData() );
    #endif /* PSoC4_RX_INTERRUPT_ENABLED */
        
    }


    /*******************************************************************************
    * Function Name: PSoC4_GetRxBufferSize
    ********************************************************************************
    *
    * Summary:
    *  Returns the number of received bytes available in the RX buffer.
    *  * RX software buffer is disabled (RX Buffer Size parameter is equal to 4): 
    *    returns 0 for empty RX FIFO or 1 for not empty RX FIFO.
    *  * RX software buffer is enabled: returns the number of bytes available in 
    *    the RX software buffer. Bytes available in the RX FIFO do not take to 
    *    account.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  uint8: Number of bytes in the RX buffer. 
    *    Return value type depends on RX Buffer Size parameter.
    *
    * Global Variables:
    *  PSoC4_rxBufferWrite - used to calculate left bytes.
    *  PSoC4_rxBufferRead - used to calculate left bytes.
    *  PSoC4_rxBufferLoopDetect - checked to decide left bytes amount.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Allows the user to find out how full the RX Buffer is.
    *
    *******************************************************************************/
    uint8 PSoC4_GetRxBufferSize(void)
                                                            
    {
        uint8 size;

    #if (PSoC4_RX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt */
        PSoC4_DisableRxInt();

        if(PSoC4_rxBufferRead == PSoC4_rxBufferWrite)
        {
            if(PSoC4_rxBufferLoopDetect != 0u)
            {
                size = PSoC4_RX_BUFFER_SIZE;
            }
            else
            {
                size = 0u;
            }
        }
        else if(PSoC4_rxBufferRead < PSoC4_rxBufferWrite)
        {
            size = (PSoC4_rxBufferWrite - PSoC4_rxBufferRead);
        }
        else
        {
            size = (PSoC4_RX_BUFFER_SIZE - PSoC4_rxBufferRead) + PSoC4_rxBufferWrite;
        }

        PSoC4_EnableRxInt();

    #else

        /* We can only know if there is data in the fifo. */
        size = ((PSoC4_RXSTATUS_REG & PSoC4_RX_STS_FIFO_NOTEMPTY) != 0u) ? 1u : 0u;

    #endif /* (PSoC4_RX_INTERRUPT_ENABLED) */

        return(size);
    }


    /*******************************************************************************
    * Function Name: PSoC4_ClearRxBuffer
    ********************************************************************************
    *
    * Summary:
    *  Clears the receiver memory buffer and hardware RX FIFO of all received data.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  PSoC4_rxBufferWrite - cleared to zero.
    *  PSoC4_rxBufferRead - cleared to zero.
    *  PSoC4_rxBufferLoopDetect - cleared to zero.
    *  PSoC4_rxBufferOverflow - cleared to zero.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Setting the pointers to zero makes the system believe there is no data to
    *  read and writing will resume at address 0 overwriting any data that may
    *  have remained in the RAM.
    *
    * Side Effects:
    *  Any received data not read from the RAM or FIFO buffer will be lost.
    *
    *******************************************************************************/
    void PSoC4_ClearRxBuffer(void) 
    {
        uint8 enableInterrupts;

        /* Clear the HW FIFO */
        enableInterrupts = CyEnterCriticalSection();
        PSoC4_RXDATA_AUX_CTL_REG |= (uint8)  PSoC4_RX_FIFO_CLR;
        PSoC4_RXDATA_AUX_CTL_REG &= (uint8) ~PSoC4_RX_FIFO_CLR;
        CyExitCriticalSection(enableInterrupts);

    #if (PSoC4_RX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt. */
        PSoC4_DisableRxInt();

        PSoC4_rxBufferRead = 0u;
        PSoC4_rxBufferWrite = 0u;
        PSoC4_rxBufferLoopDetect = 0u;
        PSoC4_rxBufferOverflow = 0u;

        PSoC4_EnableRxInt();

    #endif /* (PSoC4_RX_INTERRUPT_ENABLED) */

    }


    /*******************************************************************************
    * Function Name: PSoC4_SetRxAddressMode
    ********************************************************************************
    *
    * Summary:
    *  Sets the software controlled Addressing mode used by the RX portion of the
    *  UART.
    *
    * Parameters:
    *  addressMode: Enumerated value indicating the mode of RX addressing
    *  PSoC4__B_UART__AM_SW_BYTE_BYTE -  Software Byte-by-Byte address
    *                                               detection
    *  PSoC4__B_UART__AM_SW_DETECT_TO_BUFFER - Software Detect to Buffer
    *                                               address detection
    *  PSoC4__B_UART__AM_HW_BYTE_BY_BYTE - Hardware Byte-by-Byte address
    *                                               detection
    *  PSoC4__B_UART__AM_HW_DETECT_TO_BUFFER - Hardware Detect to Buffer
    *                                               address detection
    *  PSoC4__B_UART__AM_NONE - No address detection
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  PSoC4_rxAddressMode - the parameter stored in this variable for
    *   the farther usage in RX ISR.
    *  PSoC4_rxAddressDetected - set to initial state (0).
    *
    *******************************************************************************/
    void PSoC4_SetRxAddressMode(uint8 addressMode)
                                                        
    {
        #if(PSoC4_RXHW_ADDRESS_ENABLED)
            #if(PSoC4_CONTROL_REG_REMOVED)
                if(0u != addressMode)
                {
                    /* Suppress compiler warning */
                }
            #else /* PSoC4_CONTROL_REG_REMOVED */
                uint8 tmpCtrl;
                tmpCtrl = PSoC4_CONTROL_REG & (uint8)~PSoC4_CTRL_RXADDR_MODE_MASK;
                tmpCtrl |= (uint8)(addressMode << PSoC4_CTRL_RXADDR_MODE0_SHIFT);
                PSoC4_CONTROL_REG = tmpCtrl;

                #if(PSoC4_RX_INTERRUPT_ENABLED && \
                   (PSoC4_RXBUFFERSIZE > PSoC4_FIFO_LENGTH) )
                    PSoC4_rxAddressMode = addressMode;
                    PSoC4_rxAddressDetected = 0u;
                #endif /* End PSoC4_RXBUFFERSIZE > PSoC4_FIFO_LENGTH*/
            #endif /* End PSoC4_CONTROL_REG_REMOVED */
        #else /* PSoC4_RXHW_ADDRESS_ENABLED */
            if(0u != addressMode)
            {
                /* Suppress compiler warning */
            }
        #endif /* End PSoC4_RXHW_ADDRESS_ENABLED */
    }


    /*******************************************************************************
    * Function Name: PSoC4_SetRxAddress1
    ********************************************************************************
    *
    * Summary:
    *  Sets the first of two hardware-detectable receiver addresses.
    *
    * Parameters:
    *  address: Address #1 for hardware address detection.
    *
    * Return:
    *  None.
    *
    *******************************************************************************/
    void PSoC4_SetRxAddress1(uint8 address) 
    {
        PSoC4_RXADDRESS1_REG = address;
    }


    /*******************************************************************************
    * Function Name: PSoC4_SetRxAddress2
    ********************************************************************************
    *
    * Summary:
    *  Sets the second of two hardware-detectable receiver addresses.
    *
    * Parameters:
    *  address: Address #2 for hardware address detection.
    *
    * Return:
    *  None.
    *
    *******************************************************************************/
    void PSoC4_SetRxAddress2(uint8 address) 
    {
        PSoC4_RXADDRESS2_REG = address;
    }

#endif  /* PSoC4_RX_ENABLED || PSoC4_HD_ENABLED*/


#if( (PSoC4_TX_ENABLED) || (PSoC4_HD_ENABLED) )
    /*******************************************************************************
    * Function Name: PSoC4_SetTxInterruptMode
    ********************************************************************************
    *
    * Summary:
    *  Configures the TX interrupt sources to be enabled, but does not enable the
    *  interrupt.
    *
    * Parameters:
    *  intSrc: Bit field containing the TX interrupt sources to enable
    *   PSoC4_TX_STS_COMPLETE        Interrupt on TX byte complete
    *   PSoC4_TX_STS_FIFO_EMPTY      Interrupt when TX FIFO is empty
    *   PSoC4_TX_STS_FIFO_FULL       Interrupt when TX FIFO is full
    *   PSoC4_TX_STS_FIFO_NOT_FULL   Interrupt when TX FIFO is not full
    *
    * Return:
    *  None.
    *
    * Theory:
    *  Enables the output of specific status bits to the interrupt controller
    *
    *******************************************************************************/
    void PSoC4_SetTxInterruptMode(uint8 intSrc) 
    {
        PSoC4_TXSTATUS_MASK_REG = intSrc;
    }


    /*******************************************************************************
    * Function Name: PSoC4_WriteTxData
    ********************************************************************************
    *
    * Summary:
    *  Places a byte of data into the transmit buffer to be sent when the bus is
    *  available without checking the TX status register. You must check status
    *  separately.
    *
    * Parameters:
    *  txDataByte: data byte
    *
    * Return:
    * None.
    *
    * Global Variables:
    *  PSoC4_txBuffer - RAM buffer pointer for save data for transmission
    *  PSoC4_txBufferWrite - cyclic index for write to txBuffer,
    *    incremented after each byte saved to buffer.
    *  PSoC4_txBufferRead - cyclic index for read from txBuffer,
    *    checked to identify the condition to write to FIFO directly or to TX buffer
    *  PSoC4_initVar - checked to identify that the component has been
    *    initialized.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    void PSoC4_WriteTxData(uint8 txDataByte) 
    {
        /* If not Initialized then skip this function*/
        if(PSoC4_initVar != 0u)
        {
        #if (PSoC4_TX_INTERRUPT_ENABLED)

            /* Protect variables that could change on interrupt. */
            PSoC4_DisableTxInt();

            if( (PSoC4_txBufferRead == PSoC4_txBufferWrite) &&
                ((PSoC4_TXSTATUS_REG & PSoC4_TX_STS_FIFO_FULL) == 0u) )
            {
                /* Add directly to the FIFO. */
                PSoC4_TXDATA_REG = txDataByte;
            }
            else
            {
                if(PSoC4_txBufferWrite >= PSoC4_TX_BUFFER_SIZE)
                {
                    PSoC4_txBufferWrite = 0u;
                }

                PSoC4_txBuffer[PSoC4_txBufferWrite] = txDataByte;

                /* Add to the software buffer. */
                PSoC4_txBufferWrite++;
            }

            PSoC4_EnableTxInt();

        #else

            /* Add directly to the FIFO. */
            PSoC4_TXDATA_REG = txDataByte;

        #endif /*(PSoC4_TX_INTERRUPT_ENABLED) */
        }
    }


    /*******************************************************************************
    * Function Name: PSoC4_ReadTxStatus
    ********************************************************************************
    *
    * Summary:
    *  Reads the status register for the TX portion of the UART.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Contents of the status register
    *
    * Theory:
    *  This function reads the TX status register, which is cleared on read.
    *  It is up to the user to handle all bits in this return value accordingly,
    *  even if the bit was not enabled as an interrupt source the event happened
    *  and must be handled accordingly.
    *
    *******************************************************************************/
    uint8 PSoC4_ReadTxStatus(void) 
    {
        return(PSoC4_TXSTATUS_REG);
    }


    /*******************************************************************************
    * Function Name: PSoC4_PutChar
    ********************************************************************************
    *
    * Summary:
    *  Puts a byte of data into the transmit buffer to be sent when the bus is
    *  available. This is a blocking API that waits until the TX buffer has room to
    *  hold the data.
    *
    * Parameters:
    *  txDataByte: Byte containing the data to transmit
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  PSoC4_txBuffer - RAM buffer pointer for save data for transmission
    *  PSoC4_txBufferWrite - cyclic index for write to txBuffer,
    *     checked to identify free space in txBuffer and incremented after each byte
    *     saved to buffer.
    *  PSoC4_txBufferRead - cyclic index for read from txBuffer,
    *     checked to identify free space in txBuffer.
    *  PSoC4_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Allows the user to transmit any byte of data in a single transfer
    *
    *******************************************************************************/
    void PSoC4_PutChar(uint8 txDataByte) 
    {
    #if (PSoC4_TX_INTERRUPT_ENABLED)
        /* The temporary output pointer is used since it takes two instructions
        *  to increment with a wrap, and we can't risk doing that with the real
        *  pointer and getting an interrupt in between instructions.
        */
        uint8 locTxBufferWrite;
        uint8 locTxBufferRead;

        do
        { /* Block if software buffer is full, so we don't overwrite. */

        #if ((PSoC4_TX_BUFFER_SIZE > PSoC4_MAX_BYTE_VALUE) && (CY_PSOC3))
            /* Disable TX interrupt to protect variables from modification */
            PSoC4_DisableTxInt();
        #endif /* (PSoC4_TX_BUFFER_SIZE > PSoC4_MAX_BYTE_VALUE) && (CY_PSOC3) */

            locTxBufferWrite = PSoC4_txBufferWrite;
            locTxBufferRead  = PSoC4_txBufferRead;

        #if ((PSoC4_TX_BUFFER_SIZE > PSoC4_MAX_BYTE_VALUE) && (CY_PSOC3))
            /* Enable interrupt to continue transmission */
            PSoC4_EnableTxInt();
        #endif /* (PSoC4_TX_BUFFER_SIZE > PSoC4_MAX_BYTE_VALUE) && (CY_PSOC3) */
        }
        while( (locTxBufferWrite < locTxBufferRead) ? (locTxBufferWrite == (locTxBufferRead - 1u)) :
                                ((locTxBufferWrite - locTxBufferRead) ==
                                (uint8)(PSoC4_TX_BUFFER_SIZE - 1u)) );

        if( (locTxBufferRead == locTxBufferWrite) &&
            ((PSoC4_TXSTATUS_REG & PSoC4_TX_STS_FIFO_FULL) == 0u) )
        {
            /* Add directly to the FIFO */
            PSoC4_TXDATA_REG = txDataByte;
        }
        else
        {
            if(locTxBufferWrite >= PSoC4_TX_BUFFER_SIZE)
            {
                locTxBufferWrite = 0u;
            }
            /* Add to the software buffer. */
            PSoC4_txBuffer[locTxBufferWrite] = txDataByte;
            locTxBufferWrite++;

            /* Finally, update the real output pointer */
        #if ((PSoC4_TX_BUFFER_SIZE > PSoC4_MAX_BYTE_VALUE) && (CY_PSOC3))
            PSoC4_DisableTxInt();
        #endif /* (PSoC4_TX_BUFFER_SIZE > PSoC4_MAX_BYTE_VALUE) && (CY_PSOC3) */

            PSoC4_txBufferWrite = locTxBufferWrite;

        #if ((PSoC4_TX_BUFFER_SIZE > PSoC4_MAX_BYTE_VALUE) && (CY_PSOC3))
            PSoC4_EnableTxInt();
        #endif /* (PSoC4_TX_BUFFER_SIZE > PSoC4_MAX_BYTE_VALUE) && (CY_PSOC3) */

            if(0u != (PSoC4_TXSTATUS_REG & PSoC4_TX_STS_FIFO_EMPTY))
            {
                /* Trigger TX interrupt to send software buffer */
                PSoC4_SetPendingTxInt();
            }
        }

    #else

        while((PSoC4_TXSTATUS_REG & PSoC4_TX_STS_FIFO_FULL) != 0u)
        {
            /* Wait for room in the FIFO */
        }

        /* Add directly to the FIFO */
        PSoC4_TXDATA_REG = txDataByte;

    #endif /* PSoC4_TX_INTERRUPT_ENABLED */
    }


    /*******************************************************************************
    * Function Name: PSoC4_PutString
    ********************************************************************************
    *
    * Summary:
    *  Sends a NULL terminated string to the TX buffer for transmission.
    *
    * Parameters:
    *  string[]: Pointer to the null terminated string array residing in RAM or ROM
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  PSoC4_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  If there is not enough memory in the TX buffer for the entire string, this
    *  function blocks until the last character of the string is loaded into the
    *  TX buffer.
    *
    *******************************************************************************/
    void PSoC4_PutString(const char8 string[]) 
    {
        uint16 bufIndex = 0u;

        /* If not Initialized then skip this function */
        if(PSoC4_initVar != 0u)
        {
            /* This is a blocking function, it will not exit until all data is sent */
            while(string[bufIndex] != (char8) 0)
            {
                PSoC4_PutChar((uint8)string[bufIndex]);
                bufIndex++;
            }
        }
    }


    /*******************************************************************************
    * Function Name: PSoC4_PutArray
    ********************************************************************************
    *
    * Summary:
    *  Places N bytes of data from a memory array into the TX buffer for
    *  transmission.
    *
    * Parameters:
    *  string[]: Address of the memory array residing in RAM or ROM.
    *  byteCount: Number of bytes to be transmitted. The type depends on TX Buffer
    *             Size parameter.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  PSoC4_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  If there is not enough memory in the TX buffer for the entire string, this
    *  function blocks until the last character of the string is loaded into the
    *  TX buffer.
    *
    *******************************************************************************/
    void PSoC4_PutArray(const uint8 string[], uint8 byteCount)
                                                                    
    {
        uint8 bufIndex = 0u;

        /* If not Initialized then skip this function */
        if(PSoC4_initVar != 0u)
        {
            while(bufIndex < byteCount)
            {
                PSoC4_PutChar(string[bufIndex]);
                bufIndex++;
            }
        }
    }


    /*******************************************************************************
    * Function Name: PSoC4_PutCRLF
    ********************************************************************************
    *
    * Summary:
    *  Writes a byte of data followed by a carriage return (0x0D) and line feed
    *  (0x0A) to the transmit buffer.
    *
    * Parameters:
    *  txDataByte: Data byte to transmit before the carriage return and line feed.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  PSoC4_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    void PSoC4_PutCRLF(uint8 txDataByte) 
    {
        /* If not Initialized then skip this function */
        if(PSoC4_initVar != 0u)
        {
            PSoC4_PutChar(txDataByte);
            PSoC4_PutChar(0x0Du);
            PSoC4_PutChar(0x0Au);
        }
    }


    /*******************************************************************************
    * Function Name: PSoC4_GetTxBufferSize
    ********************************************************************************
    *
    * Summary:
    *  Returns the number of bytes in the TX buffer which are waiting to be 
    *  transmitted.
    *  * TX software buffer is disabled (TX Buffer Size parameter is equal to 4): 
    *    returns 0 for empty TX FIFO, 1 for not full TX FIFO or 4 for full TX FIFO.
    *  * TX software buffer is enabled: returns the number of bytes in the TX 
    *    software buffer which are waiting to be transmitted. Bytes available in the
    *    TX FIFO do not count.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Number of bytes used in the TX buffer. Return value type depends on the TX 
    *  Buffer Size parameter.
    *
    * Global Variables:
    *  PSoC4_txBufferWrite - used to calculate left space.
    *  PSoC4_txBufferRead - used to calculate left space.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Allows the user to find out how full the TX Buffer is.
    *
    *******************************************************************************/
    uint8 PSoC4_GetTxBufferSize(void)
                                                            
    {
        uint8 size;

    #if (PSoC4_TX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt. */
        PSoC4_DisableTxInt();

        if(PSoC4_txBufferRead == PSoC4_txBufferWrite)
        {
            size = 0u;
        }
        else if(PSoC4_txBufferRead < PSoC4_txBufferWrite)
        {
            size = (PSoC4_txBufferWrite - PSoC4_txBufferRead);
        }
        else
        {
            size = (PSoC4_TX_BUFFER_SIZE - PSoC4_txBufferRead) +
                    PSoC4_txBufferWrite;
        }

        PSoC4_EnableTxInt();

    #else

        size = PSoC4_TXSTATUS_REG;

        /* Is the fifo is full. */
        if((size & PSoC4_TX_STS_FIFO_FULL) != 0u)
        {
            size = PSoC4_FIFO_LENGTH;
        }
        else if((size & PSoC4_TX_STS_FIFO_EMPTY) != 0u)
        {
            size = 0u;
        }
        else
        {
            /* We only know there is data in the fifo. */
            size = 1u;
        }

    #endif /* (PSoC4_TX_INTERRUPT_ENABLED) */

    return(size);
    }


    /*******************************************************************************
    * Function Name: PSoC4_ClearTxBuffer
    ********************************************************************************
    *
    * Summary:
    *  Clears all data from the TX buffer and hardware TX FIFO.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  PSoC4_txBufferWrite - cleared to zero.
    *  PSoC4_txBufferRead - cleared to zero.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Setting the pointers to zero makes the system believe there is no data to
    *  read and writing will resume at address 0 overwriting any data that may have
    *  remained in the RAM.
    *
    * Side Effects:
    *  Data waiting in the transmit buffer is not sent; a byte that is currently
    *  transmitting finishes transmitting.
    *
    *******************************************************************************/
    void PSoC4_ClearTxBuffer(void) 
    {
        uint8 enableInterrupts;

        enableInterrupts = CyEnterCriticalSection();
        /* Clear the HW FIFO */
        PSoC4_TXDATA_AUX_CTL_REG |= (uint8)  PSoC4_TX_FIFO_CLR;
        PSoC4_TXDATA_AUX_CTL_REG &= (uint8) ~PSoC4_TX_FIFO_CLR;
        CyExitCriticalSection(enableInterrupts);

    #if (PSoC4_TX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt. */
        PSoC4_DisableTxInt();

        PSoC4_txBufferRead = 0u;
        PSoC4_txBufferWrite = 0u;

        /* Enable Tx interrupt. */
        PSoC4_EnableTxInt();

    #endif /* (PSoC4_TX_INTERRUPT_ENABLED) */
    }


    /*******************************************************************************
    * Function Name: PSoC4_SendBreak
    ********************************************************************************
    *
    * Summary:
    *  Transmits a break signal on the bus.
    *
    * Parameters:
    *  uint8 retMode:  Send Break return mode. See the following table for options.
    *   PSoC4_SEND_BREAK - Initialize registers for break, send the Break
    *       signal and return immediately.
    *   PSoC4_WAIT_FOR_COMPLETE_REINIT - Wait until break transmission is
    *       complete, reinitialize registers to normal transmission mode then return
    *   PSoC4_REINIT - Reinitialize registers to normal transmission mode
    *       then return.
    *   PSoC4_SEND_WAIT_REINIT - Performs both options: 
    *      PSoC4_SEND_BREAK and PSoC4_WAIT_FOR_COMPLETE_REINIT.
    *      This option is recommended for most cases.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  PSoC4_initVar - checked to identify that the component has been
    *     initialized.
    *  txPeriod - static variable, used for keeping TX period configuration.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  SendBreak function initializes registers to send 13-bit break signal. It is
    *  important to return the registers configuration to normal for continue 8-bit
    *  operation.
    *  There are 3 variants for this API usage:
    *  1) SendBreak(3) - function will send the Break signal and take care on the
    *     configuration returning. Function will block CPU until transmission
    *     complete.
    *  2) User may want to use blocking time if UART configured to the low speed
    *     operation
    *     Example for this case:
    *     SendBreak(0);     - initialize Break signal transmission
    *         Add your code here to use CPU time
    *     SendBreak(1);     - complete Break operation
    *  3) Same to 2) but user may want to initialize and use the interrupt to
    *     complete break operation.
    *     Example for this case:
    *     Initialize TX interrupt with "TX - On TX Complete" parameter
    *     SendBreak(0);     - initialize Break signal transmission
    *         Add your code here to use CPU time
    *     When interrupt appear with PSoC4_TX_STS_COMPLETE status:
    *     SendBreak(2);     - complete Break operation
    *
    * Side Effects:
    *  The PSoC4_SendBreak() function initializes registers to send a
    *  break signal.
    *  Break signal length depends on the break signal bits configuration.
    *  The register configuration should be reinitialized before normal 8-bit
    *  communication can continue.
    *
    *******************************************************************************/
    void PSoC4_SendBreak(uint8 retMode) 
    {

        /* If not Initialized then skip this function*/
        if(PSoC4_initVar != 0u)
        {
            /* Set the Counter to 13-bits and transmit a 00 byte */
            /* When that is done then reset the counter value back */
            uint8 tmpStat;

        #if(PSoC4_HD_ENABLED) /* Half Duplex mode*/

            if( (retMode == PSoC4_SEND_BREAK) ||
                (retMode == PSoC4_SEND_WAIT_REINIT ) )
            {
                /* CTRL_HD_SEND_BREAK - sends break bits in HD mode */
                PSoC4_WriteControlRegister(PSoC4_ReadControlRegister() |
                                                      PSoC4_CTRL_HD_SEND_BREAK);
                /* Send zeros */
                PSoC4_TXDATA_REG = 0u;

                do /* Wait until transmit starts */
                {
                    tmpStat = PSoC4_TXSTATUS_REG;
                }
                while((tmpStat & PSoC4_TX_STS_FIFO_EMPTY) != 0u);
            }

            if( (retMode == PSoC4_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == PSoC4_SEND_WAIT_REINIT) )
            {
                do /* Wait until transmit complete */
                {
                    tmpStat = PSoC4_TXSTATUS_REG;
                }
                while(((uint8)~tmpStat & PSoC4_TX_STS_COMPLETE) != 0u);
            }

            if( (retMode == PSoC4_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == PSoC4_REINIT) ||
                (retMode == PSoC4_SEND_WAIT_REINIT) )
            {
                PSoC4_WriteControlRegister(PSoC4_ReadControlRegister() &
                                              (uint8)~PSoC4_CTRL_HD_SEND_BREAK);
            }

        #else /* PSoC4_HD_ENABLED Full Duplex mode */

            static uint8 txPeriod;

            if( (retMode == PSoC4_SEND_BREAK) ||
                (retMode == PSoC4_SEND_WAIT_REINIT) )
            {
                /* CTRL_HD_SEND_BREAK - skip to send parity bit at Break signal in Full Duplex mode */
                #if( (PSoC4_PARITY_TYPE != PSoC4__B_UART__NONE_REVB) || \
                                    (PSoC4_PARITY_TYPE_SW != 0u) )
                    PSoC4_WriteControlRegister(PSoC4_ReadControlRegister() |
                                                          PSoC4_CTRL_HD_SEND_BREAK);
                #endif /* End PSoC4_PARITY_TYPE != PSoC4__B_UART__NONE_REVB  */

                #if(PSoC4_TXCLKGEN_DP)
                    txPeriod = PSoC4_TXBITCLKTX_COMPLETE_REG;
                    PSoC4_TXBITCLKTX_COMPLETE_REG = PSoC4_TXBITCTR_BREAKBITS;
                #else
                    txPeriod = PSoC4_TXBITCTR_PERIOD_REG;
                    PSoC4_TXBITCTR_PERIOD_REG = PSoC4_TXBITCTR_BREAKBITS8X;
                #endif /* End PSoC4_TXCLKGEN_DP */

                /* Send zeros */
                PSoC4_TXDATA_REG = 0u;

                do /* Wait until transmit starts */
                {
                    tmpStat = PSoC4_TXSTATUS_REG;
                }
                while((tmpStat & PSoC4_TX_STS_FIFO_EMPTY) != 0u);
            }

            if( (retMode == PSoC4_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == PSoC4_SEND_WAIT_REINIT) )
            {
                do /* Wait until transmit complete */
                {
                    tmpStat = PSoC4_TXSTATUS_REG;
                }
                while(((uint8)~tmpStat & PSoC4_TX_STS_COMPLETE) != 0u);
            }

            if( (retMode == PSoC4_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == PSoC4_REINIT) ||
                (retMode == PSoC4_SEND_WAIT_REINIT) )
            {

            #if(PSoC4_TXCLKGEN_DP)
                PSoC4_TXBITCLKTX_COMPLETE_REG = txPeriod;
            #else
                PSoC4_TXBITCTR_PERIOD_REG = txPeriod;
            #endif /* End PSoC4_TXCLKGEN_DP */

            #if( (PSoC4_PARITY_TYPE != PSoC4__B_UART__NONE_REVB) || \
                 (PSoC4_PARITY_TYPE_SW != 0u) )
                PSoC4_WriteControlRegister(PSoC4_ReadControlRegister() &
                                                      (uint8) ~PSoC4_CTRL_HD_SEND_BREAK);
            #endif /* End PSoC4_PARITY_TYPE != NONE */
            }
        #endif    /* End PSoC4_HD_ENABLED */
        }
    }


    /*******************************************************************************
    * Function Name: PSoC4_SetTxAddressMode
    ********************************************************************************
    *
    * Summary:
    *  Configures the transmitter to signal the next bytes is address or data.
    *
    * Parameters:
    *  addressMode: 
    *       PSoC4_SET_SPACE - Configure the transmitter to send the next
    *                                    byte as a data.
    *       PSoC4_SET_MARK  - Configure the transmitter to send the next
    *                                    byte as an address.
    *
    * Return:
    *  None.
    *
    * Side Effects:
    *  This function sets and clears PSoC4_CTRL_MARK bit in the Control
    *  register.
    *
    *******************************************************************************/
    void PSoC4_SetTxAddressMode(uint8 addressMode) 
    {
        /* Mark/Space sending enable */
        if(addressMode != 0u)
        {
        #if( PSoC4_CONTROL_REG_REMOVED == 0u )
            PSoC4_WriteControlRegister(PSoC4_ReadControlRegister() |
                                                  PSoC4_CTRL_MARK);
        #endif /* End PSoC4_CONTROL_REG_REMOVED == 0u */
        }
        else
        {
        #if( PSoC4_CONTROL_REG_REMOVED == 0u )
            PSoC4_WriteControlRegister(PSoC4_ReadControlRegister() &
                                                  (uint8) ~PSoC4_CTRL_MARK);
        #endif /* End PSoC4_CONTROL_REG_REMOVED == 0u */
        }
    }

#endif  /* EndPSoC4_TX_ENABLED */

#if(PSoC4_HD_ENABLED)


    /*******************************************************************************
    * Function Name: PSoC4_LoadRxConfig
    ********************************************************************************
    *
    * Summary:
    *  Loads the receiver configuration in half duplex mode. After calling this
    *  function, the UART is ready to receive data.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Side Effects:
    *  Valid only in half duplex mode. You must make sure that the previous
    *  transaction is complete and it is safe to unload the transmitter
    *  configuration.
    *
    *******************************************************************************/
    void PSoC4_LoadRxConfig(void) 
    {
        PSoC4_WriteControlRegister(PSoC4_ReadControlRegister() &
                                                (uint8)~PSoC4_CTRL_HD_SEND);
        PSoC4_RXBITCTR_PERIOD_REG = PSoC4_HD_RXBITCTR_INIT;

    #if (PSoC4_RX_INTERRUPT_ENABLED)
        /* Enable RX interrupt after set RX configuration */
        PSoC4_SetRxInterruptMode(PSoC4_INIT_RX_INTERRUPTS_MASK);
    #endif /* (PSoC4_RX_INTERRUPT_ENABLED) */
    }


    /*******************************************************************************
    * Function Name: PSoC4_LoadTxConfig
    ********************************************************************************
    *
    * Summary:
    *  Loads the transmitter configuration in half duplex mode. After calling this
    *  function, the UART is ready to transmit data.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Side Effects:
    *  Valid only in half duplex mode. You must make sure that the previous
    *  transaction is complete and it is safe to unload the receiver configuration.
    *
    *******************************************************************************/
    void PSoC4_LoadTxConfig(void) 
    {
    #if (PSoC4_RX_INTERRUPT_ENABLED)
        /* Disable RX interrupts before set TX configuration */
        PSoC4_SetRxInterruptMode(0u);
    #endif /* (PSoC4_RX_INTERRUPT_ENABLED) */

        PSoC4_WriteControlRegister(PSoC4_ReadControlRegister() | PSoC4_CTRL_HD_SEND);
        PSoC4_RXBITCTR_PERIOD_REG = PSoC4_HD_TXBITCTR_INIT;
    }

#endif  /* PSoC4_HD_ENABLED */


/* [] END OF FILE */
