/*******************************************************************************
* File Name: PSoC4INT.c
* Version 2.50
*
* Description:
*  This file provides all Interrupt Service functionality of the UART component
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "PSoC4.h"



/***************************************
* Custom Declarations
***************************************/
/* `#START CUSTOM_DECLARATIONS` Place your declaration here */

/* `#END` */

#if (PSoC4_RX_INTERRUPT_ENABLED && (PSoC4_RX_ENABLED || PSoC4_HD_ENABLED))
    /*******************************************************************************
    * Function Name: PSoC4_RXISR
    ********************************************************************************
    *
    * Summary:
    *  Interrupt Service Routine for RX portion of the UART
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  PSoC4_rxBuffer - RAM buffer pointer for save received data.
    *  PSoC4_rxBufferWrite - cyclic index for write to rxBuffer,
    *     increments after each byte saved to buffer.
    *  PSoC4_rxBufferRead - cyclic index for read from rxBuffer,
    *     checked to detect overflow condition.
    *  PSoC4_rxBufferOverflow - software overflow flag. Set to one
    *     when PSoC4_rxBufferWrite index overtakes
    *     PSoC4_rxBufferRead index.
    *  PSoC4_rxBufferLoopDetect - additional variable to detect overflow.
    *     Set to one when PSoC4_rxBufferWrite is equal to
    *    PSoC4_rxBufferRead
    *  PSoC4_rxAddressMode - this variable contains the Address mode,
    *     selected in customizer or set by UART_SetRxAddressMode() API.
    *  PSoC4_rxAddressDetected - set to 1 when correct address received,
    *     and analysed to store following addressed data bytes to the buffer.
    *     When not correct address received, set to 0 to skip following data bytes.
    *
    *******************************************************************************/
    CY_ISR(PSoC4_RXISR)
    {
        uint8 readData;
        uint8 readStatus;
        uint8 increment_pointer = 0u;

    #if(CY_PSOC3)
        uint8 int_en;
    #endif /* (CY_PSOC3) */

    #ifdef PSoC4_RXISR_ENTRY_CALLBACK
        PSoC4_RXISR_EntryCallback();
    #endif /* PSoC4_RXISR_ENTRY_CALLBACK */

        /* User code required at start of ISR */
        /* `#START PSoC4_RXISR_START` */

        /* `#END` */

    #if(CY_PSOC3)   /* Make sure nested interrupt is enabled */
        int_en = EA;
        CyGlobalIntEnable;
    #endif /* (CY_PSOC3) */

        do
        {
            /* Read receiver status register */
            readStatus = PSoC4_RXSTATUS_REG;
            /* Copy the same status to readData variable for backward compatibility support 
            *  of the user code in PSoC4_RXISR_ERROR` section. 
            */
            readData = readStatus;

            if((readStatus & (PSoC4_RX_STS_BREAK | 
                            PSoC4_RX_STS_PAR_ERROR |
                            PSoC4_RX_STS_STOP_ERROR | 
                            PSoC4_RX_STS_OVERRUN)) != 0u)
            {
                /* ERROR handling. */
                PSoC4_errorStatus |= readStatus & ( PSoC4_RX_STS_BREAK | 
                                                            PSoC4_RX_STS_PAR_ERROR | 
                                                            PSoC4_RX_STS_STOP_ERROR | 
                                                            PSoC4_RX_STS_OVERRUN);
                /* `#START PSoC4_RXISR_ERROR` */

                /* `#END` */
                
            #ifdef PSoC4_RXISR_ERROR_CALLBACK
                PSoC4_RXISR_ERROR_Callback();
            #endif /* PSoC4_RXISR_ERROR_CALLBACK */
            }
            
            if((readStatus & PSoC4_RX_STS_FIFO_NOTEMPTY) != 0u)
            {
                /* Read data from the RX data register */
                readData = PSoC4_RXDATA_REG;
            #if (PSoC4_RXHW_ADDRESS_ENABLED)
                if(PSoC4_rxAddressMode == (uint8)PSoC4__B_UART__AM_SW_DETECT_TO_BUFFER)
                {
                    if((readStatus & PSoC4_RX_STS_MRKSPC) != 0u)
                    {
                        if ((readStatus & PSoC4_RX_STS_ADDR_MATCH) != 0u)
                        {
                            PSoC4_rxAddressDetected = 1u;
                        }
                        else
                        {
                            PSoC4_rxAddressDetected = 0u;
                        }
                    }
                    if(PSoC4_rxAddressDetected != 0u)
                    {   /* Store only addressed data */
                        PSoC4_rxBuffer[PSoC4_rxBufferWrite] = readData;
                        increment_pointer = 1u;
                    }
                }
                else /* Without software addressing */
                {
                    PSoC4_rxBuffer[PSoC4_rxBufferWrite] = readData;
                    increment_pointer = 1u;
                }
            #else  /* Without addressing */
                PSoC4_rxBuffer[PSoC4_rxBufferWrite] = readData;
                increment_pointer = 1u;
            #endif /* (PSoC4_RXHW_ADDRESS_ENABLED) */

                /* Do not increment buffer pointer when skip not addressed data */
                if(increment_pointer != 0u)
                {
                    if(PSoC4_rxBufferLoopDetect != 0u)
                    {   /* Set Software Buffer status Overflow */
                        PSoC4_rxBufferOverflow = 1u;
                    }
                    /* Set next pointer. */
                    PSoC4_rxBufferWrite++;

                    /* Check pointer for a loop condition */
                    if(PSoC4_rxBufferWrite >= PSoC4_RX_BUFFER_SIZE)
                    {
                        PSoC4_rxBufferWrite = 0u;
                    }

                    /* Detect pre-overload condition and set flag */
                    if(PSoC4_rxBufferWrite == PSoC4_rxBufferRead)
                    {
                        PSoC4_rxBufferLoopDetect = 1u;
                        /* When Hardware Flow Control selected */
                        #if (PSoC4_FLOW_CONTROL != 0u)
                            /* Disable RX interrupt mask, it is enabled when user read data from the buffer using APIs */
                            PSoC4_RXSTATUS_MASK_REG  &= (uint8)~PSoC4_RX_STS_FIFO_NOTEMPTY;
                            CyIntClearPending(PSoC4_RX_VECT_NUM);
                            break; /* Break the reading of the FIFO loop, leave the data there for generating RTS signal */
                        #endif /* (PSoC4_FLOW_CONTROL != 0u) */
                    }
                }
            }
        }while((readStatus & PSoC4_RX_STS_FIFO_NOTEMPTY) != 0u);

        /* User code required at end of ISR (Optional) */
        /* `#START PSoC4_RXISR_END` */

        /* `#END` */

    #ifdef PSoC4_RXISR_EXIT_CALLBACK
        PSoC4_RXISR_ExitCallback();
    #endif /* PSoC4_RXISR_EXIT_CALLBACK */

    #if(CY_PSOC3)
        EA = int_en;
    #endif /* (CY_PSOC3) */
    }
    
#endif /* (PSoC4_RX_INTERRUPT_ENABLED && (PSoC4_RX_ENABLED || PSoC4_HD_ENABLED)) */


#if (PSoC4_TX_INTERRUPT_ENABLED && PSoC4_TX_ENABLED)
    /*******************************************************************************
    * Function Name: PSoC4_TXISR
    ********************************************************************************
    *
    * Summary:
    * Interrupt Service Routine for the TX portion of the UART
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  PSoC4_txBuffer - RAM buffer pointer for transmit data from.
    *  PSoC4_txBufferRead - cyclic index for read and transmit data
    *     from txBuffer, increments after each transmitted byte.
    *  PSoC4_rxBufferWrite - cyclic index for write to txBuffer,
    *     checked to detect available for transmission bytes.
    *
    *******************************************************************************/
    CY_ISR(PSoC4_TXISR)
    {
    #if(CY_PSOC3)
        uint8 int_en;
    #endif /* (CY_PSOC3) */

    #ifdef PSoC4_TXISR_ENTRY_CALLBACK
        PSoC4_TXISR_EntryCallback();
    #endif /* PSoC4_TXISR_ENTRY_CALLBACK */

        /* User code required at start of ISR */
        /* `#START PSoC4_TXISR_START` */

        /* `#END` */

    #if(CY_PSOC3)   /* Make sure nested interrupt is enabled */
        int_en = EA;
        CyGlobalIntEnable;
    #endif /* (CY_PSOC3) */

        while((PSoC4_txBufferRead != PSoC4_txBufferWrite) &&
             ((PSoC4_TXSTATUS_REG & PSoC4_TX_STS_FIFO_FULL) == 0u))
        {
            /* Check pointer wrap around */
            if(PSoC4_txBufferRead >= PSoC4_TX_BUFFER_SIZE)
            {
                PSoC4_txBufferRead = 0u;
            }

            PSoC4_TXDATA_REG = PSoC4_txBuffer[PSoC4_txBufferRead];

            /* Set next pointer */
            PSoC4_txBufferRead++;
        }

        /* User code required at end of ISR (Optional) */
        /* `#START PSoC4_TXISR_END` */

        /* `#END` */

    #ifdef PSoC4_TXISR_EXIT_CALLBACK
        PSoC4_TXISR_ExitCallback();
    #endif /* PSoC4_TXISR_EXIT_CALLBACK */

    #if(CY_PSOC3)
        EA = int_en;
    #endif /* (CY_PSOC3) */
   }
#endif /* (PSoC4_TX_INTERRUPT_ENABLED && PSoC4_TX_ENABLED) */


/* [] END OF FILE */
