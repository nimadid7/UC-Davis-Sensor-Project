/*******************************************************************************
* File Name: VOC.c
* Version 3.50
*
* Description:
*  This file provides the source code of APIs for the I2C component.
*  The actual protocol and operation code resides in the interrupt service
*  routine file.
*
*******************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "VOC_PVT.h"


/**********************************
*      System variables
**********************************/

uint8 VOC_initVar = 0u; /* Defines if component was initialized */

volatile uint8 VOC_state;  /* Current state of I2C FSM */


/*******************************************************************************
* Function Name: VOC_Init
********************************************************************************
*
* Summary:
*  Initializes I2C registers with initial values provided from customizer.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void VOC_Init(void) 
{
#if (VOC_FF_IMPLEMENTED)
    /* Configure fixed function block */
    VOC_CFG_REG  = VOC_DEFAULT_CFG;
    VOC_XCFG_REG = VOC_DEFAULT_XCFG;
    VOC_ADDR_REG = VOC_DEFAULT_ADDR;
    VOC_CLKDIV1_REG = LO8(VOC_DEFAULT_DIVIDE_FACTOR);
    VOC_CLKDIV2_REG = HI8(VOC_DEFAULT_DIVIDE_FACTOR);

#else
    uint8 intState;

    /* Configure control and interrupt sources */
    VOC_CFG_REG      = VOC_DEFAULT_CFG;
    VOC_INT_MASK_REG = VOC_DEFAULT_INT_MASK;

    /* Enable interrupt generation in status */
    intState = CyEnterCriticalSection();
    VOC_INT_ENABLE_REG |= VOC_INTR_ENABLE;
    CyExitCriticalSection(intState);

    /* Configure bit counter */
    #if (VOC_MODE_SLAVE_ENABLED)
        VOC_PERIOD_REG = VOC_DEFAULT_PERIOD;
    #endif  /* (VOC_MODE_SLAVE_ENABLED) */

    /* Configure clock generator */
    #if (VOC_MODE_MASTER_ENABLED)
        VOC_MCLK_PRD_REG = VOC_DEFAULT_MCLK_PRD;
        VOC_MCLK_CMP_REG = VOC_DEFAULT_MCLK_CMP;
    #endif /* (VOC_MODE_MASTER_ENABLED) */
#endif /* (VOC_FF_IMPLEMENTED) */

#if (VOC_TIMEOUT_ENABLED)
    VOC_TimeoutInit();
#endif /* (VOC_TIMEOUT_ENABLED) */

    /* Configure internal interrupt */
    CyIntDisable    (VOC_ISR_NUMBER);
    CyIntSetPriority(VOC_ISR_NUMBER, VOC_ISR_PRIORITY);
    #if (VOC_INTERN_I2C_INTR_HANDLER)
        (void) CyIntSetVector(VOC_ISR_NUMBER, &VOC_ISR);
    #endif /* (VOC_INTERN_I2C_INTR_HANDLER) */

    /* Set FSM to default state */
    VOC_state = VOC_SM_IDLE;

#if (VOC_MODE_SLAVE_ENABLED)
    /* Clear status and buffers index */
    VOC_slStatus = 0u;
    VOC_slRdBufIndex = 0u;
    VOC_slWrBufIndex = 0u;

    /* Configure matched address */
    VOC_SlaveSetAddress(VOC_DEFAULT_ADDR);
#endif /* (VOC_MODE_SLAVE_ENABLED) */

#if (VOC_MODE_MASTER_ENABLED)
    /* Clear status and buffers index */
    VOC_mstrStatus = 0u;
    VOC_mstrRdBufIndex = 0u;
    VOC_mstrWrBufIndex = 0u;
#endif /* (VOC_MODE_MASTER_ENABLED) */
}


/*******************************************************************************
* Function Name: VOC_Enable
********************************************************************************
*
* Summary:
*  Enables I2C operations.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  None.
*
*******************************************************************************/
void VOC_Enable(void) 
{
#if (VOC_FF_IMPLEMENTED)
    uint8 intState;

    /* Enable power to block */
    intState = CyEnterCriticalSection();
    VOC_ACT_PWRMGR_REG  |= VOC_ACT_PWR_EN;
    VOC_STBY_PWRMGR_REG |= VOC_STBY_PWR_EN;
    CyExitCriticalSection(intState);
#else
    #if (VOC_MODE_SLAVE_ENABLED)
        /* Enable bit counter */
        uint8 intState = CyEnterCriticalSection();
        VOC_COUNTER_AUX_CTL_REG |= VOC_CNT7_ENABLE;
        CyExitCriticalSection(intState);
    #endif /* (VOC_MODE_SLAVE_ENABLED) */

    /* Enable slave or master bits */
    VOC_CFG_REG |= VOC_ENABLE_MS;
#endif /* (VOC_FF_IMPLEMENTED) */

#if (VOC_TIMEOUT_ENABLED)
    VOC_TimeoutEnable();
#endif /* (VOC_TIMEOUT_ENABLED) */
}


/*******************************************************************************
* Function Name: VOC_Start
********************************************************************************
*
* Summary:
*  Starts the I2C hardware. Enables Active mode power template bits or clock
*  gating as appropriate. It is required to be executed before I2C bus
*  operation.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Side Effects:
*  This component automatically enables its interrupt.  If I2C is enabled !
*  without the interrupt enabled, it can lock up the I2C bus.
*
* Global variables:
*  VOC_initVar - This variable is used to check the initial
*                             configuration, modified on the first
*                             function call.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void VOC_Start(void) 
{
    if (0u == VOC_initVar)
    {
        VOC_Init();
        VOC_initVar = 1u; /* Component initialized */
    }

    VOC_Enable();
    VOC_EnableInt();
}


/*******************************************************************************
* Function Name: VOC_Stop
********************************************************************************
*
* Summary:
*  Disables I2C hardware and disables I2C interrupt. Disables Active mode power
*  template bits or clock gating as appropriate.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void VOC_Stop(void) 
{
    VOC_DisableInt();

#if (VOC_TIMEOUT_ENABLED)
    VOC_TimeoutStop();
#endif  /* End (VOC_TIMEOUT_ENABLED) */

#if (VOC_FF_IMPLEMENTED)
    {
        uint8 intState;
        uint16 blockResetCycles;

        /* Store registers effected by block disable */
        VOC_backup.addr    = VOC_ADDR_REG;
        VOC_backup.clkDiv1 = VOC_CLKDIV1_REG;
        VOC_backup.clkDiv2 = VOC_CLKDIV2_REG;

        /* Calculate number of cycles to reset block */
        blockResetCycles = ((uint16) ((uint16) VOC_CLKDIV2_REG << 8u) | VOC_CLKDIV1_REG) + 1u;

        /* Disable block */
        VOC_CFG_REG &= (uint8) ~VOC_CFG_EN_SLAVE;
        /* Wait for block reset before disable power */
        CyDelayCycles((uint32) blockResetCycles);

        /* Disable power to block */
        intState = CyEnterCriticalSection();
        VOC_ACT_PWRMGR_REG  &= (uint8) ~VOC_ACT_PWR_EN;
        VOC_STBY_PWRMGR_REG &= (uint8) ~VOC_STBY_PWR_EN;
        CyExitCriticalSection(intState);

        /* Enable block */
        VOC_CFG_REG |= (uint8) VOC_ENABLE_MS;

        /* Restore registers effected by block disable. Ticket ID#198004 */
        VOC_ADDR_REG    = VOC_backup.addr;
        VOC_ADDR_REG    = VOC_backup.addr;
        VOC_CLKDIV1_REG = VOC_backup.clkDiv1;
        VOC_CLKDIV2_REG = VOC_backup.clkDiv2;
    }
#else

    /* Disable slave or master bits */
    VOC_CFG_REG &= (uint8) ~VOC_ENABLE_MS;

#if (VOC_MODE_SLAVE_ENABLED)
    {
        /* Disable bit counter */
        uint8 intState = CyEnterCriticalSection();
        VOC_COUNTER_AUX_CTL_REG &= (uint8) ~VOC_CNT7_ENABLE;
        CyExitCriticalSection(intState);
    }
#endif /* (VOC_MODE_SLAVE_ENABLED) */

    /* Clear interrupt source register */
    (void) VOC_CSR_REG;
#endif /* (VOC_FF_IMPLEMENTED) */

    /* Disable interrupt on stop (enabled by write transaction) */
    VOC_DISABLE_INT_ON_STOP;
    VOC_ClearPendingInt();

    /* Reset FSM to default state */
    VOC_state = VOC_SM_IDLE;

    /* Clear busy statuses */
#if (VOC_MODE_SLAVE_ENABLED)
    VOC_slStatus &= (uint8) ~(VOC_SSTAT_RD_BUSY | VOC_SSTAT_WR_BUSY);
#endif /* (VOC_MODE_SLAVE_ENABLED) */
}


/* [] END OF FILE */
