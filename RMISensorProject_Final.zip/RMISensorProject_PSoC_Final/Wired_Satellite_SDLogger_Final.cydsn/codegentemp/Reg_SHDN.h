/*******************************************************************************
* File Name: Reg_SHDN.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Reg_SHDN_H) /* Pins Reg_SHDN_H */
#define CY_PINS_Reg_SHDN_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Reg_SHDN_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Reg_SHDN__PORT == 15 && ((Reg_SHDN__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Reg_SHDN_Write(uint8 value);
void    Reg_SHDN_SetDriveMode(uint8 mode);
uint8   Reg_SHDN_ReadDataReg(void);
uint8   Reg_SHDN_Read(void);
void    Reg_SHDN_SetInterruptMode(uint16 position, uint16 mode);
uint8   Reg_SHDN_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Reg_SHDN_SetDriveMode() function.
     *  @{
     */
        #define Reg_SHDN_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Reg_SHDN_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Reg_SHDN_DM_RES_UP          PIN_DM_RES_UP
        #define Reg_SHDN_DM_RES_DWN         PIN_DM_RES_DWN
        #define Reg_SHDN_DM_OD_LO           PIN_DM_OD_LO
        #define Reg_SHDN_DM_OD_HI           PIN_DM_OD_HI
        #define Reg_SHDN_DM_STRONG          PIN_DM_STRONG
        #define Reg_SHDN_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Reg_SHDN_MASK               Reg_SHDN__MASK
#define Reg_SHDN_SHIFT              Reg_SHDN__SHIFT
#define Reg_SHDN_WIDTH              1u

/* Interrupt constants */
#if defined(Reg_SHDN__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Reg_SHDN_SetInterruptMode() function.
     *  @{
     */
        #define Reg_SHDN_INTR_NONE      (uint16)(0x0000u)
        #define Reg_SHDN_INTR_RISING    (uint16)(0x0001u)
        #define Reg_SHDN_INTR_FALLING   (uint16)(0x0002u)
        #define Reg_SHDN_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Reg_SHDN_INTR_MASK      (0x01u) 
#endif /* (Reg_SHDN__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Reg_SHDN_PS                     (* (reg8 *) Reg_SHDN__PS)
/* Data Register */
#define Reg_SHDN_DR                     (* (reg8 *) Reg_SHDN__DR)
/* Port Number */
#define Reg_SHDN_PRT_NUM                (* (reg8 *) Reg_SHDN__PRT) 
/* Connect to Analog Globals */                                                  
#define Reg_SHDN_AG                     (* (reg8 *) Reg_SHDN__AG)                       
/* Analog MUX bux enable */
#define Reg_SHDN_AMUX                   (* (reg8 *) Reg_SHDN__AMUX) 
/* Bidirectional Enable */                                                        
#define Reg_SHDN_BIE                    (* (reg8 *) Reg_SHDN__BIE)
/* Bit-mask for Aliased Register Access */
#define Reg_SHDN_BIT_MASK               (* (reg8 *) Reg_SHDN__BIT_MASK)
/* Bypass Enable */
#define Reg_SHDN_BYP                    (* (reg8 *) Reg_SHDN__BYP)
/* Port wide control signals */                                                   
#define Reg_SHDN_CTL                    (* (reg8 *) Reg_SHDN__CTL)
/* Drive Modes */
#define Reg_SHDN_DM0                    (* (reg8 *) Reg_SHDN__DM0) 
#define Reg_SHDN_DM1                    (* (reg8 *) Reg_SHDN__DM1)
#define Reg_SHDN_DM2                    (* (reg8 *) Reg_SHDN__DM2) 
/* Input Buffer Disable Override */
#define Reg_SHDN_INP_DIS                (* (reg8 *) Reg_SHDN__INP_DIS)
/* LCD Common or Segment Drive */
#define Reg_SHDN_LCD_COM_SEG            (* (reg8 *) Reg_SHDN__LCD_COM_SEG)
/* Enable Segment LCD */
#define Reg_SHDN_LCD_EN                 (* (reg8 *) Reg_SHDN__LCD_EN)
/* Slew Rate Control */
#define Reg_SHDN_SLW                    (* (reg8 *) Reg_SHDN__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Reg_SHDN_PRTDSI__CAPS_SEL       (* (reg8 *) Reg_SHDN__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Reg_SHDN_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Reg_SHDN__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Reg_SHDN_PRTDSI__OE_SEL0        (* (reg8 *) Reg_SHDN__PRTDSI__OE_SEL0) 
#define Reg_SHDN_PRTDSI__OE_SEL1        (* (reg8 *) Reg_SHDN__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Reg_SHDN_PRTDSI__OUT_SEL0       (* (reg8 *) Reg_SHDN__PRTDSI__OUT_SEL0) 
#define Reg_SHDN_PRTDSI__OUT_SEL1       (* (reg8 *) Reg_SHDN__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Reg_SHDN_PRTDSI__SYNC_OUT       (* (reg8 *) Reg_SHDN__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Reg_SHDN__SIO_CFG)
    #define Reg_SHDN_SIO_HYST_EN        (* (reg8 *) Reg_SHDN__SIO_HYST_EN)
    #define Reg_SHDN_SIO_REG_HIFREQ     (* (reg8 *) Reg_SHDN__SIO_REG_HIFREQ)
    #define Reg_SHDN_SIO_CFG            (* (reg8 *) Reg_SHDN__SIO_CFG)
    #define Reg_SHDN_SIO_DIFF           (* (reg8 *) Reg_SHDN__SIO_DIFF)
#endif /* (Reg_SHDN__SIO_CFG) */

/* Interrupt Registers */
#if defined(Reg_SHDN__INTSTAT)
    #define Reg_SHDN_INTSTAT            (* (reg8 *) Reg_SHDN__INTSTAT)
    #define Reg_SHDN_SNAP               (* (reg8 *) Reg_SHDN__SNAP)
    
	#define Reg_SHDN_0_INTTYPE_REG 		(* (reg8 *) Reg_SHDN__0__INTTYPE)
#endif /* (Reg_SHDN__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Reg_SHDN_H */


/* [] END OF FILE */
