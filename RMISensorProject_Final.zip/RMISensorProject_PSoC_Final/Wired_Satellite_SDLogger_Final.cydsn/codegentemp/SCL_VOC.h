/*******************************************************************************
* File Name: SCL_VOC.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SCL_VOC_H) /* Pins SCL_VOC_H */
#define CY_PINS_SCL_VOC_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "SCL_VOC_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 SCL_VOC__PORT == 15 && ((SCL_VOC__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    SCL_VOC_Write(uint8 value);
void    SCL_VOC_SetDriveMode(uint8 mode);
uint8   SCL_VOC_ReadDataReg(void);
uint8   SCL_VOC_Read(void);
void    SCL_VOC_SetInterruptMode(uint16 position, uint16 mode);
uint8   SCL_VOC_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the SCL_VOC_SetDriveMode() function.
     *  @{
     */
        #define SCL_VOC_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define SCL_VOC_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define SCL_VOC_DM_RES_UP          PIN_DM_RES_UP
        #define SCL_VOC_DM_RES_DWN         PIN_DM_RES_DWN
        #define SCL_VOC_DM_OD_LO           PIN_DM_OD_LO
        #define SCL_VOC_DM_OD_HI           PIN_DM_OD_HI
        #define SCL_VOC_DM_STRONG          PIN_DM_STRONG
        #define SCL_VOC_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define SCL_VOC_MASK               SCL_VOC__MASK
#define SCL_VOC_SHIFT              SCL_VOC__SHIFT
#define SCL_VOC_WIDTH              1u

/* Interrupt constants */
#if defined(SCL_VOC__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in SCL_VOC_SetInterruptMode() function.
     *  @{
     */
        #define SCL_VOC_INTR_NONE      (uint16)(0x0000u)
        #define SCL_VOC_INTR_RISING    (uint16)(0x0001u)
        #define SCL_VOC_INTR_FALLING   (uint16)(0x0002u)
        #define SCL_VOC_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define SCL_VOC_INTR_MASK      (0x01u) 
#endif /* (SCL_VOC__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define SCL_VOC_PS                     (* (reg8 *) SCL_VOC__PS)
/* Data Register */
#define SCL_VOC_DR                     (* (reg8 *) SCL_VOC__DR)
/* Port Number */
#define SCL_VOC_PRT_NUM                (* (reg8 *) SCL_VOC__PRT) 
/* Connect to Analog Globals */                                                  
#define SCL_VOC_AG                     (* (reg8 *) SCL_VOC__AG)                       
/* Analog MUX bux enable */
#define SCL_VOC_AMUX                   (* (reg8 *) SCL_VOC__AMUX) 
/* Bidirectional Enable */                                                        
#define SCL_VOC_BIE                    (* (reg8 *) SCL_VOC__BIE)
/* Bit-mask for Aliased Register Access */
#define SCL_VOC_BIT_MASK               (* (reg8 *) SCL_VOC__BIT_MASK)
/* Bypass Enable */
#define SCL_VOC_BYP                    (* (reg8 *) SCL_VOC__BYP)
/* Port wide control signals */                                                   
#define SCL_VOC_CTL                    (* (reg8 *) SCL_VOC__CTL)
/* Drive Modes */
#define SCL_VOC_DM0                    (* (reg8 *) SCL_VOC__DM0) 
#define SCL_VOC_DM1                    (* (reg8 *) SCL_VOC__DM1)
#define SCL_VOC_DM2                    (* (reg8 *) SCL_VOC__DM2) 
/* Input Buffer Disable Override */
#define SCL_VOC_INP_DIS                (* (reg8 *) SCL_VOC__INP_DIS)
/* LCD Common or Segment Drive */
#define SCL_VOC_LCD_COM_SEG            (* (reg8 *) SCL_VOC__LCD_COM_SEG)
/* Enable Segment LCD */
#define SCL_VOC_LCD_EN                 (* (reg8 *) SCL_VOC__LCD_EN)
/* Slew Rate Control */
#define SCL_VOC_SLW                    (* (reg8 *) SCL_VOC__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define SCL_VOC_PRTDSI__CAPS_SEL       (* (reg8 *) SCL_VOC__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define SCL_VOC_PRTDSI__DBL_SYNC_IN    (* (reg8 *) SCL_VOC__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define SCL_VOC_PRTDSI__OE_SEL0        (* (reg8 *) SCL_VOC__PRTDSI__OE_SEL0) 
#define SCL_VOC_PRTDSI__OE_SEL1        (* (reg8 *) SCL_VOC__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define SCL_VOC_PRTDSI__OUT_SEL0       (* (reg8 *) SCL_VOC__PRTDSI__OUT_SEL0) 
#define SCL_VOC_PRTDSI__OUT_SEL1       (* (reg8 *) SCL_VOC__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define SCL_VOC_PRTDSI__SYNC_OUT       (* (reg8 *) SCL_VOC__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(SCL_VOC__SIO_CFG)
    #define SCL_VOC_SIO_HYST_EN        (* (reg8 *) SCL_VOC__SIO_HYST_EN)
    #define SCL_VOC_SIO_REG_HIFREQ     (* (reg8 *) SCL_VOC__SIO_REG_HIFREQ)
    #define SCL_VOC_SIO_CFG            (* (reg8 *) SCL_VOC__SIO_CFG)
    #define SCL_VOC_SIO_DIFF           (* (reg8 *) SCL_VOC__SIO_DIFF)
#endif /* (SCL_VOC__SIO_CFG) */

/* Interrupt Registers */
#if defined(SCL_VOC__INTSTAT)
    #define SCL_VOC_INTSTAT            (* (reg8 *) SCL_VOC__INTSTAT)
    #define SCL_VOC_SNAP               (* (reg8 *) SCL_VOC__SNAP)
    
	#define SCL_VOC_0_INTTYPE_REG 		(* (reg8 *) SCL_VOC__0__INTTYPE)
#endif /* (SCL_VOC__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_SCL_VOC_H */


/* [] END OF FILE */
