/*******************************************************************************
* File Name: COZIR.h
* Version 2.50
*
* Description:
*  Contains the function prototypes and constants available to the UART
*  user module.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/


#if !defined(CY_UART_COZIR_H)
#define CY_UART_COZIR_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CyLib.h"


/***************************************
* Conditional Compilation Parameters
***************************************/

#define COZIR_RX_ENABLED                     (1u)
#define COZIR_TX_ENABLED                     (1u)
#define COZIR_HD_ENABLED                     (0u)
#define COZIR_RX_INTERRUPT_ENABLED           (1u)
#define COZIR_TX_INTERRUPT_ENABLED           (1u)
#define COZIR_INTERNAL_CLOCK_USED            (1u)
#define COZIR_RXHW_ADDRESS_ENABLED           (0u)
#define COZIR_OVER_SAMPLE_COUNT              (8u)
#define COZIR_PARITY_TYPE                    (0u)
#define COZIR_PARITY_TYPE_SW                 (0u)
#define COZIR_BREAK_DETECT                   (0u)
#define COZIR_BREAK_BITS_TX                  (13u)
#define COZIR_BREAK_BITS_RX                  (13u)
#define COZIR_TXCLKGEN_DP                    (1u)
#define COZIR_USE23POLLING                   (1u)
#define COZIR_FLOW_CONTROL                   (0u)
#define COZIR_CLK_FREQ                       (0u)
#define COZIR_TX_BUFFER_SIZE                 (10u)
#define COZIR_RX_BUFFER_SIZE                 (30u)

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component UART_v2_50 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */

#if defined(COZIR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG)
    #define COZIR_CONTROL_REG_REMOVED            (0u)
#else
    #define COZIR_CONTROL_REG_REMOVED            (1u)
#endif /* End COZIR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */


/***************************************
*      Data Structure Definition
***************************************/

/* Sleep Mode API Support */
typedef struct COZIR_backupStruct_
{
    uint8 enableState;

    #if(COZIR_CONTROL_REG_REMOVED == 0u)
        uint8 cr;
    #endif /* End COZIR_CONTROL_REG_REMOVED */

} COZIR_BACKUP_STRUCT;


/***************************************
*       Function Prototypes
***************************************/

void COZIR_Start(void) ;
void COZIR_Stop(void) ;
uint8 COZIR_ReadControlRegister(void) ;
void COZIR_WriteControlRegister(uint8 control) ;

void COZIR_Init(void) ;
void COZIR_Enable(void) ;
void COZIR_SaveConfig(void) ;
void COZIR_RestoreConfig(void) ;
void COZIR_Sleep(void) ;
void COZIR_Wakeup(void) ;

/* Only if RX is enabled */
#if( (COZIR_RX_ENABLED) || (COZIR_HD_ENABLED) )

    #if (COZIR_RX_INTERRUPT_ENABLED)
        #define COZIR_EnableRxInt()  CyIntEnable (COZIR_RX_VECT_NUM)
        #define COZIR_DisableRxInt() CyIntDisable(COZIR_RX_VECT_NUM)
        CY_ISR_PROTO(COZIR_RXISR);
    #endif /* COZIR_RX_INTERRUPT_ENABLED */

    void COZIR_SetRxAddressMode(uint8 addressMode)
                                                           ;
    void COZIR_SetRxAddress1(uint8 address) ;
    void COZIR_SetRxAddress2(uint8 address) ;

    void  COZIR_SetRxInterruptMode(uint8 intSrc) ;
    uint8 COZIR_ReadRxData(void) ;
    uint8 COZIR_ReadRxStatus(void) ;
    uint8 COZIR_GetChar(void) ;
    uint16 COZIR_GetByte(void) ;
    uint8 COZIR_GetRxBufferSize(void)
                                                            ;
    void COZIR_ClearRxBuffer(void) ;

    /* Obsolete functions, defines for backward compatible */
    #define COZIR_GetRxInterruptSource   COZIR_ReadRxStatus

#endif /* End (COZIR_RX_ENABLED) || (COZIR_HD_ENABLED) */

/* Only if TX is enabled */
#if(COZIR_TX_ENABLED || COZIR_HD_ENABLED)

    #if(COZIR_TX_INTERRUPT_ENABLED)
        #define COZIR_EnableTxInt()  CyIntEnable (COZIR_TX_VECT_NUM)
        #define COZIR_DisableTxInt() CyIntDisable(COZIR_TX_VECT_NUM)
        #define COZIR_SetPendingTxInt() CyIntSetPending(COZIR_TX_VECT_NUM)
        #define COZIR_ClearPendingTxInt() CyIntClearPending(COZIR_TX_VECT_NUM)
        CY_ISR_PROTO(COZIR_TXISR);
    #endif /* COZIR_TX_INTERRUPT_ENABLED */

    void COZIR_SetTxInterruptMode(uint8 intSrc) ;
    void COZIR_WriteTxData(uint8 txDataByte) ;
    uint8 COZIR_ReadTxStatus(void) ;
    void COZIR_PutChar(uint8 txDataByte) ;
    void COZIR_PutString(const char8 string[]) ;
    void COZIR_PutArray(const uint8 string[], uint8 byteCount)
                                                            ;
    void COZIR_PutCRLF(uint8 txDataByte) ;
    void COZIR_ClearTxBuffer(void) ;
    void COZIR_SetTxAddressMode(uint8 addressMode) ;
    void COZIR_SendBreak(uint8 retMode) ;
    uint8 COZIR_GetTxBufferSize(void)
                                                            ;
    /* Obsolete functions, defines for backward compatible */
    #define COZIR_PutStringConst         COZIR_PutString
    #define COZIR_PutArrayConst          COZIR_PutArray
    #define COZIR_GetTxInterruptSource   COZIR_ReadTxStatus

#endif /* End COZIR_TX_ENABLED || COZIR_HD_ENABLED */

#if(COZIR_HD_ENABLED)
    void COZIR_LoadRxConfig(void) ;
    void COZIR_LoadTxConfig(void) ;
#endif /* End COZIR_HD_ENABLED */


/* Communication bootloader APIs */
#if defined(CYDEV_BOOTLOADER_IO_COMP) && ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_COZIR) || \
                                          (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))
    /* Physical layer functions */
    void    COZIR_CyBtldrCommStart(void) CYSMALL ;
    void    COZIR_CyBtldrCommStop(void) CYSMALL ;
    void    COZIR_CyBtldrCommReset(void) CYSMALL ;
    cystatus COZIR_CyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;
    cystatus COZIR_CyBtldrCommRead(uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;

    #if (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_COZIR)
        #define CyBtldrCommStart    COZIR_CyBtldrCommStart
        #define CyBtldrCommStop     COZIR_CyBtldrCommStop
        #define CyBtldrCommReset    COZIR_CyBtldrCommReset
        #define CyBtldrCommWrite    COZIR_CyBtldrCommWrite
        #define CyBtldrCommRead     COZIR_CyBtldrCommRead
    #endif  /* (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_COZIR) */

    /* Byte to Byte time out for detecting end of block data from host */
    #define COZIR_BYTE2BYTE_TIME_OUT (25u)
    #define COZIR_PACKET_EOP         (0x17u) /* End of packet defined by bootloader */
    #define COZIR_WAIT_EOP_DELAY     (5u)    /* Additional 5ms to wait for End of packet */
    #define COZIR_BL_CHK_DELAY_MS    (1u)    /* Time Out quantity equal 1mS */

#endif /* CYDEV_BOOTLOADER_IO_COMP */


/***************************************
*          API Constants
***************************************/
/* Parameters for SetTxAddressMode API*/
#define COZIR_SET_SPACE      (0x00u)
#define COZIR_SET_MARK       (0x01u)

/* Status Register definitions */
#if( (COZIR_TX_ENABLED) || (COZIR_HD_ENABLED) )
    #if(COZIR_TX_INTERRUPT_ENABLED)
        #define COZIR_TX_VECT_NUM            (uint8)COZIR_TXInternalInterrupt__INTC_NUMBER
        #define COZIR_TX_PRIOR_NUM           (uint8)COZIR_TXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* COZIR_TX_INTERRUPT_ENABLED */

    #define COZIR_TX_STS_COMPLETE_SHIFT          (0x00u)
    #define COZIR_TX_STS_FIFO_EMPTY_SHIFT        (0x01u)
    #define COZIR_TX_STS_FIFO_NOT_FULL_SHIFT     (0x03u)
    #if(COZIR_TX_ENABLED)
        #define COZIR_TX_STS_FIFO_FULL_SHIFT     (0x02u)
    #else /* (COZIR_HD_ENABLED) */
        #define COZIR_TX_STS_FIFO_FULL_SHIFT     (0x05u)  /* Needs MD=0 */
    #endif /* (COZIR_TX_ENABLED) */

    #define COZIR_TX_STS_COMPLETE            (uint8)(0x01u << COZIR_TX_STS_COMPLETE_SHIFT)
    #define COZIR_TX_STS_FIFO_EMPTY          (uint8)(0x01u << COZIR_TX_STS_FIFO_EMPTY_SHIFT)
    #define COZIR_TX_STS_FIFO_FULL           (uint8)(0x01u << COZIR_TX_STS_FIFO_FULL_SHIFT)
    #define COZIR_TX_STS_FIFO_NOT_FULL       (uint8)(0x01u << COZIR_TX_STS_FIFO_NOT_FULL_SHIFT)
#endif /* End (COZIR_TX_ENABLED) || (COZIR_HD_ENABLED)*/

#if( (COZIR_RX_ENABLED) || (COZIR_HD_ENABLED) )
    #if(COZIR_RX_INTERRUPT_ENABLED)
        #define COZIR_RX_VECT_NUM            (uint8)COZIR_RXInternalInterrupt__INTC_NUMBER
        #define COZIR_RX_PRIOR_NUM           (uint8)COZIR_RXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* COZIR_RX_INTERRUPT_ENABLED */
    #define COZIR_RX_STS_MRKSPC_SHIFT            (0x00u)
    #define COZIR_RX_STS_BREAK_SHIFT             (0x01u)
    #define COZIR_RX_STS_PAR_ERROR_SHIFT         (0x02u)
    #define COZIR_RX_STS_STOP_ERROR_SHIFT        (0x03u)
    #define COZIR_RX_STS_OVERRUN_SHIFT           (0x04u)
    #define COZIR_RX_STS_FIFO_NOTEMPTY_SHIFT     (0x05u)
    #define COZIR_RX_STS_ADDR_MATCH_SHIFT        (0x06u)
    #define COZIR_RX_STS_SOFT_BUFF_OVER_SHIFT    (0x07u)

    #define COZIR_RX_STS_MRKSPC           (uint8)(0x01u << COZIR_RX_STS_MRKSPC_SHIFT)
    #define COZIR_RX_STS_BREAK            (uint8)(0x01u << COZIR_RX_STS_BREAK_SHIFT)
    #define COZIR_RX_STS_PAR_ERROR        (uint8)(0x01u << COZIR_RX_STS_PAR_ERROR_SHIFT)
    #define COZIR_RX_STS_STOP_ERROR       (uint8)(0x01u << COZIR_RX_STS_STOP_ERROR_SHIFT)
    #define COZIR_RX_STS_OVERRUN          (uint8)(0x01u << COZIR_RX_STS_OVERRUN_SHIFT)
    #define COZIR_RX_STS_FIFO_NOTEMPTY    (uint8)(0x01u << COZIR_RX_STS_FIFO_NOTEMPTY_SHIFT)
    #define COZIR_RX_STS_ADDR_MATCH       (uint8)(0x01u << COZIR_RX_STS_ADDR_MATCH_SHIFT)
    #define COZIR_RX_STS_SOFT_BUFF_OVER   (uint8)(0x01u << COZIR_RX_STS_SOFT_BUFF_OVER_SHIFT)
    #define COZIR_RX_HW_MASK                     (0x7Fu)
#endif /* End (COZIR_RX_ENABLED) || (COZIR_HD_ENABLED) */

/* Control Register definitions */
#define COZIR_CTRL_HD_SEND_SHIFT                 (0x00u) /* 1 enable TX part in Half Duplex mode */
#define COZIR_CTRL_HD_SEND_BREAK_SHIFT           (0x01u) /* 1 send BREAK signal in Half Duplez mode */
#define COZIR_CTRL_MARK_SHIFT                    (0x02u) /* 1 sets mark, 0 sets space */
#define COZIR_CTRL_PARITY_TYPE0_SHIFT            (0x03u) /* Defines the type of parity implemented */
#define COZIR_CTRL_PARITY_TYPE1_SHIFT            (0x04u) /* Defines the type of parity implemented */
#define COZIR_CTRL_RXADDR_MODE0_SHIFT            (0x05u)
#define COZIR_CTRL_RXADDR_MODE1_SHIFT            (0x06u)
#define COZIR_CTRL_RXADDR_MODE2_SHIFT            (0x07u)

#define COZIR_CTRL_HD_SEND               (uint8)(0x01u << COZIR_CTRL_HD_SEND_SHIFT)
#define COZIR_CTRL_HD_SEND_BREAK         (uint8)(0x01u << COZIR_CTRL_HD_SEND_BREAK_SHIFT)
#define COZIR_CTRL_MARK                  (uint8)(0x01u << COZIR_CTRL_MARK_SHIFT)
#define COZIR_CTRL_PARITY_TYPE_MASK      (uint8)(0x03u << COZIR_CTRL_PARITY_TYPE0_SHIFT)
#define COZIR_CTRL_RXADDR_MODE_MASK      (uint8)(0x07u << COZIR_CTRL_RXADDR_MODE0_SHIFT)

/* StatusI Register Interrupt Enable Control Bits. As defined by the Register map for the AUX Control Register */
#define COZIR_INT_ENABLE                         (0x10u)

/* Bit Counter (7-bit) Control Register Bit Definitions. As defined by the Register map for the AUX Control Register */
#define COZIR_CNTR_ENABLE                        (0x20u)

/*   Constants for SendBreak() "retMode" parameter  */
#define COZIR_SEND_BREAK                         (0x00u)
#define COZIR_WAIT_FOR_COMPLETE_REINIT           (0x01u)
#define COZIR_REINIT                             (0x02u)
#define COZIR_SEND_WAIT_REINIT                   (0x03u)

#define COZIR_OVER_SAMPLE_8                      (8u)
#define COZIR_OVER_SAMPLE_16                     (16u)

#define COZIR_BIT_CENTER                         (COZIR_OVER_SAMPLE_COUNT - 2u)

#define COZIR_FIFO_LENGTH                        (4u)
#define COZIR_NUMBER_OF_START_BIT                (1u)
#define COZIR_MAX_BYTE_VALUE                     (0xFFu)

/* 8X always for count7 implementation */
#define COZIR_TXBITCTR_BREAKBITS8X   ((COZIR_BREAK_BITS_TX * COZIR_OVER_SAMPLE_8) - 1u)
/* 8X or 16X for DP implementation */
#define COZIR_TXBITCTR_BREAKBITS ((COZIR_BREAK_BITS_TX * COZIR_OVER_SAMPLE_COUNT) - 1u)

#define COZIR_HALF_BIT_COUNT   \
                            (((COZIR_OVER_SAMPLE_COUNT / 2u) + (COZIR_USE23POLLING * 1u)) - 2u)
#if (COZIR_OVER_SAMPLE_COUNT == COZIR_OVER_SAMPLE_8)
    #define COZIR_HD_TXBITCTR_INIT   (((COZIR_BREAK_BITS_TX + \
                            COZIR_NUMBER_OF_START_BIT) * COZIR_OVER_SAMPLE_COUNT) - 1u)

    /* This parameter is increased on the 2 in 2 out of 3 mode to sample voting in the middle */
    #define COZIR_RXBITCTR_INIT  ((((COZIR_BREAK_BITS_RX + COZIR_NUMBER_OF_START_BIT) \
                            * COZIR_OVER_SAMPLE_COUNT) + COZIR_HALF_BIT_COUNT) - 1u)

#else /* COZIR_OVER_SAMPLE_COUNT == COZIR_OVER_SAMPLE_16 */
    #define COZIR_HD_TXBITCTR_INIT   ((8u * COZIR_OVER_SAMPLE_COUNT) - 1u)
    /* 7bit counter need one more bit for OverSampleCount = 16 */
    #define COZIR_RXBITCTR_INIT      (((7u * COZIR_OVER_SAMPLE_COUNT) - 1u) + \
                                                      COZIR_HALF_BIT_COUNT)
#endif /* End COZIR_OVER_SAMPLE_COUNT */

#define COZIR_HD_RXBITCTR_INIT                   COZIR_RXBITCTR_INIT


/***************************************
* Global variables external identifier
***************************************/

extern uint8 COZIR_initVar;
#if (COZIR_TX_INTERRUPT_ENABLED && COZIR_TX_ENABLED)
    extern volatile uint8 COZIR_txBuffer[COZIR_TX_BUFFER_SIZE];
    extern volatile uint8 COZIR_txBufferRead;
    extern uint8 COZIR_txBufferWrite;
#endif /* (COZIR_TX_INTERRUPT_ENABLED && COZIR_TX_ENABLED) */
#if (COZIR_RX_INTERRUPT_ENABLED && (COZIR_RX_ENABLED || COZIR_HD_ENABLED))
    extern uint8 COZIR_errorStatus;
    extern volatile uint8 COZIR_rxBuffer[COZIR_RX_BUFFER_SIZE];
    extern volatile uint8 COZIR_rxBufferRead;
    extern volatile uint8 COZIR_rxBufferWrite;
    extern volatile uint8 COZIR_rxBufferLoopDetect;
    extern volatile uint8 COZIR_rxBufferOverflow;
    #if (COZIR_RXHW_ADDRESS_ENABLED)
        extern volatile uint8 COZIR_rxAddressMode;
        extern volatile uint8 COZIR_rxAddressDetected;
    #endif /* (COZIR_RXHW_ADDRESS_ENABLED) */
#endif /* (COZIR_RX_INTERRUPT_ENABLED && (COZIR_RX_ENABLED || COZIR_HD_ENABLED)) */


/***************************************
* Enumerated Types and Parameters
***************************************/

#define COZIR__B_UART__AM_SW_BYTE_BYTE 1
#define COZIR__B_UART__AM_SW_DETECT_TO_BUFFER 2
#define COZIR__B_UART__AM_HW_BYTE_BY_BYTE 3
#define COZIR__B_UART__AM_HW_DETECT_TO_BUFFER 4
#define COZIR__B_UART__AM_NONE 0

#define COZIR__B_UART__NONE_REVB 0
#define COZIR__B_UART__EVEN_REVB 1
#define COZIR__B_UART__ODD_REVB 2
#define COZIR__B_UART__MARK_SPACE_REVB 3



/***************************************
*    Initial Parameter Constants
***************************************/

/* UART shifts max 8 bits, Mark/Space functionality working if 9 selected */
#define COZIR_NUMBER_OF_DATA_BITS    ((8u > 8u) ? 8u : 8u)
#define COZIR_NUMBER_OF_STOP_BITS    (1u)

#if (COZIR_RXHW_ADDRESS_ENABLED)
    #define COZIR_RX_ADDRESS_MODE    (0u)
    #define COZIR_RX_HW_ADDRESS1     (0u)
    #define COZIR_RX_HW_ADDRESS2     (0u)
#endif /* (COZIR_RXHW_ADDRESS_ENABLED) */

#define COZIR_INIT_RX_INTERRUPTS_MASK \
                                  (uint8)((1 << COZIR_RX_STS_FIFO_NOTEMPTY_SHIFT) \
                                        | (0 << COZIR_RX_STS_MRKSPC_SHIFT) \
                                        | (0 << COZIR_RX_STS_ADDR_MATCH_SHIFT) \
                                        | (0 << COZIR_RX_STS_PAR_ERROR_SHIFT) \
                                        | (0 << COZIR_RX_STS_STOP_ERROR_SHIFT) \
                                        | (0 << COZIR_RX_STS_BREAK_SHIFT) \
                                        | (0 << COZIR_RX_STS_OVERRUN_SHIFT))

#define COZIR_INIT_TX_INTERRUPTS_MASK \
                                  (uint8)((0 << COZIR_TX_STS_COMPLETE_SHIFT) \
                                        | (1 << COZIR_TX_STS_FIFO_EMPTY_SHIFT) \
                                        | (0 << COZIR_TX_STS_FIFO_FULL_SHIFT) \
                                        | (0 << COZIR_TX_STS_FIFO_NOT_FULL_SHIFT))


/***************************************
*              Registers
***************************************/

#ifdef COZIR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define COZIR_CONTROL_REG \
                            (* (reg8 *) COZIR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
    #define COZIR_CONTROL_PTR \
                            (  (reg8 *) COZIR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
#endif /* End COZIR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(COZIR_TX_ENABLED)
    #define COZIR_TXDATA_REG          (* (reg8 *) COZIR_BUART_sTX_TxShifter_u0__F0_REG)
    #define COZIR_TXDATA_PTR          (  (reg8 *) COZIR_BUART_sTX_TxShifter_u0__F0_REG)
    #define COZIR_TXDATA_AUX_CTL_REG  (* (reg8 *) COZIR_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define COZIR_TXDATA_AUX_CTL_PTR  (  (reg8 *) COZIR_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define COZIR_TXSTATUS_REG        (* (reg8 *) COZIR_BUART_sTX_TxSts__STATUS_REG)
    #define COZIR_TXSTATUS_PTR        (  (reg8 *) COZIR_BUART_sTX_TxSts__STATUS_REG)
    #define COZIR_TXSTATUS_MASK_REG   (* (reg8 *) COZIR_BUART_sTX_TxSts__MASK_REG)
    #define COZIR_TXSTATUS_MASK_PTR   (  (reg8 *) COZIR_BUART_sTX_TxSts__MASK_REG)
    #define COZIR_TXSTATUS_ACTL_REG   (* (reg8 *) COZIR_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)
    #define COZIR_TXSTATUS_ACTL_PTR   (  (reg8 *) COZIR_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)

    /* DP clock */
    #if(COZIR_TXCLKGEN_DP)
        #define COZIR_TXBITCLKGEN_CTR_REG        \
                                        (* (reg8 *) COZIR_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define COZIR_TXBITCLKGEN_CTR_PTR        \
                                        (  (reg8 *) COZIR_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define COZIR_TXBITCLKTX_COMPLETE_REG    \
                                        (* (reg8 *) COZIR_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
        #define COZIR_TXBITCLKTX_COMPLETE_PTR    \
                                        (  (reg8 *) COZIR_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
    #else     /* Count7 clock*/
        #define COZIR_TXBITCTR_PERIOD_REG    \
                                        (* (reg8 *) COZIR_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define COZIR_TXBITCTR_PERIOD_PTR    \
                                        (  (reg8 *) COZIR_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define COZIR_TXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) COZIR_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define COZIR_TXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) COZIR_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define COZIR_TXBITCTR_COUNTER_REG   \
                                        (* (reg8 *) COZIR_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
        #define COZIR_TXBITCTR_COUNTER_PTR   \
                                        (  (reg8 *) COZIR_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
    #endif /* COZIR_TXCLKGEN_DP */

#endif /* End COZIR_TX_ENABLED */

#if(COZIR_HD_ENABLED)

    #define COZIR_TXDATA_REG             (* (reg8 *) COZIR_BUART_sRX_RxShifter_u0__F1_REG )
    #define COZIR_TXDATA_PTR             (  (reg8 *) COZIR_BUART_sRX_RxShifter_u0__F1_REG )
    #define COZIR_TXDATA_AUX_CTL_REG     (* (reg8 *) COZIR_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)
    #define COZIR_TXDATA_AUX_CTL_PTR     (  (reg8 *) COZIR_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define COZIR_TXSTATUS_REG           (* (reg8 *) COZIR_BUART_sRX_RxSts__STATUS_REG )
    #define COZIR_TXSTATUS_PTR           (  (reg8 *) COZIR_BUART_sRX_RxSts__STATUS_REG )
    #define COZIR_TXSTATUS_MASK_REG      (* (reg8 *) COZIR_BUART_sRX_RxSts__MASK_REG )
    #define COZIR_TXSTATUS_MASK_PTR      (  (reg8 *) COZIR_BUART_sRX_RxSts__MASK_REG )
    #define COZIR_TXSTATUS_ACTL_REG      (* (reg8 *) COZIR_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define COZIR_TXSTATUS_ACTL_PTR      (  (reg8 *) COZIR_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End COZIR_HD_ENABLED */

#if( (COZIR_RX_ENABLED) || (COZIR_HD_ENABLED) )
    #define COZIR_RXDATA_REG             (* (reg8 *) COZIR_BUART_sRX_RxShifter_u0__F0_REG )
    #define COZIR_RXDATA_PTR             (  (reg8 *) COZIR_BUART_sRX_RxShifter_u0__F0_REG )
    #define COZIR_RXADDRESS1_REG         (* (reg8 *) COZIR_BUART_sRX_RxShifter_u0__D0_REG )
    #define COZIR_RXADDRESS1_PTR         (  (reg8 *) COZIR_BUART_sRX_RxShifter_u0__D0_REG )
    #define COZIR_RXADDRESS2_REG         (* (reg8 *) COZIR_BUART_sRX_RxShifter_u0__D1_REG )
    #define COZIR_RXADDRESS2_PTR         (  (reg8 *) COZIR_BUART_sRX_RxShifter_u0__D1_REG )
    #define COZIR_RXDATA_AUX_CTL_REG     (* (reg8 *) COZIR_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define COZIR_RXBITCTR_PERIOD_REG    (* (reg8 *) COZIR_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define COZIR_RXBITCTR_PERIOD_PTR    (  (reg8 *) COZIR_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define COZIR_RXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) COZIR_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define COZIR_RXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) COZIR_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define COZIR_RXBITCTR_COUNTER_REG   (* (reg8 *) COZIR_BUART_sRX_RxBitCounter__COUNT_REG )
    #define COZIR_RXBITCTR_COUNTER_PTR   (  (reg8 *) COZIR_BUART_sRX_RxBitCounter__COUNT_REG )

    #define COZIR_RXSTATUS_REG           (* (reg8 *) COZIR_BUART_sRX_RxSts__STATUS_REG )
    #define COZIR_RXSTATUS_PTR           (  (reg8 *) COZIR_BUART_sRX_RxSts__STATUS_REG )
    #define COZIR_RXSTATUS_MASK_REG      (* (reg8 *) COZIR_BUART_sRX_RxSts__MASK_REG )
    #define COZIR_RXSTATUS_MASK_PTR      (  (reg8 *) COZIR_BUART_sRX_RxSts__MASK_REG )
    #define COZIR_RXSTATUS_ACTL_REG      (* (reg8 *) COZIR_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define COZIR_RXSTATUS_ACTL_PTR      (  (reg8 *) COZIR_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End  (COZIR_RX_ENABLED) || (COZIR_HD_ENABLED) */

#if(COZIR_INTERNAL_CLOCK_USED)
    /* Register to enable or disable the digital clocks */
    #define COZIR_INTCLOCK_CLKEN_REG     (* (reg8 *) COZIR_IntClock__PM_ACT_CFG)
    #define COZIR_INTCLOCK_CLKEN_PTR     (  (reg8 *) COZIR_IntClock__PM_ACT_CFG)

    /* Clock mask for this clock. */
    #define COZIR_INTCLOCK_CLKEN_MASK    COZIR_IntClock__PM_ACT_MSK
#endif /* End COZIR_INTERNAL_CLOCK_USED */


/***************************************
*       Register Constants
***************************************/

#if(COZIR_TX_ENABLED)
    #define COZIR_TX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End COZIR_TX_ENABLED */

#if(COZIR_HD_ENABLED)
    #define COZIR_TX_FIFO_CLR            (0x02u) /* FIFO1 CLR */
#endif /* End COZIR_HD_ENABLED */

#if( (COZIR_RX_ENABLED) || (COZIR_HD_ENABLED) )
    #define COZIR_RX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End  (COZIR_RX_ENABLED) || (COZIR_HD_ENABLED) */


/***************************************
* The following code is DEPRECATED and
* should not be used in new projects.
***************************************/

/* UART v2_40 obsolete definitions */
#define COZIR_WAIT_1_MS      COZIR_BL_CHK_DELAY_MS   

#define COZIR_TXBUFFERSIZE   COZIR_TX_BUFFER_SIZE
#define COZIR_RXBUFFERSIZE   COZIR_RX_BUFFER_SIZE

#if (COZIR_RXHW_ADDRESS_ENABLED)
    #define COZIR_RXADDRESSMODE  COZIR_RX_ADDRESS_MODE
    #define COZIR_RXHWADDRESS1   COZIR_RX_HW_ADDRESS1
    #define COZIR_RXHWADDRESS2   COZIR_RX_HW_ADDRESS2
    /* Backward compatible define */
    #define COZIR_RXAddressMode  COZIR_RXADDRESSMODE
#endif /* (COZIR_RXHW_ADDRESS_ENABLED) */

/* UART v2_30 obsolete definitions */
#define COZIR_initvar                    COZIR_initVar

#define COZIR_RX_Enabled                 COZIR_RX_ENABLED
#define COZIR_TX_Enabled                 COZIR_TX_ENABLED
#define COZIR_HD_Enabled                 COZIR_HD_ENABLED
#define COZIR_RX_IntInterruptEnabled     COZIR_RX_INTERRUPT_ENABLED
#define COZIR_TX_IntInterruptEnabled     COZIR_TX_INTERRUPT_ENABLED
#define COZIR_InternalClockUsed          COZIR_INTERNAL_CLOCK_USED
#define COZIR_RXHW_Address_Enabled       COZIR_RXHW_ADDRESS_ENABLED
#define COZIR_OverSampleCount            COZIR_OVER_SAMPLE_COUNT
#define COZIR_ParityType                 COZIR_PARITY_TYPE

#if( COZIR_TX_ENABLED && (COZIR_TXBUFFERSIZE > COZIR_FIFO_LENGTH))
    #define COZIR_TXBUFFER               COZIR_txBuffer
    #define COZIR_TXBUFFERREAD           COZIR_txBufferRead
    #define COZIR_TXBUFFERWRITE          COZIR_txBufferWrite
#endif /* End COZIR_TX_ENABLED */
#if( ( COZIR_RX_ENABLED || COZIR_HD_ENABLED ) && \
     (COZIR_RXBUFFERSIZE > COZIR_FIFO_LENGTH) )
    #define COZIR_RXBUFFER               COZIR_rxBuffer
    #define COZIR_RXBUFFERREAD           COZIR_rxBufferRead
    #define COZIR_RXBUFFERWRITE          COZIR_rxBufferWrite
    #define COZIR_RXBUFFERLOOPDETECT     COZIR_rxBufferLoopDetect
    #define COZIR_RXBUFFER_OVERFLOW      COZIR_rxBufferOverflow
#endif /* End COZIR_RX_ENABLED */

#ifdef COZIR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define COZIR_CONTROL                COZIR_CONTROL_REG
#endif /* End COZIR_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(COZIR_TX_ENABLED)
    #define COZIR_TXDATA                 COZIR_TXDATA_REG
    #define COZIR_TXSTATUS               COZIR_TXSTATUS_REG
    #define COZIR_TXSTATUS_MASK          COZIR_TXSTATUS_MASK_REG
    #define COZIR_TXSTATUS_ACTL          COZIR_TXSTATUS_ACTL_REG
    /* DP clock */
    #if(COZIR_TXCLKGEN_DP)
        #define COZIR_TXBITCLKGEN_CTR        COZIR_TXBITCLKGEN_CTR_REG
        #define COZIR_TXBITCLKTX_COMPLETE    COZIR_TXBITCLKTX_COMPLETE_REG
    #else     /* Count7 clock*/
        #define COZIR_TXBITCTR_PERIOD        COZIR_TXBITCTR_PERIOD_REG
        #define COZIR_TXBITCTR_CONTROL       COZIR_TXBITCTR_CONTROL_REG
        #define COZIR_TXBITCTR_COUNTER       COZIR_TXBITCTR_COUNTER_REG
    #endif /* COZIR_TXCLKGEN_DP */
#endif /* End COZIR_TX_ENABLED */

#if(COZIR_HD_ENABLED)
    #define COZIR_TXDATA                 COZIR_TXDATA_REG
    #define COZIR_TXSTATUS               COZIR_TXSTATUS_REG
    #define COZIR_TXSTATUS_MASK          COZIR_TXSTATUS_MASK_REG
    #define COZIR_TXSTATUS_ACTL          COZIR_TXSTATUS_ACTL_REG
#endif /* End COZIR_HD_ENABLED */

#if( (COZIR_RX_ENABLED) || (COZIR_HD_ENABLED) )
    #define COZIR_RXDATA                 COZIR_RXDATA_REG
    #define COZIR_RXADDRESS1             COZIR_RXADDRESS1_REG
    #define COZIR_RXADDRESS2             COZIR_RXADDRESS2_REG
    #define COZIR_RXBITCTR_PERIOD        COZIR_RXBITCTR_PERIOD_REG
    #define COZIR_RXBITCTR_CONTROL       COZIR_RXBITCTR_CONTROL_REG
    #define COZIR_RXBITCTR_COUNTER       COZIR_RXBITCTR_COUNTER_REG
    #define COZIR_RXSTATUS               COZIR_RXSTATUS_REG
    #define COZIR_RXSTATUS_MASK          COZIR_RXSTATUS_MASK_REG
    #define COZIR_RXSTATUS_ACTL          COZIR_RXSTATUS_ACTL_REG
#endif /* End  (COZIR_RX_ENABLED) || (COZIR_HD_ENABLED) */

#if(COZIR_INTERNAL_CLOCK_USED)
    #define COZIR_INTCLOCK_CLKEN         COZIR_INTCLOCK_CLKEN_REG
#endif /* End COZIR_INTERNAL_CLOCK_USED */

#define COZIR_WAIT_FOR_COMLETE_REINIT    COZIR_WAIT_FOR_COMPLETE_REINIT

#endif  /* CY_UART_COZIR_H */


/* [] END OF FILE */
