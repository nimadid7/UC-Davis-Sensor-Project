/*******************************************************************************
* File Name: DustINT.c
* Version 2.50
*
* Description:
*  This file provides all Interrupt Service functionality of the UART component
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Dust.h"



/***************************************
* Custom Declarations
***************************************/
/* `#START CUSTOM_DECLARATIONS` Place your declaration here */

/* `#END` */

#if (Dust_RX_INTERRUPT_ENABLED && (Dust_RX_ENABLED || Dust_HD_ENABLED))
    /*******************************************************************************
    * Function Name: Dust_RXISR
    ********************************************************************************
    *
    * Summary:
    *  Interrupt Service Routine for RX portion of the UART
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  Dust_rxBuffer - RAM buffer pointer for save received data.
    *  Dust_rxBufferWrite - cyclic index for write to rxBuffer,
    *     increments after each byte saved to buffer.
    *  Dust_rxBufferRead - cyclic index for read from rxBuffer,
    *     checked to detect overflow condition.
    *  Dust_rxBufferOverflow - software overflow flag. Set to one
    *     when Dust_rxBufferWrite index overtakes
    *     Dust_rxBufferRead index.
    *  Dust_rxBufferLoopDetect - additional variable to detect overflow.
    *     Set to one when Dust_rxBufferWrite is equal to
    *    Dust_rxBufferRead
    *  Dust_rxAddressMode - this variable contains the Address mode,
    *     selected in customizer or set by UART_SetRxAddressMode() API.
    *  Dust_rxAddressDetected - set to 1 when correct address received,
    *     and analysed to store following addressed data bytes to the buffer.
    *     When not correct address received, set to 0 to skip following data bytes.
    *
    *******************************************************************************/
    CY_ISR(Dust_RXISR)
    {
        uint8 readData;
        uint8 readStatus;
        uint8 increment_pointer = 0u;

    #if(CY_PSOC3)
        uint8 int_en;
    #endif /* (CY_PSOC3) */

    #ifdef Dust_RXISR_ENTRY_CALLBACK
        Dust_RXISR_EntryCallback();
    #endif /* Dust_RXISR_ENTRY_CALLBACK */

        /* User code required at start of ISR */
        /* `#START Dust_RXISR_START` */

        /* `#END` */

    #if(CY_PSOC3)   /* Make sure nested interrupt is enabled */
        int_en = EA;
        CyGlobalIntEnable;
    #endif /* (CY_PSOC3) */

        do
        {
            /* Read receiver status register */
            readStatus = Dust_RXSTATUS_REG;
            /* Copy the same status to readData variable for backward compatibility support 
            *  of the user code in Dust_RXISR_ERROR` section. 
            */
            readData = readStatus;

            if((readStatus & (Dust_RX_STS_BREAK | 
                            Dust_RX_STS_PAR_ERROR |
                            Dust_RX_STS_STOP_ERROR | 
                            Dust_RX_STS_OVERRUN)) != 0u)
            {
                /* ERROR handling. */
                Dust_errorStatus |= readStatus & ( Dust_RX_STS_BREAK | 
                                                            Dust_RX_STS_PAR_ERROR | 
                                                            Dust_RX_STS_STOP_ERROR | 
                                                            Dust_RX_STS_OVERRUN);
                /* `#START Dust_RXISR_ERROR` */

                /* `#END` */
                
            #ifdef Dust_RXISR_ERROR_CALLBACK
                Dust_RXISR_ERROR_Callback();
            #endif /* Dust_RXISR_ERROR_CALLBACK */
            }
            
            if((readStatus & Dust_RX_STS_FIFO_NOTEMPTY) != 0u)
            {
                /* Read data from the RX data register */
                readData = Dust_RXDATA_REG;
            #if (Dust_RXHW_ADDRESS_ENABLED)
                if(Dust_rxAddressMode == (uint8)Dust__B_UART__AM_SW_DETECT_TO_BUFFER)
                {
                    if((readStatus & Dust_RX_STS_MRKSPC) != 0u)
                    {
                        if ((readStatus & Dust_RX_STS_ADDR_MATCH) != 0u)
                        {
                            Dust_rxAddressDetected = 1u;
                        }
                        else
                        {
                            Dust_rxAddressDetected = 0u;
                        }
                    }
                    if(Dust_rxAddressDetected != 0u)
                    {   /* Store only addressed data */
                        Dust_rxBuffer[Dust_rxBufferWrite] = readData;
                        increment_pointer = 1u;
                    }
                }
                else /* Without software addressing */
                {
                    Dust_rxBuffer[Dust_rxBufferWrite] = readData;
                    increment_pointer = 1u;
                }
            #else  /* Without addressing */
                Dust_rxBuffer[Dust_rxBufferWrite] = readData;
                increment_pointer = 1u;
            #endif /* (Dust_RXHW_ADDRESS_ENABLED) */

                /* Do not increment buffer pointer when skip not addressed data */
                if(increment_pointer != 0u)
                {
                    if(Dust_rxBufferLoopDetect != 0u)
                    {   /* Set Software Buffer status Overflow */
                        Dust_rxBufferOverflow = 1u;
                    }
                    /* Set next pointer. */
                    Dust_rxBufferWrite++;

                    /* Check pointer for a loop condition */
                    if(Dust_rxBufferWrite >= Dust_RX_BUFFER_SIZE)
                    {
                        Dust_rxBufferWrite = 0u;
                    }

                    /* Detect pre-overload condition and set flag */
                    if(Dust_rxBufferWrite == Dust_rxBufferRead)
                    {
                        Dust_rxBufferLoopDetect = 1u;
                        /* When Hardware Flow Control selected */
                        #if (Dust_FLOW_CONTROL != 0u)
                            /* Disable RX interrupt mask, it is enabled when user read data from the buffer using APIs */
                            Dust_RXSTATUS_MASK_REG  &= (uint8)~Dust_RX_STS_FIFO_NOTEMPTY;
                            CyIntClearPending(Dust_RX_VECT_NUM);
                            break; /* Break the reading of the FIFO loop, leave the data there for generating RTS signal */
                        #endif /* (Dust_FLOW_CONTROL != 0u) */
                    }
                }
            }
        }while((readStatus & Dust_RX_STS_FIFO_NOTEMPTY) != 0u);

        /* User code required at end of ISR (Optional) */
        /* `#START Dust_RXISR_END` */

        /* `#END` */

    #ifdef Dust_RXISR_EXIT_CALLBACK
        Dust_RXISR_ExitCallback();
    #endif /* Dust_RXISR_EXIT_CALLBACK */

    #if(CY_PSOC3)
        EA = int_en;
    #endif /* (CY_PSOC3) */
    }
    
#endif /* (Dust_RX_INTERRUPT_ENABLED && (Dust_RX_ENABLED || Dust_HD_ENABLED)) */


#if (Dust_TX_INTERRUPT_ENABLED && Dust_TX_ENABLED)
    /*******************************************************************************
    * Function Name: Dust_TXISR
    ********************************************************************************
    *
    * Summary:
    * Interrupt Service Routine for the TX portion of the UART
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  Dust_txBuffer - RAM buffer pointer for transmit data from.
    *  Dust_txBufferRead - cyclic index for read and transmit data
    *     from txBuffer, increments after each transmitted byte.
    *  Dust_rxBufferWrite - cyclic index for write to txBuffer,
    *     checked to detect available for transmission bytes.
    *
    *******************************************************************************/
    CY_ISR(Dust_TXISR)
    {
    #if(CY_PSOC3)
        uint8 int_en;
    #endif /* (CY_PSOC3) */

    #ifdef Dust_TXISR_ENTRY_CALLBACK
        Dust_TXISR_EntryCallback();
    #endif /* Dust_TXISR_ENTRY_CALLBACK */

        /* User code required at start of ISR */
        /* `#START Dust_TXISR_START` */

        /* `#END` */

    #if(CY_PSOC3)   /* Make sure nested interrupt is enabled */
        int_en = EA;
        CyGlobalIntEnable;
    #endif /* (CY_PSOC3) */

        while((Dust_txBufferRead != Dust_txBufferWrite) &&
             ((Dust_TXSTATUS_REG & Dust_TX_STS_FIFO_FULL) == 0u))
        {
            /* Check pointer wrap around */
            if(Dust_txBufferRead >= Dust_TX_BUFFER_SIZE)
            {
                Dust_txBufferRead = 0u;
            }

            Dust_TXDATA_REG = Dust_txBuffer[Dust_txBufferRead];

            /* Set next pointer */
            Dust_txBufferRead++;
        }

        /* User code required at end of ISR (Optional) */
        /* `#START Dust_TXISR_END` */

        /* `#END` */

    #ifdef Dust_TXISR_EXIT_CALLBACK
        Dust_TXISR_ExitCallback();
    #endif /* Dust_TXISR_EXIT_CALLBACK */

    #if(CY_PSOC3)
        EA = int_en;
    #endif /* (CY_PSOC3) */
   }
#endif /* (Dust_TX_INTERRUPT_ENABLED && Dust_TX_ENABLED) */


/* [] END OF FILE */
