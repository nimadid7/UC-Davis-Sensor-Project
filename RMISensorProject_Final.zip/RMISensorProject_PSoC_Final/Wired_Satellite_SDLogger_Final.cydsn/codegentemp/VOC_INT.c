/*******************************************************************************
* File Name: VOC_INT.c
* Version 3.50
*
* Description:
*  This file provides the source code of Interrupt Service Routine (ISR)
*  for the I2C component.
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "VOC_PVT.h"



/*******************************************************************************
*  Place your includes, defines and code here.
********************************************************************************/
/* `#START VOC_ISR_intc` */

/* `#END` */


/*******************************************************************************
* Function Name: VOC_ISR
********************************************************************************
*
* Summary:
*  The handler for the I2C interrupt. The slave and master operations are
*  handled here.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
CY_ISR(VOC_ISR)
{
#if (VOC_MODE_SLAVE_ENABLED)
   uint8  tmp8;
#endif  /* (VOC_MODE_SLAVE_ENABLED) */

    uint8  tmpCsr;
    
#ifdef VOC_ISR_ENTRY_CALLBACK
    VOC_ISR_EntryCallback();
#endif /* VOC_ISR_ENTRY_CALLBACK */
    

#if(VOC_TIMEOUT_FF_ENABLED)
    if(0u != VOC_TimeoutGetStatus())
    {
        VOC_TimeoutReset();
        VOC_state = VOC_SM_EXIT_IDLE;
        /* VOC_CSR_REG should be cleared after reset */
    }
#endif /* (VOC_TIMEOUT_FF_ENABLED) */


    tmpCsr = VOC_CSR_REG;      /* Make copy as interrupts clear */

#if(VOC_MODE_MULTI_MASTER_SLAVE_ENABLED)
    if(VOC_CHECK_START_GEN(VOC_MCSR_REG))
    {
        VOC_CLEAR_START_GEN;

        /* Set transfer complete and error flags */
        VOC_mstrStatus |= (VOC_MSTAT_ERR_XFER |
                                        VOC_GET_MSTAT_CMPLT);

        /* Slave was addressed */
        VOC_state = VOC_SM_SLAVE;
    }
#endif /* (VOC_MODE_MULTI_MASTER_SLAVE_ENABLED) */


#if(VOC_MODE_MULTI_MASTER_ENABLED)
    if(VOC_CHECK_LOST_ARB(tmpCsr))
    {
        /* Set errors */
        VOC_mstrStatus |= (VOC_MSTAT_ERR_XFER     |
                                        VOC_MSTAT_ERR_ARB_LOST |
                                        VOC_GET_MSTAT_CMPLT);

        VOC_DISABLE_INT_ON_STOP; /* Interrupt on Stop is enabled by write */

        #if(VOC_MODE_MULTI_MASTER_SLAVE_ENABLED)
            if(VOC_CHECK_ADDRESS_STS(tmpCsr))
            {
                /* Slave was addressed */
                VOC_state = VOC_SM_SLAVE;
            }
            else
            {
                VOC_BUS_RELEASE;

                VOC_state = VOC_SM_EXIT_IDLE;
            }
        #else
            VOC_BUS_RELEASE;

            VOC_state = VOC_SM_EXIT_IDLE;

        #endif /* (VOC_MODE_MULTI_MASTER_SLAVE_ENABLED) */
    }
#endif /* (VOC_MODE_MULTI_MASTER_ENABLED) */

    /* Check for master operation mode */
    if(VOC_CHECK_SM_MASTER)
    {
    #if(VOC_MODE_MASTER_ENABLED)
        if(VOC_CHECK_BYTE_COMPLETE(tmpCsr))
        {
            switch (VOC_state)
            {
            case VOC_SM_MSTR_WR_ADDR:  /* After address is sent, write data */
            case VOC_SM_MSTR_RD_ADDR:  /* After address is sent, read data */

                tmpCsr &= ((uint8) ~VOC_CSR_STOP_STATUS); /* Clear Stop bit history on address phase */

                if(VOC_CHECK_ADDR_ACK(tmpCsr))
                {
                    /* Setup for transmit or receive of data */
                    if(VOC_state == VOC_SM_MSTR_WR_ADDR)   /* TRANSMIT data */
                    {
                        /* Check if at least one byte to transfer */
                        if(VOC_mstrWrBufSize > 0u)
                        {
                            /* Load the 1st data byte */
                            VOC_DATA_REG = VOC_mstrWrBufPtr[0u];
                            VOC_TRANSMIT_DATA;
                            VOC_mstrWrBufIndex = 1u;   /* Set index to 2nd element */

                            /* Set transmit state until done */
                            VOC_state = VOC_SM_MSTR_WR_DATA;
                        }
                        /* End of buffer: complete writing */
                        else if(VOC_CHECK_NO_STOP(VOC_mstrControl))
                        {
                            /* Set write complete and master halted */
                            VOC_mstrStatus |= (VOC_MSTAT_XFER_HALT |
                                                            VOC_MSTAT_WR_CMPLT);

                            VOC_state = VOC_SM_MSTR_HALT; /* Expect ReStart */
                            VOC_DisableInt();
                        }
                        else
                        {
                            VOC_ENABLE_INT_ON_STOP; /* Enable interrupt on Stop, to catch it */
                            VOC_GENERATE_STOP;
                        }
                    }
                    else  /* Master receive data */
                    {
                        VOC_READY_TO_READ; /* Release bus to read data */

                        VOC_state  = VOC_SM_MSTR_RD_DATA;
                    }
                }
                /* Address is NACKed */
                else if(VOC_CHECK_ADDR_NAK(tmpCsr))
                {
                    /* Set Address NAK error */
                    VOC_mstrStatus |= (VOC_MSTAT_ERR_XFER |
                                                    VOC_MSTAT_ERR_ADDR_NAK);

                    if(VOC_CHECK_NO_STOP(VOC_mstrControl))
                    {
                        VOC_mstrStatus |= (VOC_MSTAT_XFER_HALT |
                                                        VOC_GET_MSTAT_CMPLT);

                        VOC_state = VOC_SM_MSTR_HALT; /* Expect RESTART */
                        VOC_DisableInt();
                    }
                    else  /* Do normal Stop */
                    {
                        VOC_ENABLE_INT_ON_STOP; /* Enable interrupt on Stop, to catch it */
                        VOC_GENERATE_STOP;
                    }
                }
                else
                {
                    /* Address phase is not set for some reason: error */
                    #if(VOC_TIMEOUT_ENABLED)
                        /* Exit interrupt to take chance for timeout timer to handle this case */
                        VOC_DisableInt();
                        VOC_ClearPendingInt();
                    #else
                        /* Block execution flow: unexpected condition */
                        CYASSERT(0u != 0u);
                    #endif /* (VOC_TIMEOUT_ENABLED) */
                }
                break;

            case VOC_SM_MSTR_WR_DATA:

                if(VOC_CHECK_DATA_ACK(tmpCsr))
                {
                    /* Check if end of buffer */
                    if(VOC_mstrWrBufIndex  < VOC_mstrWrBufSize)
                    {
                        VOC_DATA_REG =
                                                 VOC_mstrWrBufPtr[VOC_mstrWrBufIndex];
                        VOC_TRANSMIT_DATA;
                        VOC_mstrWrBufIndex++;
                    }
                    /* End of buffer: complete writing */
                    else if(VOC_CHECK_NO_STOP(VOC_mstrControl))
                    {
                        /* Set write complete and master halted */
                        VOC_mstrStatus |= (VOC_MSTAT_XFER_HALT |
                                                        VOC_MSTAT_WR_CMPLT);

                        VOC_state = VOC_SM_MSTR_HALT;    /* Expect restart */
                        VOC_DisableInt();
                    }
                    else  /* Do normal Stop */
                    {
                        VOC_ENABLE_INT_ON_STOP;    /* Enable interrupt on Stop, to catch it */
                        VOC_GENERATE_STOP;
                    }
                }
                /* Last byte NAKed: end writing */
                else if(VOC_CHECK_NO_STOP(VOC_mstrControl))
                {
                    /* Set write complete, short transfer and master halted */
                    VOC_mstrStatus |= (VOC_MSTAT_ERR_XFER       |
                                                    VOC_MSTAT_ERR_SHORT_XFER |
                                                    VOC_MSTAT_XFER_HALT      |
                                                    VOC_MSTAT_WR_CMPLT);

                    VOC_state = VOC_SM_MSTR_HALT;    /* Expect ReStart */
                    VOC_DisableInt();
                }
                else  /* Do normal Stop */
                {
                    VOC_ENABLE_INT_ON_STOP;    /* Enable interrupt on Stop, to catch it */
                    VOC_GENERATE_STOP;

                    /* Set short transfer and error flag */
                    VOC_mstrStatus |= (VOC_MSTAT_ERR_SHORT_XFER |
                                                    VOC_MSTAT_ERR_XFER);
                }

                break;

            case VOC_SM_MSTR_RD_DATA:

                VOC_mstrRdBufPtr[VOC_mstrRdBufIndex] = VOC_DATA_REG;
                VOC_mstrRdBufIndex++;

                /* Check if end of buffer */
                if(VOC_mstrRdBufIndex < VOC_mstrRdBufSize)
                {
                    VOC_ACK_AND_RECEIVE;       /* ACK and receive byte */
                }
                /* End of buffer: complete reading */
                else if(VOC_CHECK_NO_STOP(VOC_mstrControl))
                {
                    /* Set read complete and master halted */
                    VOC_mstrStatus |= (VOC_MSTAT_XFER_HALT |
                                                    VOC_MSTAT_RD_CMPLT);

                    VOC_state = VOC_SM_MSTR_HALT;    /* Expect ReStart */
                    VOC_DisableInt();
                }
                else
                {
                    VOC_ENABLE_INT_ON_STOP;
                    VOC_NAK_AND_RECEIVE;       /* NACK and TRY to generate Stop */
                }
                break;

            default: /* This is an invalid state and should not occur */

            #if(VOC_TIMEOUT_ENABLED)
                /* Exit interrupt to take chance for timeout timer to handles this case */
                VOC_DisableInt();
                VOC_ClearPendingInt();
            #else
                /* Block execution flow: unexpected condition */
                CYASSERT(0u != 0u);
            #endif /* (VOC_TIMEOUT_ENABLED) */

                break;
            }
        }

        /* Catches Stop: end of transaction */
        if(VOC_CHECK_STOP_STS(tmpCsr))
        {
            VOC_mstrStatus |= VOC_GET_MSTAT_CMPLT;

            VOC_DISABLE_INT_ON_STOP;
            VOC_state = VOC_SM_IDLE;
        }
    #endif /* (VOC_MODE_MASTER_ENABLED) */
    }
    else if(VOC_CHECK_SM_SLAVE)
    {
    #if(VOC_MODE_SLAVE_ENABLED)

        if((VOC_CHECK_STOP_STS(tmpCsr)) || /* Stop || Restart */
           (VOC_CHECK_BYTE_COMPLETE(tmpCsr) && VOC_CHECK_ADDRESS_STS(tmpCsr)))
        {
            /* Catch end of master write transaction: use interrupt on Stop */
            /* The Stop bit history on address phase does not have correct state */
            if(VOC_SM_SL_WR_DATA == VOC_state)
            {
                VOC_DISABLE_INT_ON_STOP;

                VOC_slStatus &= ((uint8) ~VOC_SSTAT_WR_BUSY);
                VOC_slStatus |= ((uint8)  VOC_SSTAT_WR_CMPLT);

                VOC_state = VOC_SM_IDLE;
            }
        }

        if(VOC_CHECK_BYTE_COMPLETE(tmpCsr))
        {
            /* The address only issued after Start or ReStart: so check the address
               to catch these events:
                FF : sets an address phase with a byte_complete interrupt trigger.
                UDB: sets an address phase immediately after Start or ReStart. */
            if(VOC_CHECK_ADDRESS_STS(tmpCsr))
            {
            /* Check for software address detection */
            #if(VOC_SW_ADRR_DECODE)
                tmp8 = VOC_GET_SLAVE_ADDR(VOC_DATA_REG);

                if(tmp8 == VOC_slAddress)   /* Check for address match */
                {
                    if(0u != (VOC_DATA_REG & VOC_READ_FLAG))
                    {
                        /* Place code to prepare read buffer here                  */
                        /* `#START VOC_SW_PREPARE_READ_BUF_interrupt` */

                        /* `#END` */

                    #ifdef VOC_SW_PREPARE_READ_BUF_CALLBACK
                        VOC_SwPrepareReadBuf_Callback();
                    #endif /* VOC_SW_PREPARE_READ_BUF_CALLBACK */
                        
                        /* Prepare next operation to read, get data and place in data register */
                        if(VOC_slRdBufIndex < VOC_slRdBufSize)
                        {
                            /* Load first data byte from array */
                            VOC_DATA_REG = VOC_slRdBufPtr[VOC_slRdBufIndex];
                            VOC_ACK_AND_TRANSMIT;
                            VOC_slRdBufIndex++;

                            VOC_slStatus |= VOC_SSTAT_RD_BUSY;
                        }
                        else    /* Overflow: provide 0xFF on bus */
                        {
                            VOC_DATA_REG = VOC_OVERFLOW_RETURN;
                            VOC_ACK_AND_TRANSMIT;

                            VOC_slStatus  |= (VOC_SSTAT_RD_BUSY |
                                                           VOC_SSTAT_RD_ERR_OVFL);
                        }

                        VOC_state = VOC_SM_SL_RD_DATA;
                    }
                    else  /* Write transaction: receive 1st byte */
                    {
                        VOC_ACK_AND_RECEIVE;
                        VOC_state = VOC_SM_SL_WR_DATA;

                        VOC_slStatus |= VOC_SSTAT_WR_BUSY;
                        VOC_ENABLE_INT_ON_STOP;
                    }
                }
                else
                {
                    /*     Place code to compare for additional address here    */
                    /* `#START VOC_SW_ADDR_COMPARE_interruptStart` */

                    /* `#END` */

                #ifdef VOC_SW_ADDR_COMPARE_ENTRY_CALLBACK
                    VOC_SwAddrCompare_EntryCallback();
                #endif /* VOC_SW_ADDR_COMPARE_ENTRY_CALLBACK */
                    
                    VOC_NAK_AND_RECEIVE;   /* NACK address */

                    /* Place code to end of condition for NACK generation here */
                    /* `#START VOC_SW_ADDR_COMPARE_interruptEnd`  */

                    /* `#END` */

                #ifdef VOC_SW_ADDR_COMPARE_EXIT_CALLBACK
                    VOC_SwAddrCompare_ExitCallback();
                #endif /* VOC_SW_ADDR_COMPARE_EXIT_CALLBACK */
                }

            #else /* (VOC_HW_ADRR_DECODE) */

                if(0u != (VOC_DATA_REG & VOC_READ_FLAG))
                {
                    /* Place code to prepare read buffer here                  */
                    /* `#START VOC_HW_PREPARE_READ_BUF_interrupt` */

                    /* `#END` */
                    
                #ifdef VOC_HW_PREPARE_READ_BUF_CALLBACK
                    VOC_HwPrepareReadBuf_Callback();
                #endif /* VOC_HW_PREPARE_READ_BUF_CALLBACK */

                    /* Prepare next operation to read, get data and place in data register */
                    if(VOC_slRdBufIndex < VOC_slRdBufSize)
                    {
                        /* Load first data byte from array */
                        VOC_DATA_REG = VOC_slRdBufPtr[VOC_slRdBufIndex];
                        VOC_ACK_AND_TRANSMIT;
                        VOC_slRdBufIndex++;

                        VOC_slStatus |= VOC_SSTAT_RD_BUSY;
                    }
                    else    /* Overflow: provide 0xFF on bus */
                    {
                        VOC_DATA_REG = VOC_OVERFLOW_RETURN;
                        VOC_ACK_AND_TRANSMIT;

                        VOC_slStatus  |= (VOC_SSTAT_RD_BUSY |
                                                       VOC_SSTAT_RD_ERR_OVFL);
                    }

                    VOC_state = VOC_SM_SL_RD_DATA;
                }
                else  /* Write transaction: receive 1st byte */
                {
                    VOC_ACK_AND_RECEIVE;
                    VOC_state = VOC_SM_SL_WR_DATA;

                    VOC_slStatus |= VOC_SSTAT_WR_BUSY;
                    VOC_ENABLE_INT_ON_STOP;
                }

            #endif /* (VOC_SW_ADRR_DECODE) */
            }
            /* Data states */
            /* Data master writes into slave */
            else if(VOC_state == VOC_SM_SL_WR_DATA)
            {
                if(VOC_slWrBufIndex < VOC_slWrBufSize)
                {
                    tmp8 = VOC_DATA_REG;
                    VOC_ACK_AND_RECEIVE;
                    VOC_slWrBufPtr[VOC_slWrBufIndex] = tmp8;
                    VOC_slWrBufIndex++;
                }
                else  /* of array: complete write, send NACK */
                {
                    VOC_NAK_AND_RECEIVE;

                    VOC_slStatus |= VOC_SSTAT_WR_ERR_OVFL;
                }
            }
            /* Data master reads from slave */
            else if(VOC_state == VOC_SM_SL_RD_DATA)
            {
                if(VOC_CHECK_DATA_ACK(tmpCsr))
                {
                    if(VOC_slRdBufIndex < VOC_slRdBufSize)
                    {
                         /* Get data from array */
                        VOC_DATA_REG = VOC_slRdBufPtr[VOC_slRdBufIndex];
                        VOC_TRANSMIT_DATA;
                        VOC_slRdBufIndex++;
                    }
                    else   /* Overflow: provide 0xFF on bus */
                    {
                        VOC_DATA_REG = VOC_OVERFLOW_RETURN;
                        VOC_TRANSMIT_DATA;

                        VOC_slStatus |= VOC_SSTAT_RD_ERR_OVFL;
                    }
                }
                else  /* Last byte was NACKed: read complete */
                {
                    /* Only NACK appears on bus */
                    VOC_DATA_REG = VOC_OVERFLOW_RETURN;
                    VOC_NAK_AND_TRANSMIT;

                    VOC_slStatus &= ((uint8) ~VOC_SSTAT_RD_BUSY);
                    VOC_slStatus |= ((uint8)  VOC_SSTAT_RD_CMPLT);

                    VOC_state = VOC_SM_IDLE;
                }
            }
            else
            {
            #if(VOC_TIMEOUT_ENABLED)
                /* Exit interrupt to take chance for timeout timer to handle this case */
                VOC_DisableInt();
                VOC_ClearPendingInt();
            #else
                /* Block execution flow: unexpected condition */
                CYASSERT(0u != 0u);
            #endif /* (VOC_TIMEOUT_ENABLED) */
            }
        }
    #endif /* (VOC_MODE_SLAVE_ENABLED) */
    }
    else
    {
        /* The FSM skips master and slave processing: return to IDLE */
        VOC_state = VOC_SM_IDLE;
    }

#ifdef VOC_ISR_EXIT_CALLBACK
    VOC_ISR_ExitCallback();
#endif /* VOC_ISR_EXIT_CALLBACK */    
}


#if ((VOC_FF_IMPLEMENTED) && (VOC_WAKEUP_ENABLED))
    /*******************************************************************************
    * Function Name: VOC_WAKEUP_ISR
    ********************************************************************************
    *
    * Summary:
    *  The interrupt handler to trigger after a wakeup.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    *******************************************************************************/
    CY_ISR(VOC_WAKEUP_ISR)
    {
    #ifdef VOC_WAKEUP_ISR_ENTRY_CALLBACK
        VOC_WAKEUP_ISR_EntryCallback();
    #endif /* VOC_WAKEUP_ISR_ENTRY_CALLBACK */
         
        /* Set flag to notify that matched address is received */
        VOC_wakeupSource = 1u;

        /* SCL is stretched until the I2C_Wake() is called */

    #ifdef VOC_WAKEUP_ISR_EXIT_CALLBACK
        VOC_WAKEUP_ISR_ExitCallback();
    #endif /* VOC_WAKEUP_ISR_EXIT_CALLBACK */
    }
#endif /* ((VOC_FF_IMPLEMENTED) && (VOC_WAKEUP_ENABLED)) */


/* [] END OF FILE */
